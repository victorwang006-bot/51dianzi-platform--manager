import {ts,need,program,walk,explicitKeys,compileFunction,alphaEqual} from './parity-core.mjs';import {patch,findFn,lastReturn} from './incremental-core.mjs';import {canonical}from './detail-source-guard.mjs';
const fixed=n=>{const p=n.parent;return(ts.isPropertyAccessExpression(p)&&p.name===n)||(ts.isPropertyAssignment(p)&&p.name===n)||(ts.isBindingElement(p)&&p.propertyName===n)||(ts.isMethodDeclaration(p)&&p.name===n)};
export function transplantUnit(code,binding={},extraFree={},allowedNew=true){const text=explicitKeys(code),p=program(text),free={...(binding.freeIdentifiers||{}),...extraFree},map=new Map(),names=new Map(),edits=[],symbols=[];for(const row of binding.localSymbols||[]){if(names.has(row.source))need(names.get(row.source)===row.compiled,'AMBIGUOUS_BINDING '+row.source);names.set(row.source,row.compiled)}let index=0;walk(p.file,n=>{if(!ts.isIdentifier(n)||fixed(n))return;const s=p.checker.getSymbolAtLocation(n);let target;if(s?.declarations?.length){if(!map.has(s)){target=names.get(n.text);if(!target){need(allowedNew,'NEW_LOCAL_REJECT '+n.text);target='__detailLocal_'+n.text+'_'+index++}map.set(s,target);symbols.push({source:n.text,compiled:target,kinds:s.declarations.map(d=>ts.SyntaxKind[d.kind])})}target=map.get(s)}else{target=free[n.text];need(target,'UNKNOWN_FREE '+n.text)}if(target!==n.text)edits.push({start:n.getStart(p.file),end:n.end,after:target,reason:'checker-symbol exact transplant'})});const out=patch(text,edits).bytes.toString();return{code:out,proof:{freeIdentifiers:free,localSymbols:symbols,renamedReferences:edits.length,afterAlpha:alphaEqual(text,out)}}}
export async function compileTail(sourceAST,fn){const nodes=fn.body.statements.filter(n=>ts.isReturnStatement(n)||ts.isIfStatement(n)&&n.expression.getText(sourceAST).includes('phase ==='));return compileFunction('function __Render(){'+nodes.map(n=>n.getText(sourceAST)).join('\n')+'}','__Render')}
function arrowList(text){const pre='const __result = ';const p=program(pre+text+';'),nodes=[];walk(p.file,n=>{if(ts.isArrowFunction(n))nodes.push(n)});return{...p,nodes,offset:pre.length}}
function isMapArrow(n){return ts.isCallExpression(n.parent)&&n.parent.arguments.includes(n)&&ts.isPropertyAccessExpression(n.parent.expression)&&n.parent.expression.name.text==='map'}
const NULL_FILTER_TEXT='__demoB_entry => __demoB_entry[1] !== null && __demoB_entry[1].trim().length > 0';
const NULL_FILTER_CANONICAL=canonical(arrowList(NULL_FILTER_TEXT).nodes[0]);
function isExactNullAttributeFilter(n){return ts.isCallExpression(n.parent)&&n.parent.arguments.length===1&&n.parent.arguments[0]===n&&ts.isPropertyAccessExpression(n.parent.expression)&&n.parent.expression.name.text==='filter'&&canonical(n)===NULL_FILTER_CANONICAL}
export function freezeExisting(oldText,newText,{allowPureMaps=0,allowIIFE=false,allowReplacedMap=0,allowNullAttributeFilter=0}={}){
 const old=arrowList(oldText),next=arrowList(newText),groups=new Map();
 for(const n of old.nodes){const k=canonical(n);if(!groups.has(k))groups.set(k,[]);groups.get(k).push(n)}
 const found=new Map(),added=[],filters=[],replaced=new Set();
 for(const n of next.nodes){
  const k=canonical(n);
  if(groups.has(k)){if(!found.has(k))found.set(k,[]);found.get(k).push(n)}
  else{
   const iife=allowIIFE&&ts.isBlock(n.body)&&n.body.statements.some(s=>ts.isVariableStatement(s)&&s.declarationList.declarations.some(d=>d.name.getText(next.file).startsWith('__demoB_')));
   const nullFilter=allowNullAttributeFilter===1&&isExactNullAttributeFilter(n);
   need(iife||isMapArrow(n)||nullFilter,'UNKNOWN_OR_CHANGED_CALLBACK '+n.getText(next.file).slice(0,180));
   if(nullFilter)filters.push(n);else if(!iife)added.push(n);
  }
 }
 for(const[k,nodes]of groups){const candidates=found.get(k)||[];if(candidates.length===0&&nodes.every(isMapArrow))replaced.add(k);else need(candidates.length===nodes.length,'ORIGINAL_CALLBACK_REMOVED '+k.slice(0,140))}
 need(replaced.size===allowReplacedMap,'EXACT_REPLACED_PRESENTATION_MAPS');need(added.length===allowPureMaps,'EXACT_NEW_PURE_RENDER_MAPS '+added.length);need(filters.length===allowNullAttributeFilter,'EXACT_NULL_ATTRIBUTE_FILTER_COUNT');
 const rows=[];for(const[k,ns]of found)for(let i=0;i<ns.length;i++)rows.push({node:ns[i],old:groups.get(k)[i]});
 const top=rows.filter(r=>!rows.some(q=>q!==r&&q.node.getStart(next.file)<=r.node.getStart(next.file)&&q.node.end>=r.node.end));
 const out=patch(newText,top.map(r=>({start:r.node.getStart(next.file)-next.offset,end:r.node.end-next.offset,after:r.old.getText(old.file),reason:'Frozen original exact callback bytes'}))).bytes.toString();
 const check=arrowList(out);for(const[k,ns]of groups){if(replaced.has(k))continue;const cs=check.nodes.filter(n=>canonical(n)===k);need(cs.length===ns.length&&cs.every((n,i)=>n.getText(check.file)===ns[i].getText(old.file)),'CALLBACK_BYTE_INVERSE')}
 return{expression:out,proof:{originalArrowsExact:old.nodes.length-replaced.size,rawCallbacksCopied:top.length,newPureRenderMapArrows:added.length,sourceBoundReplacedPresentationMaps:replaced.size,originalCallbackBytesExact:true,sourceBoundNewMaps:true,sourceBoundNullAttributeFilterCount:filters.length,exactNullAttributeFilterCanonical:filters.length?NULL_FILTER_CANONICAL:null}};
}
export function expressionOf(code){const {file}=program(code);return lastReturn(file.statements.find(ts.isFunctionDeclaration)).expression.getText(file)}
