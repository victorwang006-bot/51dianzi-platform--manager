import type { OfficialMallPublicMaterial } from "../../server/services/officialMallPublic";

export const OFFICIAL_QUANTITY_MAX = 2_147_483_647;
export function positiveOfficialQuantity(value: number | null | undefined): value is number {
  return typeof value === "number" && Number.isInteger(value) && value > 0 && value <= OFFICIAL_QUANTITY_MAX;
}
export function parseOfficialQuantity(raw: string): number | null {
  const text = raw.trim();
  if (!/^\d{1,10}$/.test(text)) return null;
  const value = Number(text);
  return positiveOfficialQuantity(value) ? value : null;
}
export function initialOfficialQuantity(item: OfficialMallPublicMaterial): number {
  return positiveOfficialQuantity(item.moq) ? item.moq : 1;
}
export function validOfficialQuantity(item: OfficialMallPublicMaterial, quantity: number | null): quantity is number {
  return positiveOfficialQuantity(quantity)
    && (!positiveOfficialQuantity(item.moq) || quantity >= item.moq)
    && (!positiveOfficialQuantity(item.spq) || quantity % item.spq === 0)
    && (item.qtyOnSale === null || item.qtyOnSale === undefined || quantity <= item.qtyOnSale);
}
/** Highest published minimum reached, never the first tier as a universal price. */
export function applicableOfficialPrice(item: OfficialMallPublicMaterial, quantity: number | null): string | null {
  if (!validOfficialQuantity(item, quantity)) return null;
  if (!item.ladderPrices.length) return item.priceEx;
  let selected: { minQty: number; price: string } | undefined;
  for (const tier of item.ladderPrices) {
    if (tier.minQty <= quantity && (!selected || tier.minQty > selected.minQty)) selected = tier;
  }
  return selected?.price ?? null;
}
/** Decimal string × integer, then half-up cents. No floating-point financial conversion. */
export function officialSubtotal(price: string | null, quantity: number | null): string | null {
  if (price === null || !positiveOfficialQuantity(quantity) || !/^(?:0|[1-9]\d{0,11})(?:\.\d{1,6})?$/.test(price)) return null;
  const [integer, fraction = ""] = price.split(".");
  const amount = BigInt(integer + fraction) * BigInt(quantity);
  const powerOfTen = (places: number) => BigInt(`1${"0".repeat(places)}`);
  const divisor = powerOfTen(Math.max(0, fraction.length - 2));
  const cents = fraction.length <= 2 ? amount * powerOfTen(2 - fraction.length)
    : amount / divisor + (amount % divisor * BigInt(2) >= divisor ? BigInt(1) : BigInt(0));
  return `${cents / BigInt(100)}.${(cents % BigInt(100)).toString().padStart(2, "0")}`;
}
/** Null SPQ is explicitly unconstrained; missing MOQ/sale metadata cannot become a purchase default. */
export function officialDraftReady(item: OfficialMallPublicMaterial, quantity: number | null): quantity is number {
  const price = applicableOfficialPrice(item, quantity);
  return positiveOfficialQuantity(item.moq) && (item.spq === null || positiveOfficialQuantity(item.spq))
    && positiveOfficialQuantity(item.qtyOnSale) && validOfficialQuantity(item, quantity)
    && price !== null && /[1-9]/.test(price) && officialSubtotal(price, quantity) !== null;
}
