import * as React from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { AUTH_SESSION_CLEARED_EVENT } from "@/lib/authSessionEvents";
import {
  OFFICIAL_MATERIAL_FAVORITES_QUERY_ROOT, OFFICIAL_MATERIAL_RESOURCES_QUERY_ROOT,
  OFFICIAL_MATERIAL_FAVORITES_CHANGED_EVENT, notifyOfficialMaterialFavoritesChanged,
  officialMaterialErrorMessage, type OfficialMaterialClient,
  prefetchOfficialMaterialResources, getFreshOfficialMaterialResource, OFFICIAL_MATERIAL_RESOURCE_FRESH_MS,
  type OfficialMaterialIdentity, type OfficialMaterialResourceSeed, type OfficialMaterialResourceUnavailable,
} from "@/lib/officialMaterialClient";
import type { OfficialMaterialResource, OfficialMaterialFavoriteStatesResult } from "@shared/officialMaterial";

type Identity = OfficialMaterialIdentity;
const MAX_VISIBLE = 100;
const BATCH_SIZE = 20;
export type OfficialMaterialHookDependencies = {
  React: Pick<typeof React, "useEffect" | "useRef" | "useState">;
  useQuery: typeof useQuery;
  useQueryClient: typeof useQueryClient;
  useAuth: typeof useAuth;
  trpc: Pick<typeof trpc, "useUtils">;
  onLoginRequired: () => void;
  toast: Pick<typeof toast, "success" | "error">;
};
/** Existing App hooks/client are injected by the native host; no transport/provider is created. */
export function createOfficialMaterialHooks(deps: OfficialMaterialHookDependencies) {
  function useOfficialMaterial(identities: readonly Identity[], seed?: OfficialMaterialResourceSeed) {
    const { user, loading, isAuthenticated } = deps.useAuth();
    const rawOwner = !loading && isAuthenticated && user ? String(user.id) : null;
    const clearedOwner = deps.React.useRef<string | null>(null);
    if (rawOwner === null) clearedOwner.current = null;
    const owner = rawOwner !== null && rawOwner !== clearedOwner.current ? rawOwner : null;
    const queryClient = deps.useQueryClient();
    const utils = deps.trpc.useUtils();
    const client: OfficialMaterialClient = utils.client as unknown as OfficialMaterialClient;
    const rootRef = deps.React.useRef<HTMLDivElement | null>(null);
    const [epoch, setEpoch] = deps.React.useState(0);
    const [visible, setVisible] = deps.React.useState<string[]>([]);
    const [pending, setPending] = deps.React.useState<{ key: string; ids: string[] }>({ key: "", ids: [] });
    const signature = JSON.stringify(identities.map(row => [row.publicId, row.revision]));
    const scopeKey = JSON.stringify([owner, epoch, signature]);
    const scope = deps.React.useRef({ owner, key: scopeKey, signature, generation: 0, mounted: true, blocked: false });
    const locks = deps.React.useRef(new Set<string>());
    if (scope.current.key !== scopeKey) {
      scope.current.generation += 1;
      scope.current.blocked = false;
      locks.current.clear();
    }
    scope.current.owner = owner;
    scope.current.key = scopeKey;
    scope.current.signature = signature;
    const generation = scope.current.generation;
    const current = (key = scopeKey, search = signature) => scope.current.mounted && !scope.current.blocked
      && scope.current.key === key && scope.current.signature === search && scope.current.generation === generation;
    deps.React.useEffect(() => {
      scope.current.mounted = true;
      const changed = () => { void queryClient.invalidateQueries({ queryKey: OFFICIAL_MATERIAL_FAVORITES_QUERY_ROOT }); };
      const clear = () => {
        clearedOwner.current = scope.current.owner;
        scope.current.blocked = true;
        scope.current.owner = null;
        locks.current.clear();
        void queryClient.cancelQueries({ queryKey: OFFICIAL_MATERIAL_FAVORITES_QUERY_ROOT });
        queryClient.removeQueries({ queryKey: OFFICIAL_MATERIAL_FAVORITES_QUERY_ROOT });
        setEpoch(value => value + 1);
      };
      const storage = (event: StorageEvent) => {
        if (event.key === OFFICIAL_MATERIAL_FAVORITES_CHANGED_EVENT && event.newValue) changed();
        if (event.key === "51dianzi:auth-session-cleared:v1" && event.newValue) clear();
      };
      window.addEventListener(OFFICIAL_MATERIAL_FAVORITES_CHANGED_EVENT, changed);
      window.addEventListener(AUTH_SESSION_CLEARED_EVENT, clear);
      window.addEventListener("storage", storage);
      return () => {
        scope.current.mounted = false;
        window.removeEventListener(OFFICIAL_MATERIAL_FAVORITES_CHANGED_EVENT, changed);
        window.removeEventListener(AUTH_SESSION_CLEARED_EVENT, clear);
        window.removeEventListener("storage", storage);
      };
    }, [queryClient]);
    deps.React.useEffect(() => {
      const root = rootRef.current;
      if (!root) { setVisible([]); return; }
      const allowed = new Set(identities.map(row => row.publicId));
      if (typeof IntersectionObserver === "undefined") {
        setVisible(Array.from(allowed).slice(0, BATCH_SIZE));
        return;
      }
      const intersecting = new Set<string>();
      setVisible([]);
      const observer = new IntersectionObserver(entries => {
        for (const entry of entries) {
          const id = (entry.target as HTMLElement).dataset.officialPublicId;
          if (!id || !allowed.has(id)) continue;
          if (entry.isIntersecting) intersecting.add(id); else intersecting.delete(id);
        }
        const next = Array.from(intersecting).sort().slice(0, MAX_VISIBLE);
        setVisible(previous => JSON.stringify(previous) === JSON.stringify(next) ? previous : next);
      }, { rootMargin: "160px 0px" });
      root.querySelectorAll("[data-official-public-id]").forEach(node => observer.observe(node));
      return () => observer.disconnect();
    }, [signature]);
    const revisions = new Map(identities.map(row => [row.publicId, row.revision]));
    const requested = Array.from(new Set(visible)).filter(id => revisions.has(id)).sort().slice(0, MAX_VISIBLE);
    // Seed belongs to the list snapshot, not the current visible aggregate. Never discard its
    // matching parameters when the observer changes visible IDs, owner or favorite epoch.
    const seeded = new Map<string, OfficialMaterialResource>();
    const seedUnavailable = new Map<string, OfficialMaterialResourceUnavailable>();
    for (const row of seed?.resourceSeed ?? []) {
      if (revisions.get(row.publicId) === row.revision) seeded.set(row.publicId, row);
    }
    for (const row of seed?.unavailable ?? []) {
      if (revisions.get(row.publicId) === row.revision && !seeded.has(row.publicId)) seedUnavailable.set(row.publicId, row);
    }
    const resourceIdentities = requested.filter(id => !seeded.has(id) && !seedUnavailable.has(id))
      .map(publicId => ({ publicId, revision: revisions.get(publicId)! }));
    const identityKey = resourceIdentities.map(row => [row.publicId, row.revision]);
    const resources = deps.useQuery({
      // Separate from public-batch-v2: fetchQuery must never recurse into its own aggregate key.
      queryKey: [...OFFICIAL_MATERIAL_RESOURCES_QUERY_ROOT, "public-view-v2", identityKey],
      enabled: seed?.source !== "inline" && resourceIdentities.length > 0,
      staleTime: 0, gcTime: OFFICIAL_MATERIAL_RESOURCE_FRESH_MS, retry: false,
      queryFn: ({ signal }) => prefetchOfficialMaterialResources(queryClient, client, resourceIdentities, { signal }),
    });
    const favorites = deps.useQuery({
      queryKey: [...OFFICIAL_MATERIAL_FAVORITES_QUERY_ROOT, owner, epoch, "states", requested],
      enabled: owner !== null && requested.length > 0,
      staleTime: 30_000, gcTime: 60_000, retry: false,
      queryFn: async ({ signal }): Promise<OfficialMaterialFavoriteStatesResult> => {
        const items: OfficialMaterialFavoriteStatesResult["items"] = [];
        for (let offset = 0; offset < requested.length; offset += BATCH_SIZE) {
          const batch = requested.slice(offset, offset + BATCH_SIZE);
          const result = await client.officialMaterial.favoriteStates.query({ publicIds: batch }, { signal });
          if (!current() || signal.aborted) throw new Error("登录状态已变化");
          items.push(...result.items.filter(row => batch.includes(row.publicId)));
        }
        return { items };
      },
    });
    const toggleFavorite = async (publicId: string) => {
      if (!owner || scope.current.blocked) { deps.onLoginRequired(); return; }
      if (!current() || locks.current.has(publicId)) return;
      const existing = favorites.data?.items.find(row => row.publicId === publicId);
      if (!existing) { deps.toast.error("收藏状态暂不可用，请重试"); return; }
      const key = scopeKey, search = signature;
      const desired = !existing.favorite;
      locks.current.add(publicId);
      setPending({ key: `${key}:${generation}`, ids: Array.from(locks.current) });
      try {
        const result = await client.officialMaterial.setFavorite.mutate({ publicId, favorite: desired });
        if (!current(key, search)) return;
        if (result.publicId !== publicId || result.favorite !== desired) throw new Error("收藏状态待确认");
        // Only a confirmed server response changes the star. Never persist favorites in storage.
        queryClient.setQueriesData<OfficialMaterialFavoriteStatesResult>({
          queryKey: [...OFFICIAL_MATERIAL_FAVORITES_QUERY_ROOT, owner, epoch, "states"],
        }, old => old ? { items: old.items.map(row => row.publicId === publicId ? result : row) } : old);
        notifyOfficialMaterialFavoritesChanged(queryClient);
        deps.toast.success(desired ? "已收藏" : "已取消收藏");
      } catch (error) {
        if (!current(key, search)) return;
        const message = officialMaterialErrorMessage(error, "收藏失败，请重试");
        if (message === "请先登录") deps.onLoginRequired();
        else deps.toast.error(message);
      } finally {
        if (current(key, search)) {
          locks.current.delete(publicId);
          setPending({ key: `${key}:${generation}`, ids: Array.from(locks.current) });
        }
      }
    };
    const mergedResources = new Map(seeded);
    const resourceUnavailable = new Map(seedUnavailable);
    for (const identity of identities) {
      const cached = seed?.source === "inline" ? undefined : getFreshOfficialMaterialResource(queryClient, identity);
      if (cached) mergedResources.set(identity.publicId, cached);
    }
    for (const row of resources.data?.resourceSeed ?? []) {
      if (seed?.source !== "inline" && revisions.get(row.publicId) === row.revision) mergedResources.set(row.publicId, row);
    }
    for (const row of resources.data?.unavailable ?? []) {
      if (seed?.source !== "inline" && revisions.get(row.publicId) === row.revision) resourceUnavailable.set(row.publicId, row);
    }
    for (const id of Array.from(mergedResources.keys())) resourceUnavailable.delete(id);
    const resourceErrors = new Map(Array.from(resourceUnavailable, ([id, row]) => [id, row.message]));
    const resourceLoading = new Set(identities.filter(row => !mergedResources.has(row.publicId)
      && !resourceUnavailable.has(row.publicId)).map(row => row.publicId));
    return {
      rootRef,
      resources: mergedResources,
      resourceUnavailable, resourceErrors, resourceLoading,
      favorites: new Map((owner && !scope.current.blocked ? favorites.data?.items ?? [] : []).map(row => [row.publicId, row.favorite])),
      pending: new Set(pending.key === `${scopeKey}:${generation}` ? pending.ids : []),
      favoriteError: owner && favorites.isError ? officialMaterialErrorMessage(favorites.error, "收藏状态暂不可用") : null,
      resourceError: resources.isError ? officialMaterialErrorMessage(resources.error, "资料暂不可用")
        : resourceErrors.values().next().value ?? null,
      authenticated: owner !== null && !scope.current.blocked,
      toggleFavorite,
    };
  }
  return { useOfficialMaterial };
}
export const { useOfficialMaterial } = createOfficialMaterialHooks({
  React, useQuery, useQueryClient, useAuth, trpc, onLoginRequired: startLogin, toast,
});
