// @vitest-environment jsdom
import * as React from "react";
import { act, useLayoutEffect } from "react";
import { createRoot, type Root } from "react-dom/client";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { readFileSync } from "node:fs";
import type { OfficialMallPublicMaterial as PublishedMaterial, OfficialMallPublicListResult } from "../../../server/services/officialMallPublic";
import type { OfficialMaterialResource } from "@shared/officialMaterial";
const mocks = vi.hoisted(() => ({ list: vi.fn(), resources: vi.fn(), favorites: vi.fn(), login: vi.fn(), cartAdd: vi.fn() }));
vi.mock("@/lib/trpc", () => ({ trpc: { useUtils: () => ({ client: { officialMall: { list: { query: mocks.list } }, officialMaterial: {
  resources: { query: mocks.resources }, favoriteStates: { query: mocks.favorites }, setFavorite: { mutate: vi.fn() },
} } }) } }));
vi.mock("@/_core/hooks/useAuth", () => ({ useAuth: () => ({ user: null, loading: false, isAuthenticated: false }) }));
vi.mock("@/const", () => ({ startLogin: mocks.login }));
vi.mock("@/hooks/useOfficialCart", () => ({ useOfficialCartCount: () => ({ buyer: null, key: "anonymous", readiness: "login_required",
  client: { officialCart: { add: { mutate: mocks.cartAdd } } }, isCurrent: () => true, invalidate: vi.fn() }) }));
vi.mock("./MallLoginDialog", () => ({ default: ({ open }: { open: boolean }) => open ? <div data-login-dialog>登录</div> : null }));
vi.mock("sonner", () => ({ toast: { success: vi.fn(), error: vi.fn() } }));
import { OfficialMallCheckoutResults } from "./OfficialMallCheckoutResults";
import { OfficialMallSearchResults, officialSearchScopeSupported } from "./OfficialMallSearchResults";
import { useSearchResultCommit } from "@/hooks/useSearchResultCommit";
import { officialMaterialResourceItemKey } from "@/lib/officialMaterialClient";
import { SEARCH_RESULT_TIMEOUT_MS } from "@/lib/searchResultCommit";
(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
type OfficialMallPublicMaterial = PublishedMaterial & { technicalResource?: import("@/lib/officialMaterialClient").OfficialInlineTechnicalResource };
const id = "OM_11111111-1111-4111-8111-111111111111";
function material(patch: Partial<OfficialMallPublicMaterial> = {}): OfficialMallPublicMaterial {
  const row = { sourceType: "official_mall" as const, publicId: id, revision: 1, partNumber: "SYNTH", brand: "ST", pkg: "QFN", dateCode: "2026",
    leadTime: "3天", qtyStock: 100, qtyOnSale: 90, qtyOrder: 10, moq: 10, spq: 5, priceEx: "1.230001", taxIncluded: true,
    ladderPrices: [{ minQty: 10, price: "1.230001" }], publishedAt: "2026-01-01T00:00:00.000Z", ...patch };
  const resource: OfficialMaterialResource = { publicId: row.publicId, revision: row.revision, partNumber: row.partNumber, brand: row.brand, pkg: row.pkg,
    category: "MCU", description: "真实公开技术说明", datasheetUrl: "https://www.st.com/test.pdf", parameters: [{ name: "主频", value: "72 MHz" }] };
  return { ...row, technicalResource: { state: "ready", parameterVersion: "dictionary-v1", resource }, ...patch };
}
function result(items = [material()], total = items.length, page = 1): OfficialMallPublicListResult { return { items, total, page, pageSize: 100 }; }
function deferred<T>() { let resolve!: (value: T) => void; const promise = new Promise<T>(done => { resolve = done; }); return { promise, resolve }; }
let root: Root, host: HTMLDivElement, queryClient: QueryClient;
const frames: Array<{ merchant: string | null; official: string | null; parameter: string | null }> = [];
type Merchant = { items: string[] };
function Harness({ keyword = "SYNTH", data, pending = true, error = false, category = "all" }: { keyword?: string; data?: Merchant; pending?: boolean; error?: boolean; category?: string }) {
  const retention = JSON.stringify([keyword, category, "anonymous"]);
  const commit = useSearchResultCommit(retention, retention, { data, pending, error }, officialSearchScopeSupported({ keyword, brand: "all", category }));
  useLayoutEffect(() => { frames.push({ merchant: host.querySelector("output")?.textContent ?? null,
    official: host.querySelector(".omr-part")?.textContent ?? null, parameter: host.querySelector(".omr-core-parameters")?.textContent ?? null }); });
  return <><OfficialMallCheckoutResults keyword={keyword} brand="all" sort="default" viewMode="list" category={category} searchCommit={commit.officialCommit} />
    <output>{commit.waiting ? "loading" : commit.error ? "error" : commit.data?.items.join(",") ?? "empty"}</output></>;
}
async function render(element: React.ReactNode) { await act(async () => root.render(<QueryClientProvider client={queryClient}>{element}</QueryClientProvider>)); }
async function flush() { await act(async () => { await new Promise(done => setTimeout(done, 15)); }); }
function cart() { return host.querySelector<HTMLButtonElement>(".omr-cart")!; }
beforeEach(() => {
  vi.clearAllMocks(); vi.stubGlobal("React", React); frames.length = 0;
  mocks.list.mockResolvedValue(result()); mocks.resources.mockImplementation(() => new Promise(() => {})); mocks.favorites.mockImplementation(() => new Promise(() => {}));
  Object.defineProperty(document, "visibilityState", { configurable: true, value: "visible" });
  host = document.createElement("div"); document.body.append(host); root = createRoot(host);
  queryClient = new QueryClient({ defaultOptions: { queries: { retry: false, gcTime: 0 } } });
});
afterEach(() => { act(() => root.unmount()); queryClient.clear(); host.remove(); vi.useRealTimers(); vi.unstubAllGlobals(); });

describe("anonymous real checkout/search first-paint chain", () => {
  it("publishes official quotation and exact technical seed immediately while merchant is pending", async () => {
    await render(<Harness />); expect(mocks.list).toHaveBeenCalledTimes(1); expect(host.querySelector("article")).not.toBeNull();
    expect(host.querySelector("output")?.textContent).toBe("loading");
    await render(<Harness data={{ items: ["merchant-SYNTH"] }} pending={false} />);
    expect(host.querySelector(".omr-part")?.textContent).toBe("SYNTH"); expect(host.querySelector(".omr-core-parameters")?.textContent).toBe("主频72 MHz");
    expect(host.querySelector("output")?.textContent).toBe("merchant-SYNTH");
    expect(frames.some(frame => frame.official && frame.merchant === "loading")).toBe(true);
    expect(mocks.resources).not.toHaveBeenCalled(); expect(mocks.favorites).not.toHaveBeenCalled();
    expect(cart().disabled).toBe(false); act(() => cart().click());
    expect(host.querySelector("[data-login-dialog]")).not.toBeNull(); expect(mocks.cartAdd).not.toHaveBeenCalled();
  });
  it("publishes merchant rows immediately while official is pending", async () => {
    const quote = deferred<OfficialMallPublicListResult>(); mocks.list.mockReturnValueOnce(quote.promise);
    await render(<Harness data={{ items: ["merchant-SYNTH"] }} pending={false} />);
    expect(host.querySelector("output")?.textContent).toBe("merchant-SYNTH"); expect(host.querySelector("article")).toBeNull();
    await act(async () => quote.resolve(result()));
    expect(host.querySelector("output")?.textContent).toBe("merchant-SYNTH"); expect(host.querySelector(".omr-core-parameters")?.textContent).toBe("主频72 MHz");
    expect(frames.some(frame => frame.merchant === "merchant-SYNTH" && !frame.official)).toBe(true);
  });
  it.each(["unavailable", "legacy", "identity"])("shows truthful %s local state immediately without blocking on slow resources or hiding the quote", async fault => {
    const row = material();
    if (fault === "unavailable") row.technicalResource = { state: "unavailable", parameterVersion: null, resource: null };
    if (fault === "legacy") delete row.technicalResource;
    if (fault === "identity") row.technicalResource = { ...row.technicalResource!, resource: { ...row.technicalResource!.resource!, pkg: "OTHER" } };
    mocks.list.mockResolvedValueOnce(result([row]));
    queryClient.setQueryData(officialMaterialResourceItemKey(row), material().technicalResource!.resource);
    await render(<Harness pending={false} data={{ items: [] }} />); await flush();
    expect(host.querySelector(".omr-part")?.textContent).toBe("SYNTH"); expect(host.querySelector(".omr-core-parameters")).toBeNull();
    expect(host.querySelector(".omr-parameter-state")?.textContent).toMatch(/暂不可用|未提供同步参数|不匹配/);
    expect(host.querySelector(".omr-parameter-state")?.textContent).not.toMatch(/暂无参数|加载中/);
    expect(mocks.resources).not.toHaveBeenCalled(); expect(cart().disabled).toBe(false);
  });
  it("shows proven empty parameters as 暂无参数, not an error and not a slow fetch", async () => {
    const row = material(); row.technicalResource = { state: "missing", parameterVersion: "v1", resource: { ...row.technicalResource!.resource!, parameters: [] } };
    mocks.list.mockResolvedValueOnce(result([row])); await render(<Harness pending={false} data={{ items: [] }} />);
    expect(host.querySelector(".omr-parameter-state")?.textContent).toBe("暂无参数"); expect(mocks.resources).not.toHaveBeenCalled();
  });
  it("never overwrites a versioned inline success with a fresh legacy same-revision cache", async () => {
    queryClient.setQueryData(officialMaterialResourceItemKey(material()), { ...material().technicalResource!.resource!, parameters: [{ name: "主频", value: "OLD" }] });
    await render(<Harness pending={false} data={{ items: [] }} />); await flush();
    expect(host.querySelector(".omr-core-parameters")?.textContent).toBe("主频72 MHz"); expect(mocks.resources).not.toHaveBeenCalled();
  });
  it("the whole displayed multi-page snapshot has inline parameters without viewport resources requests", async () => {
    const rows = Array.from({ length: 100 }, (_, index) => material({ publicId: `synthetic-${index}`, partNumber: `SYNTH-${index}` }));
    mocks.list.mockResolvedValueOnce(result(rows, 105));
    await render(<OfficialMallSearchResults keyword="SYNTH" brand="all" sort="default" viewMode="list" />);
    mocks.list.mockResolvedValueOnce(result(rows, 105)).mockResolvedValueOnce(result(Array.from({ length: 5 }, (_, index) => material({ publicId: `extra-${index}`, partNumber: `SYNTH-EXTRA-${index}` })), 105, 2));
    const more = Array.from(host.querySelectorAll("button")).find(button => button.textContent === "加载更多")!;
    await act(async () => more.click());
    expect(host.querySelectorAll("article")).toHaveLength(105); expect(host.querySelectorAll(".omr-core-parameters")).toHaveLength(105);
    expect(mocks.resources).not.toHaveBeenCalled(); expect(mocks.list.mock.calls.map(call => call[0].page)).toEqual([1, 1, 2]);
  });
  it("React StrictMode effect remounts preserve independent section publication", async () => {
    await render(<React.StrictMode><Harness pending={false} data={{ items: ["merchant-SYNTH"] }} /></React.StrictMode>);
    await flush(); expect(host.querySelector("output")?.textContent).toBe("merchant-SYNTH"); expect(host.querySelector("article")).not.toBeNull();
  });
  it("bounds an abort-ignoring quotation, releases merchant results on terminal failure and ignores late quotation success", async () => {
    vi.useFakeTimers(); const quote = deferred<OfficialMallPublicListResult>(); mocks.list.mockReturnValueOnce(quote.promise);
    await render(<Harness pending={false} data={{ items: ["merchant-SYNTH"] }} />);
    await act(async () => { await vi.advanceTimersByTimeAsync(SEARCH_RESULT_TIMEOUT_MS + 1); });
    expect(host.querySelector("output")?.textContent).toBe("merchant-SYNTH"); expect(host.querySelector('[role="alert"]')?.textContent).toContain("报价暂不可用");
    await act(async () => quote.resolve(result())); expect(host.querySelector("article")).toBeNull();
    expect(mocks.list.mock.calls[0][1].signal.aborted).toBe(true);
  });
  it("bounds merchant-core waiting without waiting on history/brand/cart/favorite adjuncts or accepting late core completion", async () => {
    vi.useFakeTimers(); await render(<Harness />);
    await act(async () => { await vi.advanceTimersByTimeAsync(SEARCH_RESULT_TIMEOUT_MS + 1); });
    expect(host.querySelector("output")?.textContent).toBe("error"); expect(host.querySelector("article")).not.toBeNull();
    await render(<Harness pending={false} data={{ items: ["late-merchant"] }} />); expect(host.querySelector("output")?.textContent).toBe("error");
    expect(mocks.resources).not.toHaveBeenCalled();
  });
  it("clears changed keywords synchronously and rejects staged old A across A→B→A", async () => {
    const oldA = deferred<OfficialMallPublicListResult>(), oldB = deferred<OfficialMallPublicListResult>(), newA = deferred<OfficialMallPublicListResult>();
    mocks.list.mockReturnValueOnce(oldA.promise).mockReturnValueOnce(oldB.promise).mockReturnValueOnce(newA.promise);
    await render(<Harness pending={false} data={{ items: ["old-A"] }} />);
    await render(<Harness keyword="OTHER" pending={false} data={{ items: ["old-B"] }} />);
    await render(<Harness pending={false} data={{ items: ["new-A"] }} />);
    await act(async () => { oldA.resolve(result()); oldB.resolve(result([material({ partNumber: "OTHER" })])); });
    expect(host.querySelector("article")).toBeNull(); expect(host.querySelector("output")?.textContent).toBe("new-A");
    await act(async () => newA.resolve(result([material({ revision: 2 })])));
    expect(host.querySelector("output")?.textContent).toBe("new-A"); expect(host.querySelector("article")).not.toBeNull();
  });
  it("unsupported merchant-only narrowing skips the official party rather than waiting forever", async () => {
    await render(<Harness category="MCU" pending={false} data={{ items: ["merchant-only"] }} />);
    expect(mocks.list).not.toHaveBeenCalled(); expect(host.querySelector("output")?.textContent).toBe("merchant-only");
  });
  it("removes the visual badge, labels the unchanged box and preserves scoped 1:1/contain/stock CSS", async () => {
    await render(<OfficialMallSearchResults keyword="SYNTH" brand="all" sort="default" viewMode="grid" />);
    expect(host.querySelector(".omr-image-note")?.textContent).toBe("包装示意 · 非商品实拍");
    expect(host.querySelector<HTMLImageElement>(".omr-image img")?.alt).toContain("非商品实拍");
    expect(host.querySelector<HTMLImageElement>(".omr-image img")?.src).toContain("official-box-clean-thumb-19274af91b0082dd.webp");
    expect(host.querySelector(".omr-badge")).toBeNull();
    expect(host.querySelector("article")?.getAttribute("data-source-type")).toBe("official_mall");
    expect(host.querySelector("article")?.getAttribute("data-official-public-id")).toBe(id);
    expect(host.querySelector("article")?.getAttribute("aria-label")).toBe("SYNTH 51自营报价");
    const css = host.querySelector("style")?.textContent;
    expect(css).toContain(".omr-root .omr-card .omr-image-placeholder{position:relative;display:block;width:100%!important;height:auto!important;aspect-ratio:1/1");
    expect(css).not.toContain(".omr-badge");
    expect(css).toContain("object-fit:contain"); expect(css).not.toMatch(/\.omr-grid \.omr-image-(?:trigger|placeholder)[^{]*\{[^}]*height:(?:80|96)px/);
    expect(css).toContain(".omr-stock b{font-weight:650;color:#17633b}");
  });
  it("the actual SearchPage wires only merchant core status into the generation fence and forwards it through the checkout alias", () => {
    const page = readFileSync("client/src/pages/SearchPage.tsx", "utf8"), checkout = readFileSync("client/src/components/OfficialMallCheckoutResults.tsx", "utf8");
    expect(page).toContain('OfficialMallCheckoutResults as OfficialMallSearchResults');
    expect(page).toContain('data: merchantData, pending: merchantLoading || merchantFetching, error: Boolean(merchantError)');
    expect(page).toContain('searchCommit={committedSearch.officialCommit}'); expect(checkout).toContain('<deps.OfficialMallSearchResults {...props}');
    expect(page).not.toContain("prefetchOfficialMaterialResources");
  });
});
