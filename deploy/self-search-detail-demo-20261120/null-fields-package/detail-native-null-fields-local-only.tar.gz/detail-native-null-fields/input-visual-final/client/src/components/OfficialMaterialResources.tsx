import * as React from "react";
import type { OfficialMaterialResource } from "@shared/officialMaterial";
import { safeOfficialDatasheetUrl } from "@/lib/officialMaterialClient";

type Parameter = OfficialMaterialResource["parameters"][number];
const PRIORITIES = [
  /^(?:cpu)?内核$|处理器内核|^core$|cpu core/i,
  /主频|时钟频率|工作频率|^frequency$|clock|speed/i,
  /程序存储|闪存|flash|rom size|program memory/i,
  /ram|sram|运行内存|数据存储/i,
  /通道|channels?/i,
  /带宽|bandwidth/i,
  /失调|offset/i,
  /分辨率|resolution/i,
  /工作电压|供电电压|supply voltage/i,
  /温度|temperature/i,
  /^(can|i2c|spi|usb|usart|uart|io|i\/o)/i,
];
/** Reject only whole-field placeholders; zero, signed numbers and ranges are real values. */
export function isValidOfficialParameterText(value: string): boolean {
  const text = value.trim();
  return text.length > 0 && !/^(?:[-—–]\s*)+$/.test(text)
    && !/^(?:n\/?a|n\.a\.|null|undefined|none|暂无(?:数据|参数|资料)?|待确认|未知|无数据|未提供|未填写|未设置|不详)$/i.test(text);
}
export function validOfficialParameters(parameters: readonly Parameter[]): Parameter[] {
  return parameters.filter(row => isValidOfficialParameterText(row.name) && isValidOfficialParameterText(row.value));
}
/** Rank real dictionary keys only; never infer specifications from a part number. */
export function selectOfficialCoreParameters(parameters: readonly Parameter[], limit = 5): Parameter[] {
  return validOfficialParameters(parameters)
    .map((row, index) => ({ row, index, rank: PRIORITIES.findIndex(pattern => pattern.test(row.name)) }))
    .sort((a, b) => (a.rank < 0 ? PRIORITIES.length : a.rank) - (b.rank < 0 ? PRIORITIES.length : b.rank) || a.index - b.index)
    .slice(0, Math.min(5, Math.max(0, limit))).map(entry => entry.row);
}
export type OfficialMaterialResourcesProps = {
  publicId: string;
  partNumber: string;
  resource?: OfficialMaterialResource;
  favorite?: boolean;
  authenticated: boolean;
  pending: boolean;
  error?: string | null;
  resourceError?: string | null;
  onFavorite: () => void;
  onResourceRetry?: () => void;
  /** Search-only parameter panel; omitted/default preserves existing shared consumers. */
  presentation?: "default" | "search" | "detail";
};
export type OfficialMaterialResourcesDependencies = {
  React: Pick<typeof React, "useState" | "useEffect" | "useRef" | "createElement" | "Fragment">;
};
/** Card-local disclosure: no overlay, focus trap, provider or independent query client. */
export function createOfficialMaterialResources(deps: OfficialMaterialResourcesDependencies) {
  const React = deps.React;
  return function OfficialMaterialResources({ publicId, partNumber, resource, favorite, authenticated, pending, error, resourceError, onFavorite, onResourceRetry, presentation = "default" }: OfficialMaterialResourcesProps) {
    const [open, setOpen] = React.useState(false);
    const parameters = validOfficialParameters(resource?.parameters ?? []);
    const core = selectOfficialCoreParameters(parameters);
    const extra = parameters.filter(row => !core.includes(row));
    const expanded = open && extra.length > 0;
    const extraId = `omr-extra-parameters-${publicId}`;
    const technicalError = resourceError === undefined ? error : resourceError;
    const resourceUnavailable = Boolean(technicalError);
    const pdf = safeOfficialDatasheetUrl(resource?.datasheetUrl);
    const searchPresentation = presentation === "search";
    React.useEffect(() => {
      setOpen(false);
    }, [publicId]);
    const shownParameters = presentation === "detail" ? parameters : core;
    const summary = shownParameters.length > 0 ? <dl className={presentation === "detail" ? "omr-detail-parameters" : "omr-core-parameters"} aria-label={presentation === "detail" ? "完整技术参数" : "核心参数"}>
      {shownParameters.map((row, index) => <div key={`${row.name}:${index}`}><dt>{row.name}</dt><dd title={row.value}>{row.value}</dd></div>)}
    </dl> : <p className="omr-parameter-state" role="status">
      {resourceUnavailable ? technicalError : resource ? "暂无参数" : "参数加载中"}
    </p>;
    const disclosure = extra.length > 0 && <button type="button" className="omr-more-parameters" aria-label={expanded ? `收起 ${partNumber} 额外参数` : `展开 ${partNumber} 额外参数`}
      aria-expanded={expanded} aria-controls={extraId} title={expanded ? "收起额外参数" : `还有${extra.length}项参数`}
      onClick={() => setOpen(value => !value)}>{searchPresentation ? expanded ? "收起参数 ∧" : "更多参数 ∨" : expanded ? "收起 ▴" : "…"}</button>;
    const extras = extra.length > 0 && <dl id={extraId} className="omr-extra-parameters" aria-label={`${partNumber} 额外参数`} hidden={!expanded}>
      {expanded && extra.map((row, index) => <div key={`${row.name}:${index}`}><dt>{row.name}</dt><dd>{row.value}</dd></div>)}
    </dl>;
    return <>
      {!searchPresentation && summary}
      <div className="omr-material-utilities">
        <button type="button" className={favorite ? "is-favorite" : undefined} aria-pressed={favorite === true}
          disabled={pending || (authenticated && favorite === undefined)} onClick={onFavorite}
          title={authenticated && favorite === undefined ? "收藏状态加载中" : undefined}>
          <svg width="13" height="13" viewBox="0 0 24 24" aria-hidden="true" fill={favorite ? "currentColor" : "none"} stroke="currentColor" strokeWidth="1.6"><path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9Z" /></svg>
          {pending ? "处理中" : favorite ? "已收藏" : "收藏"}
        </button>
        {resourceUnavailable && onResourceRetry && <button type="button" onClick={onResourceRetry}>重试资料</button>}
        {pdf && <a href={pdf} target="_blank" rel="noopener noreferrer">PDF规格书</a>}
        {!searchPresentation && presentation !== "detail" && disclosure}
        {error && (core.length > 0 || error !== technicalError) && <span className="omr-material-error" role="status">{error}</span>}
      </div>
      {searchPresentation ? <section className="omr-parameter-panel" data-omr-zone="parameters" aria-label={`${partNumber} 商品参数`}>
        {summary}
        {extras}
        {disclosure}
      </section> : presentation === "detail" ? null : extras}
    </>;
  };
}
export default createOfficialMaterialResources({ React });
export const officialMaterialStyles = `
.omr-info{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);align-content:center;column-gap:14px;row-gap:6px}
.omr-basic{min-width:0;grid-column:1;align-self:center}.omr-core-parameters{grid-column:2;min-width:0;margin:0;font-size:11px;line-height:20px;color:#75808c}
.omr-core-parameters>div{display:flex;gap:7px;min-width:0}.omr-core-parameters dt{flex:0 1 45%;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.omr-core-parameters dd{flex:1;min-width:0;margin:0;color:#39434e;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.omr-parameter-state{grid-column:2;min-width:0;margin:0;font-size:11px;line-height:20px;color:#75808c}
.omr-material-utilities{grid-column:1/-1;display:flex;align-items:center;flex-wrap:wrap;gap:5px 14px;min-width:0;line-height:20px;font-size:11px;color:#75808c}.omr-material-utilities button,.omr-material-utilities a{display:inline-flex;align-items:center;gap:4px;min-height:24px;border:0;padding:0;background:none;color:inherit;font:inherit;text-decoration:none;cursor:pointer}.omr-material-utilities button:hover,.omr-material-utilities a:hover{color:#185fa5}.omr-material-utilities button:disabled{cursor:default;opacity:.55}.omr-material-utilities .is-favorite{color:#c27617}.omr-material-error{font-size:11px;color:#9b4d33}
.omr-material-utilities .omr-more-parameters{min-width:24px;justify-content:center;color:#185fa5}
.omr-extra-parameters{grid-column:1/-1;margin:0;min-width:0;font-size:11px;line-height:20px;border-top:1px solid #edf0f3;padding-top:6px}.omr-extra-parameters>div{display:grid;grid-template-columns:minmax(0,40%) minmax(0,1fr);gap:12px}.omr-extra-parameters dt{color:#75808c;overflow-wrap:anywhere}.omr-extra-parameters dd{margin:0;color:#39434e;overflow-wrap:anywhere}
.omr-grid .omr-info{display:flex;flex-direction:column;align-items:stretch}.omr-grid .omr-core-parameters{margin-top:4px}
@media(min-width:901px) and (max-width:1100px){.omr-list .omr-info{grid-template-columns:minmax(0,1fr)}.omr-list .omr-core-parameters,.omr-list .omr-parameter-state{grid-column:1}.omr-list .omr-core-parameters>div{line-height:18px}}
@media(max-width:600px){.omr-info{grid-template-columns:minmax(0,1fr)}.omr-core-parameters,.omr-parameter-state{grid-column:1}.omr-material-utilities{gap:4px 12px}}
.omr-root .omr-card .omr-info-search{display:grid;grid-template-columns:minmax(0,1.1fr) minmax(0,1fr);grid-template-rows:auto auto;align-content:center;align-items:start;column-gap:16px;row-gap:6px;padding:0}
.omr-root .omr-card .omr-info-search>.omr-material-utilities{grid-column:1;grid-row:2}
.omr-root .omr-card .omr-parameter-panel{grid-column:2;grid-row:1/3;min-width:0;align-self:stretch;display:flex;flex-direction:column;gap:6px;border-left:1px solid #edf0f3;padding-left:16px}
.omr-root .omr-card .omr-parameter-panel .omr-core-parameters{margin:0;font-size:12px;line-height:22px}
.omr-root .omr-card .omr-parameter-panel .omr-parameter-state{font-size:12px;line-height:22px}
.omr-root .omr-card .omr-parameter-panel .omr-more-parameters{align-self:flex-start;margin-top:auto;min-height:24px;border:0;padding:0;background:none;color:#185fa5;font:inherit;cursor:pointer}
.omr-root .omr-card .omr-parameter-panel .omr-extra-parameters{width:100%}
.omr-root.omr-grid .omr-card .omr-info-search{grid-template-columns:minmax(0,1fr);grid-template-rows:auto auto auto;align-content:start}
.omr-root.omr-grid .omr-card .omr-parameter-panel{grid-column:1;grid-row:3;border-left:0;border-top:1px solid #edf0f3;padding:10px 0 0}
@media(max-width:600px){.omr-root .omr-card .omr-info-search{grid-template-columns:minmax(0,1fr);grid-template-rows:auto auto auto}.omr-root .omr-card .omr-parameter-panel{grid-column:1;grid-row:3;border-left:0;border-top:1px solid #edf0f3;padding:10px 0 0}}
`;
