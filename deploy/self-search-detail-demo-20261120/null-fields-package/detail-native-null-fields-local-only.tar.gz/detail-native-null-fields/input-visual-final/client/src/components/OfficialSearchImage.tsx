import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import ImageLightbox from "./ImageLightbox";
import type { OfficialMallPublicMaterial } from "../../../server/services/officialMallPublic";

type ImageItem = Pick<OfficialMallPublicMaterial, "partNumber" | "brand" | "thumbnailUrl" | "imageKind">;
export type OfficialSearchImageSource = { thumbnail: string; zoom: string; alt: string };
/** One shared platform-box illustration, never a photo of the listed stock. */
export const OFFICIAL_SEARCH_IMAGE_FALLBACK: OfficialSearchImageSource = {
  thumbnail: "/assets/official-box-clean-thumb-19274af91b0082dd.webp",
  zoom: "/assets/official-box-clean-preview-d66e5a0ebe06d68d.webp",
  alt: "51电子网平台包装示意，非商品实拍",
};

/** All official cards share one platform illustration; product image metadata is ignored. */
export function officialSearchImageSources(_item: ImageItem): OfficialSearchImageSource[] {
  return [OFFICIAL_SEARCH_IMAGE_FALLBACK];
}

/** Fixed portal geometry flips left/right and clamps vertically to the visible viewport. */
export function officialPreviewPosition(rect: Pick<DOMRect, "left" | "right" | "top" | "height">, viewportWidth: number, viewportHeight: number) {
  const inset = 8, gap = 8;
  const width = Math.max(1, Math.min(320, viewportWidth - inset * 2));
  const height = Math.max(1, Math.min(width + 54, viewportHeight - inset * 2));
  const left = rect.right + gap + width <= viewportWidth - inset ? rect.right + gap : rect.left - gap - width;
  return { left: Math.max(inset, Math.min(left, viewportWidth - width - inset)),
    top: Math.max(inset, Math.min(rect.top + rect.height / 2 - height / 2, viewportHeight - height - inset)), width, height };
}

export default function OfficialSearchImage({ item, priority = false }: { item: ImageItem; priority?: boolean }) {
  const sources = officialSearchImageSources(item);
  // A source change unmounts all timers, portals and viewer synchronously (no stale frame).
  const signature = JSON.stringify([item.partNumber, item.brand, sources]);
  return <SourceImage key={signature} sources={sources} priority={priority} />;
}

function SourceImage({ sources, priority }: { sources: OfficialSearchImageSource[]; priority: boolean }) {
  const [index, setIndex] = useState(0);
  const source = sources[index];
  // A shared thumbnail/preview failure ends at the fixed placeholder, without network fallback.
  return source ? <InteractiveImage key={source.thumbnail} source={source} priority={priority}
    onFailure={() => setIndex(value => value === index ? value + 1 : value)} />
    : <div className="omr-image-placeholder" role="img" aria-label="图片暂不可用，非商品实拍"
      style={{ width: 96, height: 80, maxWidth: "100%", flexShrink: 0, background: "#f3f4f6", borderRadius: 4 }} />;
}

function InteractiveImage({ source, priority, onFailure }: { source: OfficialSearchImageSource; priority: boolean; onFailure: () => void }) {
  const button = useRef<HTMLButtonElement>(null);
  const openTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const closeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const focusTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [preview, setPreview] = useState<ReturnType<typeof officialPreviewPosition> | null>(null);
  const [hoverActive, setHoverActive] = useState(false);
  const [requested, setRequested] = useState(false);
  const [viewer, setViewer] = useState(false);
  const clearTimers = () => {
    if (openTimer.current !== null) clearTimeout(openTimer.current);
    if (closeTimer.current !== null) clearTimeout(closeTimer.current);
    openTimer.current = closeTimer.current = null;
  };
  const closePreview = () => { clearTimers(); setPreview(null); setHoverActive(false); };
  const beginHover = () => {
    if (viewer || !window.matchMedia?.("(hover: hover) and (pointer: fine)").matches) return;
    clearTimers();
    setHoverActive(true);
    openTimer.current = setTimeout(() => {
      openTimer.current = null;
      if (!button.current) return;
      setRequested(true);
      setPreview(officialPreviewPosition(button.current.getBoundingClientRect(), window.innerWidth, window.innerHeight));
    }, 150);
  };
  const leaveHover = () => {
    clearTimers();
    closeTimer.current = setTimeout(() => { closeTimer.current = null; setPreview(null); setHoverActive(false); }, 180);
  };
  const openViewer = () => { closePreview(); setViewer(true); };
  const changeViewer = (open: boolean) => {
    setViewer(open);
    if (!open) focusTimer.current = setTimeout(() => { button.current?.focus({ preventScroll: true }); }, 0);
  };
  useEffect(() => () => {
    clearTimers();
    if (focusTimer.current !== null) clearTimeout(focusTimer.current);
  }, []);
  useEffect(() => {
    if (!hoverActive) return;
    const escape = (event: KeyboardEvent) => { if (event.key === "Escape") closePreview(); };
    window.addEventListener("resize", closePreview);
    window.addEventListener("scroll", closePreview, true);
    window.addEventListener("blur", closePreview);
    window.addEventListener("keydown", escape);
    return () => {
      window.removeEventListener("resize", closePreview);
      window.removeEventListener("scroll", closePreview, true);
      window.removeEventListener("blur", closePreview);
      window.removeEventListener("keydown", escape);
    };
  }, [hoverActive]);
  return <>
    <button ref={button} className="omr-image-trigger" type="button" aria-label={`查看 ${source.alt}`} aria-haspopup="dialog"
      onPointerEnter={event => { if (event.pointerType !== "touch") beginHover(); }} onPointerLeave={leaveHover}
      onClick={openViewer} title="点击查看大图" style={{ width: 96, height: 80, maxWidth: "100%", flexShrink: 0 }}>
      <img src={source.thumbnail} alt={source.alt} width={96} height={80} loading={priority ? "eager" : "lazy"}
        decoding="async" fetchPriority={priority ? "high" : "low"} referrerPolicy="no-referrer" onError={onFailure}
        style={{ width: "100%", height: "100%", objectFit: "contain" }} />
    </button>
    {requested && createPortal(<div data-testid="official-image-hover" aria-hidden={!preview} onPointerEnter={clearTimers} onPointerLeave={leaveHover}
      style={{ position: "fixed", zIndex: 45, display: preview ? "flex" : "none", flexDirection: "column", ...(preview ?? {}),
        padding: 8, background: "#fff", border: "1px solid #dce2e8", borderRadius: 8, boxShadow: "0 8px 28px #13283c26", overflow: "hidden" }}>
      <button type="button" onClick={openViewer} tabIndex={preview ? 0 : -1} aria-label={`查看 ${source.alt}`}
        style={{ display: "flex", flex: "1 1 0", minHeight: 0, border: 0, padding: 0, background: "#f8fafc", cursor: "zoom-in" }}>
        <img src={source.zoom} alt={source.alt} width={320} height={320} decoding="async" referrerPolicy="no-referrer" onError={onFailure}
          style={{ width: "100%", height: "100%", objectFit: "contain" }} />
      </button>
      <p style={{ margin: "6px 0 0", fontSize: 11, lineHeight: "16px", color: "#697684", flexShrink: 0, overflowWrap: "anywhere" }}>{source.alt}</p>
    </div>, document.body)}
    {viewer && <ImageLightbox open={viewer} src={source.zoom} alt={source.alt} onOpenChange={changeViewer}
      onRequestRefresh={async () => { onFailure(); return null; }} />}
  </>;
}
