import * as React from "react";
import { Link } from "wouter";
import MallNav from "@/components/MallNav";
import { OfficialMallCheckoutResults } from "@/components/OfficialMallCheckoutResults";
import { OfficialMallSearchResults, isOfficialDetailPublicId, type OfficialMallSearchResultsProps } from "@/components/OfficialMallSearchResults";

export type OfficialProductDetailProps = {
  publicId: string;
  /** Optional presentation seam; the native host passes its EXISTING official cart callback. */
  onAddOfficialDraft?: OfficialMallSearchResultsProps["onAddOfficialDraft"];
  officialCheckoutReady?: boolean;
};
export type OfficialProductDetailDependencies = {
  React: Pick<typeof React, "createElement" | "Fragment">;
  MallNav: typeof MallNav;
  Link: typeof Link;
  /** Checkout-wrapped existing results; no provider, client or mutation is created here. */
  OfficialMallCheckoutResults: typeof OfficialMallCheckoutResults;
  OfficialMallSearchResults: typeof OfficialMallSearchResults;
};

/** Native hosts inject their existing navigation, router and official cart-bound result component. */
export function createOfficialProductDetail(deps: OfficialProductDetailDependencies) {
  const React = deps.React;
  return function OfficialProductDetail({ publicId, onAddOfficialDraft, officialCheckoutReady }: OfficialProductDetailProps) {
    const Results = onAddOfficialDraft === undefined ? deps.OfficialMallCheckoutResults : deps.OfficialMallSearchResults;
    return <main className="opd-root" data-source-type="official_mall">
      <deps.MallNav />
      <nav className="opd-crumb" aria-label="面包屑">
        <deps.Link href="/">首页</deps.Link><span>/</span><deps.Link href="/search">元器件搜索</deps.Link><span>/</span><span>自营商品详情</span>
      </nav>
      <div className="opd-content">
        {isOfficialDetailPublicId(publicId)
          ? <Results key={publicId} keyword="" brand="all" sort="default" viewMode="list" detailPublicId={publicId} presentation="detail"
              onAddOfficialDraft={onAddOfficialDraft} officialCheckoutReady={officialCheckoutReady} />
          : <div className="opd-empty" role="alert">自营商品编号无效，<deps.Link href="/search">去搜索其他元器件</deps.Link></div>}
      </div>
      <style>{officialProductDetailStyles}</style>
    </main>;
  };
}
export default createOfficialProductDetail({ React, MallNav, Link, OfficialMallCheckoutResults, OfficialMallSearchResults });

export const officialProductDetailStyles = `
.opd-root{font-family:-apple-system,BlinkMacSystemFont,'PingFang SC','Microsoft YaHei',sans-serif;background:#f5f5f5;color:#1a1a1a;font-size:13px;min-height:100vh;display:flex;flex-direction:column}
.opd-root .opd-crumb{padding:12px 24px 0;font-size:12px;color:#999;display:flex;flex-wrap:wrap;gap:6px;align-items:center}.opd-root .opd-crumb a{color:#666;text-decoration:none}.opd-root .opd-crumb a:hover{color:#185fa5}.opd-root .opd-crumb>span:last-child{color:#1a1a1a;font-weight:600}
.opd-root .opd-content{margin:12px 24px 24px;min-width:0}.opd-root .opd-empty,.opd-root .opd-content>.omr-state{background:#fff;border:1px solid #eee;border-radius:10px;padding:40px 20px;text-align:center;color:#77818c}.opd-root .opd-empty a,.opd-root .omr-state a{color:#185fa5}
@media(max-width:960px){.opd-root .opd-crumb{padding:10px 12px 0}.opd-root .opd-content{margin:12px}}
`;
