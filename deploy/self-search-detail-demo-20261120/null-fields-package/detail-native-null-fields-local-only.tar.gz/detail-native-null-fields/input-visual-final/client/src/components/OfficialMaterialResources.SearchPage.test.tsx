// @vitest-environment jsdom
import * as React from "react";
import { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { readFileSync } from "node:fs";
const mocks = vi.hoisted(() => ({
  auth: { user: { id: 1 } as { id: number } | null, loading: false, isAuthenticated: true },
  resources: vi.fn(), states: vi.fn(), mutate: vi.fn(), login: vi.fn(), list: vi.fn(),
  toast: { success: vi.fn(), error: vi.fn() },
}));
vi.mock("@/_core/hooks/useAuth", () => ({ useAuth: () => mocks.auth }));
vi.mock("@/const", () => ({ startLogin: mocks.login }));
vi.mock("sonner", () => ({ toast: mocks.toast }));
vi.mock("@/lib/trpc", () => ({ trpc: { useUtils: () => ({ client: { officialMall: { list: { query: mocks.list } }, officialMaterial: {
  resources: { query: mocks.resources }, favoriteStates: { query: mocks.states }, setFavorite: { mutate: mocks.mutate },
} } }) } }));
import OfficialMaterialResources, { selectOfficialCoreParameters } from "./OfficialMaterialResources";
import { OfficialMallSearchResults } from "./OfficialMallSearchResults";
import { useOfficialMaterial } from "@/hooks/useOfficialMaterial";
import { safeOfficialDatasheetUrl, OFFICIAL_MATERIAL_FAVORITES_QUERY_ROOT, OFFICIAL_MATERIAL_FAVORITES_CHANGED_EVENT } from "@/lib/officialMaterialClient";
import { AUTH_SESSION_CLEARED_EVENT } from "@/lib/authSessionEvents";
import type { OfficialMaterialResource } from "@shared/officialMaterial";
(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
const id = "OM_11111111-1111-4111-8111-111111111111";
const parameters = [
  { name: "CAN", value: "1" }, { name: "CPU内核", value: "Cortex-M3" },
  { name: "主频", value: "72 MHz" }, { name: "Flash", value: "128 KB" },
  { name: "RAM", value: "20 KB" }, { name: "I2C", value: "2" },
  { name: "USB", value: "1" }, { name: "空字段", value: "" },
];
const resource: OfficialMaterialResource = {
  publicId: id, revision: 1, partNumber: "STM32F103CBT6", brand: "ST", pkg: "LQFP48",
  category: null, description: null, parameters, datasheetUrl: "https://www.st.com/resource/en/datasheet/stm32f103cb.pdf",
};
let host: HTMLDivElement, root: Root, queryClient: QueryClient;
let serverFavorite = false;
async function flush() { await act(async () => { await new Promise(resolve => setTimeout(resolve, 25)); }); }
async function render(element: React.ReactNode) {
  await act(async () => { root.render(<QueryClientProvider client={queryClient}>{element}</QueryClientProvider>); });
  await flush();
}
function button(text: string) {
  const result = Array.from(host.querySelectorAll("button")).find(node => node.textContent?.includes(text));
  if (!result) throw new Error(`Missing button: ${text}`);
  return result;
}
function Harness({ revision = 1 }: { revision?: number }) {
  const material = useOfficialMaterial([{ publicId: id, revision }]);
  return <div ref={material.rootRef}><article data-official-public-id={id}>
    <OfficialMaterialResources publicId={id} partNumber={resource.partNumber} resource={material.resources.get(id)}
      authenticated={material.authenticated} favorite={material.favorites.get(id)} pending={material.pending.has(id)}
      error={material.resourceErrors.get(id) || material.favoriteError} resourceError={material.resourceErrors.get(id) ?? null} onFavorite={() => void material.toggleFavorite(id)} />
  </article><output>{material.authenticated ? "authenticated" : "anonymous"}</output></div>;
}
beforeEach(() => {
  vi.clearAllMocks();
  vi.stubGlobal("React", React);
  mocks.auth = { user: { id: 1 }, loading: false, isAuthenticated: true };
  serverFavorite = false;
  mocks.resources.mockImplementation(async () => ({ items: [resource] }));
  mocks.states.mockImplementation(async () => ({ items: [{ publicId: id, favorite: mocks.auth.user?.id === 1 && serverFavorite }] }));
  mocks.mutate.mockImplementation(async ({ favorite }: { favorite: boolean }) => { serverFavorite = favorite; return { publicId: id, favorite }; });
  localStorage.clear();
  host = document.createElement("div"); document.body.append(host); root = createRoot(host);
  queryClient = new QueryClient({ defaultOptions: { queries: { retry: false, gcTime: 0 } } });
});
afterEach(() => { act(() => root.unmount()); queryClient.clear(); host.remove(); vi.unstubAllGlobals(); });

describe("official material resources synthetic DOM", () => {
  it("shows five real priority parameters directly and discloses only extras inside the card with stable focus", async () => {
    await render(<OfficialMaterialResources publicId={id} partNumber={resource.partNumber} resource={resource}
      authenticated={false} pending={false} onFavorite={() => {}} />);
    expect(host.querySelectorAll(".omr-core-parameters>div")).toHaveLength(5);
    expect(selectOfficialCoreParameters(parameters).map(row => row.name)).toEqual(["CPU内核", "主频", "Flash", "RAM", "CAN"]);
    expect(host.querySelector(".omr-core-parameters")?.textContent).toContain("72 MHz");
    const trigger = button("…"); trigger.focus(); act(() => trigger.click());
    expect(host.querySelector('.omr-extra-parameters')?.children).toHaveLength(2);
    expect(host.querySelectorAll('dl>div')).toHaveLength(7); expect(document.activeElement).toBe(trigger);
    act(() => trigger.click());
    expect(host.querySelector<HTMLDListElement>('.omr-extra-parameters')?.hidden).toBe(true);
    expect(host.querySelector('[role="dialog"]')).toBeNull(); expect(document.activeElement).toBe(trigger);
  });
  it("hides missing and unsafe PDFs, keeps only truthful actions without persistent missing-data prose", async () => {
    for (const value of [null, "javascript:alert(1)", "http://example.com/a.pdf", "//evil.test/a.pdf", "https://user:pass@example.com/a.pdf", "https://a.test/\\evil.pdf", " https://a.test/a.pdf", "https://127.0.0.1/a.pdf", "https://192.168.1.2/a.pdf", "https://localhost/a.pdf", "https://example.com/private/a.pdf", "https://example.com/a.pdf?token=secret"]) {
      expect(safeOfficialDatasheetUrl(value)).toBeNull();
      await render(<OfficialMaterialResources publicId={id} partNumber={resource.partNumber}
        resource={{ ...resource, parameters: [], datasheetUrl: value }} authenticated={false} pending={false} onFavorite={() => {}} />);
      expect(host.querySelector("a")).toBeNull(); expect(host.querySelector("dl")).toBeNull();
      expect(host.textContent).not.toMatch(/暂无资料|更多参数/);
      expect(host.querySelector(".omr-parameter-state")?.textContent).toBe("暂无参数");
    }
    await render(<OfficialMaterialResources publicId={id} partNumber={resource.partNumber} resource={resource} authenticated={false} pending={false} onFavorite={() => {}} />);
    expect(host.querySelector("a")?.target).toBe("_blank"); expect(host.querySelector("a")?.rel).toBe("noopener noreferrer");
  });
  it("requests real server persistence once, changes star only on success and stores notification nonce only", async () => {
    let finish!: (value: { publicId: string; favorite: boolean }) => void;
    mocks.mutate.mockImplementation(() => new Promise(resolve => { finish = resolve; }));
    await render(<Harness />);
    const favorite = button("收藏"); expect(favorite.getAttribute("aria-pressed")).toBe("false");
    act(() => { favorite.click(); favorite.click(); });
    expect(mocks.mutate).toHaveBeenCalledTimes(1); expect(mocks.mutate).toHaveBeenCalledWith({ publicId: id, favorite: true });
    expect(favorite.getAttribute("aria-pressed")).toBe("false"); expect(mocks.toast.success).not.toHaveBeenCalled();
    serverFavorite = true;
    await act(async () => finish({ publicId: id, favorite: true })); await flush();
    expect(button("已收藏").getAttribute("aria-pressed")).toBe("true"); expect(mocks.toast.success).toHaveBeenCalledWith("已收藏");
    expect(localStorage.length).toBe(1); expect(localStorage.key(0)).toBe(OFFICIAL_MATERIAL_FAVORITES_CHANGED_EVENT);
    expect(localStorage.getItem(OFFICIAL_MATERIAL_FAVORITES_CHANGED_EVENT)).not.toContain(id);
    expect(queryClient.getQueryCache().findAll({ queryKey: [...OFFICIAL_MATERIAL_FAVORITES_QUERY_ROOT, "1"] }).length).toBeGreaterThan(0);
  });
  it("failed request never changes star or broadcasts false success", async () => {
    mocks.mutate.mockRejectedValue(new Error("offline")); await render(<Harness />);
    await act(async () => button("收藏").click()); await flush();
    expect(button("收藏").getAttribute("aria-pressed")).toBe("false"); expect(mocks.toast.success).not.toHaveBeenCalled();
    expect(mocks.toast.error).toHaveBeenCalledWith("收藏失败，请重试"); expect(localStorage.length).toBe(0);
  });
  it("fences late mutation on owner switch, clears star immediately on logout and opens existing login flow", async () => {
    let finish!: (value: { publicId: string; favorite: boolean }) => void;
    mocks.mutate.mockImplementation(() => new Promise(resolve => { finish = resolve; }));
    await render(<Harness />); act(() => button("收藏").click());
    mocks.auth = { user: { id: 2 }, loading: false, isAuthenticated: true }; await render(<Harness />);
    await act(async () => finish({ publicId: id, favorite: true })); await flush();
    expect(button("收藏").getAttribute("aria-pressed")).toBe("false"); expect(mocks.toast.success).not.toHaveBeenCalled();
    act(() => window.dispatchEvent(new Event(AUTH_SESSION_CLEARED_EVENT))); await flush();
    expect(host.querySelector("output")?.textContent).toBe("anonymous");
    act(() => button("收藏").click()); expect(mocks.login).toHaveBeenCalledTimes(1); expect(mocks.mutate).toHaveBeenCalledTimes(1);
  });
  it("rejects mismatched resource revisions without inventing parameters; failure is independent of buying", async () => {
    await render(<Harness revision={2} />); expect(host.querySelector(".omr-core-parameters")).toBeNull();
    expect(mocks.resources).toHaveBeenCalledWith({ publicIds: [id] }, expect.objectContaining({ signal: expect.any(AbortSignal) }));
    mocks.resources.mockRejectedValue(new Error("offline")); await render(<Harness revision={3} />);
    expect(host.textContent).toContain("资料暂不可用"); expect(host.querySelector(".omr-core-parameters")).toBeNull();
  });
  it("reacts to cross-tab nonce by refetching server state without trusting stored favorite values", async () => {
    await render(<Harness />); const before = mocks.states.mock.calls.length; serverFavorite = true;
    act(() => window.dispatchEvent(new StorageEvent("storage", { key: OFFICIAL_MATERIAL_FAVORITES_CHANGED_EVENT, newValue: "nonce-only" })));
    await flush(); expect(mocks.states.mock.calls.length).toBeGreaterThan(before); expect(button("已收藏")).toBeTruthy();
  });
  it("batches only visible deduplicated official IDs with a strict twenty-ID RPC limit", async () => {
    const ids = Array.from({ length: 47 }, (_, index) => `OM_${String(index).padStart(8, "0")}-1111-4111-8111-111111111111`);
    vi.stubGlobal("IntersectionObserver", class {
      callback: IntersectionObserverCallback;
      constructor(callback: IntersectionObserverCallback) { this.callback = callback; }
      observe(target: Element) { queueMicrotask(() => this.callback([{ target, isIntersecting: true } as IntersectionObserverEntry], this as unknown as IntersectionObserver)); }
      disconnect() {}
    });
    mocks.resources.mockResolvedValue({ items: [] }); mocks.states.mockResolvedValue({ items: [] });
    function Many() {
      const material = useOfficialMaterial(ids.concat(ids).map(publicId => ({ publicId, revision: 1 })));
      return <div ref={material.rootRef}>{ids.map(publicId => <article key={publicId} data-official-public-id={publicId} />)}</div>;
    }
    await render(<Many />); await flush();
    const batches = mocks.resources.mock.calls.map(call => (call[0] as { publicIds: string[] }).publicIds);
    expect(batches.map(batch => batch.length)).toEqual([20, 20, 7]);
    expect(Array.from(new Set(batches.flat()))).toHaveLength(47);
  });
  it("does not accept an old mutation after owner A→B→A", async () => {
    let finish!: (value: { publicId: string; favorite: boolean }) => void;
    mocks.mutate.mockImplementation(() => new Promise(resolve => { finish = resolve; }));
    await render(<Harness />); act(() => button("收藏").click());
    mocks.auth = { user: { id: 2 }, loading: false, isAuthenticated: true }; await render(<Harness />);
    mocks.auth = { user: { id: 1 }, loading: false, isAuthenticated: true }; await render(<Harness />);
    await act(async () => finish({ publicId: id, favorite: true })); await flush();
    expect(button("收藏").getAttribute("aria-pressed")).toBe("false"); expect(mocks.toast.success).not.toHaveBeenCalled();
  });
  it("keeps existing purchase zones and callbacks enabled even when resource requests fail", async () => {
    const item = { sourceType: "official_mall" as const, publicId: id, revision: 1, partNumber: "SYNTH", brand: "ST", pkg: "LQFP48",
      dateCode: "2026", qtyOnSale: 100, qtyStock: 100, qtyOrder: 0, moq: 10, spq: 5, leadTime: "3天", priceEx: "1.230000", taxIncluded: true,
      ladderPrices: [{ minQty: 10, price: "1.230000" }], publishedAt: "2026-01-01T00:00:00.000Z",
      technicalResource: { state: "unavailable", parameterVersion: null, resource: null } };
    mocks.list.mockResolvedValue({ items: [item], total: 1, page: 1, pageSize: 100 });
    mocks.resources.mockRejectedValue(new Error("offline")); const add = vi.fn();
    await render(<OfficialMallSearchResults keyword="SYNTH" brand="all" sort="default" viewMode="list" officialCheckoutReady onAddOfficialDraft={add} />); await flush();
    expect(host.textContent).toContain("参数暂不可用"); expect(mocks.resources).not.toHaveBeenCalled();
    expect(Array.from(host.querySelectorAll("[data-omr-zone]")).map(node => node.getAttribute("data-omr-zone"))).toEqual(["info", "image", "parameters", "procurement", "tiers", "order", "contact"]);
    expect(host.querySelector(".omr-parameter-state")?.closest(".omr-parameter-panel")).not.toBeNull();
    expect(host.querySelector(".omr-material-utilities .omr-more-parameters")).toBeNull();
    expect(host.querySelector(".omr-contact")?.parentElement?.className).toBe("omr-order");
    expect(host.querySelector(".omr-order")?.parentElement?.className).toBe("omr-procurement");
    expect(button("加入购物车").disabled).toBe(false); act(() => button("加入购物车").click()); expect(add).toHaveBeenCalledWith(item, 10);
    expect(host.querySelector('.omr-contact a')?.getAttribute("href")).toBe("/chat?service=1");
  });
  it("uses search-only parameter presentation and scoped procurement layout without touching merchant layout or callbacks", () => {
    const card = readFileSync("client/src/components/OfficialMallSearchResults.tsx", "utf8");
    // Detail has its own info/image branches; assert the unchanged search branch plus shared procurement.
    const searchCard = card.slice(card.indexOf('<div className="omr-info omr-info-search"'), card.indexOf("const officialSearchStyles"));
    expect(Array.from(searchCard.matchAll(/data-omr-zone="([^"]+)"/g)).map(match => match[1])).toEqual(["info", "image", "procurement", "tiers", "order", "contact"]);
    expect(card).toContain('<OfficialMaterialResources presentation={detail ? "detail" : "search"}');
    expect(card.match(/onFavorite=\{\(\) => void materials\.toggleFavorite\(item\.publicId\)\}/g)).toHaveLength(1);
    expect(card).toContain(".omr-root .omr-card .omr-procurement{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.05fr)");
    expect(card).toContain("@media(max-width:900px)"); expect(card).toContain("@media(max-width:600px)");
    expect(card).toContain(".omr-root .omr-card.omr-tiers-expanded .omr-prices,.omr-root .omr-card.omr-tiers-expanded .omr-order{justify-content:flex-start}");
    expect(card).toContain("<OfficialSearchImage item={item} priority={priority} />");
    expect(card).toContain("priority={index < 2}"); expect(card).toContain("onAddOfficialDraft?.(item, quantity)"); expect(card).toContain('href="/chat?service=1"');
    const search = readFileSync("client/src/pages/SearchPage.tsx", "utf8");
    expect(search).toContain(".srch-root>.result-list,.srch-root>.result-grid{padding-left:0;padding-right:0}");
    expect(search).toContain(".srch-root>.result-list,.srch-root>.result-grid,.srch-root>.omr-root{padding-left:12px;padding-right:12px}");
    expect(search).toContain("grid-template-columns:repeat(6,minmax(0,1fr))"); expect(search).toContain("<SupplierQQContact");
    expect(search).not.toContain("useOfficialMaterial");
  });
});
