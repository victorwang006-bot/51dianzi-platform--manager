import type {
  OfficialMaterialResourcesResult, OfficialMaterialFavoriteStatesResult,
  OfficialMaterialSetFavoriteResult, OfficialMaterialFavoritesResult,
  OfficialMaterialFavoriteCountResult, OfficialMaterialPublicIdsInput,
  OfficialMaterialSetFavoriteInput, OfficialMaterialFavoritesInput,
  OfficialMaterialResource,
} from "@shared/officialMaterial";
import type { QueryClient } from "@tanstack/react-query";

export type OfficialMaterialQueryOptions = { signal?: AbortSignal; context?: { skipBatch?: boolean } };
type Query<I, O> = { query: (input: I, options?: OfficialMaterialQueryOptions) => Promise<O> };
/** Narrow adapter for trpc.useUtils().client. Always inherits the App transport/session. */
export type OfficialMaterialClient = {
  officialMaterial: {
    resources: Query<OfficialMaterialPublicIdsInput, OfficialMaterialResourcesResult>;
    favoriteStates: Query<OfficialMaterialPublicIdsInput, OfficialMaterialFavoriteStatesResult>;
    setFavorite: { mutate: (input: OfficialMaterialSetFavoriteInput) => Promise<OfficialMaterialSetFavoriteResult> };
    favorites: Query<OfficialMaterialFavoritesInput, OfficialMaterialFavoritesResult>;
    favoriteCount: { query: (input?: undefined, options?: OfficialMaterialQueryOptions) => Promise<OfficialMaterialFavoriteCountResult> };
  };
};
export const OFFICIAL_MATERIAL_FAVORITES_QUERY_ROOT = ["officialMaterial", "favorites"] as const;
export const OFFICIAL_MATERIAL_FAVORITES_CHANGED_EVENT = "51dianzi:official-material-favorites-changed:v1";
export const OFFICIAL_MATERIAL_RESOURCES_QUERY_ROOT = ["officialMaterial", "resources"] as const;
export type OfficialMaterialIdentity = { publicId: string; revision: number };
export type OfficialMaterialResourceUnavailable = OfficialMaterialIdentity & {
  reason: "missing" | "invalid-response" | "error" | "timeout" | "aborted";
  message: string;
};
/** No favorite/owner state belongs in this seed or the public resource cache. */
export type OfficialMaterialResourceSeed = {
  resourceSeed: readonly OfficialMaterialResource[];
  unavailable: readonly OfficialMaterialResourceUnavailable[];
  errors: readonly OfficialMaterialResourceUnavailable[];
  /** Inline snapshots are authoritative for this quotation, even over a fresh legacy cache. */
  source?: "inline";
  parameterVersions?: ReadonlyMap<string, string | null>;
};
export const OFFICIAL_MATERIAL_RESOURCE_FRESH_MS = 5 * 60_000;
const RESOURCE_TIMEOUT_MS = 8_000;
export const officialMaterialResourceItemKey = ({ publicId, revision }: OfficialMaterialIdentity) =>
  [...OFFICIAL_MATERIAL_RESOURCES_QUERY_ROOT, "public-item-v2", publicId, revision] as const;
export function officialMaterialResourceBatchKey(identities: readonly OfficialMaterialIdentity[]) {
  if (identities.length > 20) throw new Error("资料批次不能超过20项");
  return [...OFFICIAL_MATERIAL_RESOURCES_QUERY_ROOT, "public-batch-v2",
    identities.map(row => [row.publicId, row.revision] as const).sort((a, b) => a[0].localeCompare(b[0]) || a[1] - b[1])] as const;
}
/** Explicit projection strips unexpected owner/favorite fields from transport responses. */
function canonicalResource(value: unknown): OfficialMaterialResource | undefined {
  if (!value || typeof value !== "object") return;
  const row = value as OfficialMaterialResource;
  if (typeof row.publicId !== "string" || !Number.isInteger(row.revision)
    || ![row.partNumber, row.brand, row.pkg].every(field => typeof field === "string")
    || ![row.category, row.description, row.datasheetUrl].every(field => field === null || typeof field === "string")
    || !Array.isArray(row.parameters) || !row.parameters.every(parameter => parameter
      && typeof parameter.name === "string" && typeof parameter.value === "string")) return;
  return {
    publicId: row.publicId, revision: row.revision, partNumber: row.partNumber, brand: row.brand, pkg: row.pkg,
    category: row.category, description: row.description, datasheetUrl: row.datasheetUrl,
    parameters: row.parameters.map(({ name, value }) => ({ name, value })),
  };
}
/** Optional during a rolling deployment; never assume legacy list responses contain parameters. */
export type OfficialInlineTechnicalResource = {
  state: "ready" | "missing" | "unavailable";
  parameterVersion: string | null;
  resource: OfficialMaterialResource | null;
};
type InlineIdentity = OfficialMaterialIdentity & { partNumber: string; brand: string; pkg: string; technicalResource?: OfficialInlineTechnicalResource };
/** No RPC, cache fallback, favorite state or inferred specs: every displayed page seeds every item. */
export function inlineOfficialMaterialResourceSeed(items: readonly InlineIdentity[]): OfficialMaterialResourceSeed {
  const resourceSeed: OfficialMaterialResource[] = [], unavailable: OfficialMaterialResourceUnavailable[] = [];
  const parameterVersions = new Map<string, string | null>();
  for (const item of items) {
    const technical = item.technicalResource;
    let message = "参数暂不可用，请稍后重试", reason: OfficialMaterialResourceUnavailable["reason"] = "error";
    if (!technical) {
      message = "当前服务未提供同步参数，请稍后重试";
      reason = "invalid-response";
    } else if (!["ready", "missing", "unavailable"].includes(technical.state)
      || !(technical.parameterVersion === null || typeof technical.parameterVersion === "string" && technical.parameterVersion.trim().length > 0)) {
      message = "参数响应无效，请稍后重试";
      reason = "invalid-response";
    } else {
      const row = canonicalResource(technical.resource);
      // Exact full product identity, not a fuzzy PN/brand match or publicId/revision alone.
      const matches = row && row.publicId === item.publicId && row.revision === item.revision
        && row.partNumber === item.partNumber && row.brand === item.brand && row.pkg === item.pkg;
      parameterVersions.set(item.publicId, technical.parameterVersion);
      if (technical.state === "missing" && technical.resource === null) {
        unavailable.push({ publicId: item.publicId, revision: item.revision, reason: "missing", message: "暂无参数" });
        continue;
      }
      if ((technical.state === "ready" || technical.state === "missing") && technical.parameterVersion !== null && matches
        && (technical.state !== "missing" || row.parameters.length === 0)) {
        resourceSeed.push(row);
        continue;
      }
      if (technical.state !== "unavailable" || technical.resource !== null) {
        message = "参数标识或版本不匹配，请稍后重试";
        reason = "invalid-response";
      }
    }
    unavailable.push({ publicId: item.publicId, revision: item.revision, reason, message });
  }
  return { source: "inline", resourceSeed, unavailable, errors: unavailable.filter(row => row.reason !== "missing"), parameterVersions };
}
export function getFreshOfficialMaterialResource(queryClient: QueryClient, identity: OfficialMaterialIdentity) {
  const state = queryClient.getQueryState<OfficialMaterialResource>(officialMaterialResourceItemKey(identity));
  if (!state || state.isInvalidated || !state.dataUpdatedAt
    || Date.now() - state.dataUpdatedAt >= OFFICIAL_MATERIAL_RESOURCE_FRESH_MS) return;
  const row = canonicalResource(state.data);
  return row?.publicId === identity.publicId && row.revision === identity.revision ? row : undefined;
}
class ResourceRequestError extends Error {
  constructor(readonly reason: OfficialMaterialResourceUnavailable["reason"], message: string) { super(message); }
}
// Classification only: the native TanStack CancelledError uses this public message.
// Do not add a second cancellation class or a new unverified singleton bridge export.
const cancelledResourceRequest = (error: unknown) => error instanceof Error && error.message === "CancelledError";
/** A consumer can stop waiting, but cannot cancel a shared fetchQuery for another consumer. */
function waitWithSignal<T>(promise: Promise<T>, signal?: AbortSignal): Promise<T> {
  if (!signal) return promise;
  return new Promise((resolve, reject) => {
    const abort = () => reject(signal.reason instanceof ResourceRequestError ? signal.reason
      : new ResourceRequestError("aborted", "资料请求已取消"));
    signal.addEventListener("abort", abort, { once: true });
    // Attach even to an already-aborted wait: an abort-ignoring transport may reject later.
    promise.then(value => { signal.removeEventListener("abort", abort); resolve(value); },
      error => { signal.removeEventListener("abort", abort); reject(error); });
    if (signal.aborted) { signal.removeEventListener("abort", abort); abort(); }
  });
}
/** First-paint prefetch: at most 100 identities, five concurrent twenty-ID RPCs.
 * Pass utils.client from the existing App and its existing QueryClient. Consumer signal only fences
 * its wait; logout cancel/remove cancels the shared QueryClient signal and prevents late backfill.
 */
export async function prefetchOfficialMaterialResources(
  queryClient: QueryClient, client: OfficialMaterialClient, identities: readonly OfficialMaterialIdentity[],
  options: { signal?: AbortSignal } = {},
): Promise<OfficialMaterialResourceSeed> {
  const unique = Array.from(new Map(identities.map(row => [row.publicId, row])).values()).slice(0, 100)
    .sort((a, b) => a.publicId.localeCompare(b.publicId));
  const resourceSeed: OfficialMaterialResource[] = [], unavailable: OfficialMaterialResourceUnavailable[] = [];
  const misses: OfficialMaterialIdentity[] = [];
  for (const identity of unique) {
    const cached = getFreshOfficialMaterialResource(queryClient, identity);
    if (cached) resourceSeed.push(cached); else misses.push(identity);
  }
  const batches: OfficialMaterialIdentity[][] = [];
  for (let offset = 0; offset < misses.length; offset += 20) batches.push(misses.slice(offset, offset + 20));
  await Promise.all(batches.map(async batch => {
    try {
      if (options.signal?.aborted) throw new ResourceRequestError("aborted", "资料请求已取消");
      const queryKey = officialMaterialResourceBatchKey(batch);
      const result = await waitWithSignal(queryClient.fetchQuery({
        queryKey, staleTime: 0, gcTime: OFFICIAL_MATERIAL_RESOURCE_FRESH_MS, retry: false,
        // This queryFn intentionally never captures a page's current()/owner/generation fence.
        queryFn: async ({ signal }): Promise<OfficialMaterialResourcesResult> => {
          const query = queryClient.getQueryCache().find({ queryKey, exact: true });
          const controller = new AbortController();
          const abort = () => controller.abort();
          signal.addEventListener("abort", abort, { once: true });
          if (signal.aborted) abort();
          const timer = setTimeout(() => controller.abort(new ResourceRequestError("timeout", "资料加载超时，请重试")), RESOURCE_TIMEOUT_MS);
          try {
            const response = await waitWithSignal(client.officialMaterial.resources.query(
              { publicIds: batch.map(row => row.publicId) }, { signal: controller.signal, context: { skipBatch: true } },
            ), controller.signal);
            if (controller.signal.aborted || signal.aborted
              || queryClient.getQueryCache().find({ queryKey, exact: true }) !== query) {
              throw new ResourceRequestError("aborted", "资料请求已取消");
            }
            const expected = new Map(batch.map(row => [row.publicId, row.revision]));
            const seen = new Set<string>(), items: OfficialMaterialResource[] = [];
            if (!response || !Array.isArray(response.items)) throw new ResourceRequestError("invalid-response", "资料响应无效，请重试");
            for (const value of response.items) {
              const row = canonicalResource(value);
              if (!row || seen.has(row.publicId) || expected.get(row.publicId) !== row.revision) {
                throw new ResourceRequestError("invalid-response", "资料标识或版本不匹配，请重试");
              }
              seen.add(row.publicId); items.push(row);
            }
            // Only real canonical successes are cached, including legitimate parameters: [].
            // No caller continuation writes seeds back after cancellation/removal.
            for (const row of items) {
              // A synchronous cache subscriber can clear/logout between individual cache writes.
              if (controller.signal.aborted || signal.aborted
                || queryClient.getQueryCache().find({ queryKey, exact: true }) !== query) {
                throw new ResourceRequestError("aborted", "资料请求已取消");
              }
              queryClient.setQueryData(officialMaterialResourceItemKey(row), row);
            }
            return { items };
          } catch (error) {
            if (controller.signal.aborted) {
              throw controller.signal.reason instanceof ResourceRequestError ? controller.signal.reason
                : new ResourceRequestError("aborted", "资料请求已取消");
            }
            throw error;
          } finally {
            clearTimeout(timer); signal.removeEventListener("abort", abort);
          }
        },
      }), options.signal);
      if (options.signal?.aborted) throw new ResourceRequestError("aborted", "资料请求已取消");
      resourceSeed.push(...result.items);
      for (const identity of batch) if (!result.items.some(row => row.publicId === identity.publicId && row.revision === identity.revision)) {
        unavailable.push({ ...identity, reason: "missing", message: "资料暂不可用" });
      }
    } catch (error) {
      const reason = error instanceof ResourceRequestError ? error.reason : cancelledResourceRequest(error) ? "aborted" : "error";
      const message = error instanceof ResourceRequestError ? error.message
        : reason === "aborted" ? "资料请求已取消" : officialMaterialErrorMessage(error, "资料暂不可用，请重试");
      unavailable.push(...batch.map(identity => ({ ...identity, reason, message })));
    }
  }));
  resourceSeed.sort((a, b) => a.publicId.localeCompare(b.publicId));
  unavailable.sort((a, b) => a.publicId.localeCompare(b.publicId));
  return { resourceSeed, unavailable, errors: unavailable.filter(row => row.reason !== "missing") };
}
/** Storage carries an invalidation nonce only, never favorite data or an owner identity. */
export function notifyOfficialMaterialFavoritesChanged(queryClient: QueryClient): void {
  void queryClient.invalidateQueries({ queryKey: OFFICIAL_MATERIAL_FAVORITES_QUERY_ROOT });
  window.dispatchEvent(new Event(OFFICIAL_MATERIAL_FAVORITES_CHANGED_EVENT));
  try {
    localStorage.setItem(OFFICIAL_MATERIAL_FAVORITES_CHANGED_EVENT, `${Date.now()}:${Math.random()}`);
  } catch { /* Storage can be disabled. Server persistence remains authoritative. */ }
}
/** A PDF action must never turn a dictionary URL into script, local-file or credential navigation. */
export function safeOfficialDatasheetUrl(value: unknown): string | null {
  if (typeof value !== "string" || value !== value.trim() || value.length > 2048 || /[\s\u0000-\u001f\u007f\\]/.test(value)) return null;
  try {
    const url = new URL(value);
    if (url.protocol !== "https:" || !url.hostname || url.username || url.password || (url.port && url.port !== "443")) return null;
    const host = url.hostname.toLowerCase().replace(/^\[|\]$/g, "").replace(/\.$/, "");
    if (!host.includes(".") || host.includes(":") || /(?:^|\.)(?:localhost|local|internal|lan|home|test|invalid)$/.test(host)) return null;
    if (/^\d+\.\d+\.\d+\.\d+$/.test(host)) {
      const [a, b] = host.split(".").map(Number);
      if (a === 0 || a === 10 || a === 127 || a === 169 && b === 254 || a === 172 && b >= 16 && b <= 31
        || a === 192 && (b === 168 || b === 0) || a === 100 && b >= 64 && b <= 127
        || a === 198 && (b === 18 || b === 19 || b === 51) || a === 203 && b === 0 || a >= 224) return null;
    }
    if (/(?:^|\/)(?:private|internal|supplier[-_]?photos?)(?:\/|$)/i.test(decodeURIComponent(url.pathname))) return null;
    if (Array.from(url.searchParams.keys()).some(key => /token|secret|signature|credential|password|authorization|api[-_]?key/i.test(key))) return null;
    return value;
  } catch { return null; }
}
export function officialMaterialErrorMessage(error: unknown, fallback = "操作失败，请重试"): string {
  const data = error && typeof error === "object" && "data" in error ? error.data : null;
  const code = data && typeof data === "object" && "code" in data ? data.code : null;
  if (code === "UNAUTHORIZED") return "请先登录";
  if (code === "FORBIDDEN") return "暂无访问权限";
  if (code === "TOO_MANY_REQUESTS") return "操作频繁，请稍后重试";
  return fallback;
}
