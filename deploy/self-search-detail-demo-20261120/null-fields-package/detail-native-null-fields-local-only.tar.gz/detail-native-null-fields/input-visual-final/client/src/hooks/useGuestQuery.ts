import { SEARCH_RESULT_TIMEOUT_MS, boundedSearchRequest } from "@/lib/searchResultCommit";
import { useEffect, useMemo, useRef, useState } from "react";
import { trpc } from "@/lib/trpc";

type Scope = { keyword: string; brand?: string; pkg?: string; category?: string; page?: number; pageSize?: number; sort?: "default" | "priceAsc" | "priceDesc" | "stockAsc" | "stockDesc" | "lead" };
type Grant = { message?: string; scope: string; token: string | null; status: "loading" | "ready" | "empty" | "login" | "error" };
type BeginResult = { token: string | null; found: boolean; expiresAt: number | null };
type Begin = (input: Scope & { module: "search" | "market"; actionId: string }, options?: BeginOptions) => Promise<BeginResult>;
// Only serialize cookie issuance. No 30-minute free result/grant reuse.
let issuanceQueue: Promise<unknown> = Promise.resolve();
// Single-use handoff from an explicit submit to the resulting render. Taking an
// entry removes it; a new submit, refresh, route or browser mount always charges.
const prepared = new Map<string, { result: BeginResult; createdAt: number }>();
function normalizeScope(scope: Scope, module: "search" | "market") {
  return { keyword: scope.keyword.normalize("NFKC").trim().toUpperCase(), brand: scope.brand || undefined, pkg: scope.pkg || undefined, category: scope.category || undefined, page: module === "search" ? scope.page ?? 1 : 1, pageSize: module === "search" ? scope.pageSize ?? 15 : 15, sort: module === "search" ? scope.sort ?? "default" : "default" as const };
}
function keyOf(scope: Scope, module: "search" | "market") {
  return JSON.stringify({ module, ...normalizeScope(scope, module) });
}
type BeginOptions = { signal: AbortSignal; context: { skipBatch: boolean } };
// A timed-out mutation may already have consumed quota or issued a cookie. Never
// resend it, and never issue another cookie while its outcome is uncertain.
let issuanceUncertain = false;
const uncertainError = () => new Error("游客授权结果待确认，为避免重复计额，请刷新页面后手动重试");
function issue(scope: Scope, module: "search" | "market", begin: Begin) {
  const controller = new AbortController();
  const deadline = Date.now() + SEARCH_RESULT_TIMEOUT_MS;
  const predecessor = issuanceQueue;
  const work = predecessor.catch(() => undefined).then(async () => {
    if (issuanceUncertain) throw uncertainError();
    if (controller.signal.aborted || Date.now() >= deadline) throw new Error("游客授权排队超时，请手动重试");
    const input = { ...normalizeScope(scope, module), module, actionId: crypto.randomUUID() };
    let settled = false;
    // The latch is set synchronously with abort, before the queue is released.
    const uncertain = () => { if (!settled) issuanceUncertain = true; };
    controller.signal.addEventListener("abort", uncertain, { once: true });
    try {
      const value = await begin(input, { signal: controller.signal, context: { skipBatch: true } });
      if (controller.signal.aborted) throw uncertainError();
      settled = true;
      return value;
    } finally { controller.signal.removeEventListener("abort", uncertain); }
  });
  const request = boundedSearchRequest(work, controller, Math.max(0, deadline - Date.now()));
  issuanceQueue = request.then(() => undefined, () => undefined);
  return request;
}

export async function requestGuestQuery(scope: Scope, module: "search" | "market", begin: Begin) {
  const result = await issue(scope, module, begin);
  prepared.set(keyOf(scope, module), { result, createdAt: Date.now() });
  if (prepared.size > 20) prepared.delete(prepared.keys().next().value!);
  return result;
}
export function useGuestQuery(scope: Scope, module: "search" | "market", enabled: boolean, onLogin: () => void) {
  const utils = trpc.useUtils();
  const loginRef = useRef(onLogin);
  loginRef.current = onLogin;
  const [generation, setGeneration] = useState(0);
  const [grant, setGrant] = useState<Grant | null>(null);
  const scopeKey = keyOf(scope, module);
  const activeScope = useMemo<Scope>(() => { const { module: _module, ...value } = JSON.parse(scopeKey); return value; }, [scopeKey]);
  const requestRef = useRef<{ key: string; promise: Promise<BeginResult> } | null>(null);
  useEffect(() => {
    if (!enabled || !activeScope.keyword) { setGrant(null); requestRef.current = null; return; }
    let cancelled = false;
    setGrant({ scope: scopeKey, token: null, status: "loading" });
    const requestKey = `${scopeKey}:${generation}`;
    if (requestRef.current?.key !== requestKey) {
      const handoff = prepared.get(scopeKey);
      prepared.delete(scopeKey);
      const promise = handoff && Date.now() - handoff.createdAt < 60_000
        ? Promise.resolve(handoff.result)
        : issue(activeScope, module, (input, options) => utils.client.guestQuery.begin.mutate(input, options));
      requestRef.current = { key: requestKey, promise };
    }
    void requestRef.current.promise.then(result => {
      if (cancelled) return;
      setGrant({ scope: scopeKey, token: result.token, status: result.token ? "ready" : "empty" });
    }).catch((error: { message?: string; data?: { code?: string } }) => {
      if (cancelled) return;
      const login = error.data?.code === "UNAUTHORIZED";
      setGrant({ scope: scopeKey, token: null, status: login ? "login" : "error", message: issuanceUncertain ? uncertainError().message : error.message });
      if (login) loginRef.current();
    });
    return () => { cancelled = true; };
  }, [scopeKey, module, enabled, activeScope, generation, utils.client]);
  const current = grant?.scope === scopeKey ? grant : null;
  return {
    token: current?.token ?? "",
    ready: enabled && current?.status === "ready",
    loading: enabled && Boolean(activeScope.keyword) && (!current || current.status === "loading"),
    blocked: current?.status === "login",
    empty: current?.status === "empty" || !activeScope.keyword,
    error: current?.status === "error",
    errorMessage: current?.message,
    retry: () => setGeneration(value => value + 1),
  };
}
