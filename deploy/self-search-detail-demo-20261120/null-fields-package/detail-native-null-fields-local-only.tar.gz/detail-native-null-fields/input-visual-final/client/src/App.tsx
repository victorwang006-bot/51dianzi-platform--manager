import "@/lib/pageMemory";
import RouteLoadingFrame from "./components/RouteLoadingFrame";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Suspense, useEffect } from "react";
import { Route, Switch, useLocation } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import PageAnalytics from "./components/PageAnalytics";
import { ThemeProvider } from "./contexts/ThemeContext";
import { importChatRoute } from "./routes/chatRoute";
import { importDataHubRoute } from "./routes/dataHubRoute";
import { importDemandCenterRoute } from "./routes/demandCenterRoute";
import { lazyRoute } from "./routes/lazyRoute";
import { importProductDetailRoute } from "./routes/productDetailRoute";
import { importModelAlternativeRoute } from "./routes/modelAlternativeRoute";
import { withEnterpriseWorkspaceRoute } from "./components/EnterpriseWorkspaceRoute";
import { resolveLegacyEnterpriseWorkbenchHref } from "./lib/mainNavigation";

const Home = lazyRoute(() => import("./pages/Home"));
const AnonLimitLoginGate = lazyRoute(() => import("./components/AnonLimitLoginGate"));
const IcpFooter = lazyRoute(() => import("./components/IcpFooter"));
const SearchPage = lazyRoute(() => import("./pages/SearchPage"));
const FactoryChannelPage = lazyRoute(() => import("./pages/FactoryChannelPage"));
const ModelAlternative = lazyRoute(importModelAlternativeRoute);
const ProductDetail = lazyRoute(importProductDetailRoute);
const AuthPage = lazyRoute(() => import("./pages/AuthPage"));
const AccountCenter = lazyRoute(() => import("./pages/AccountCenter"));
const CartPage = lazyRoute(() => import("./pages/CartPage"));
const OrderCenter = lazyRoute(() => import("./pages/OrderCenter"));
const CrmApply = lazyRoute(() => import("./pages/CrmApply"));
const AdminCompanyReview = lazyRoute(() => import("./pages/AdminCompanyReview"));
const AdminCoffeeVouchers = lazyRoute(() => import("./pages/AdminCoffeeVouchers"));
const EditInventory = withEnterpriseWorkspaceRoute(lazyRoute(() => import("./pages/EditInventory")));
const PublishInventory = withEnterpriseWorkspaceRoute(lazyRoute(() => import("./pages/PublishInventory")));
const MyInventory = withEnterpriseWorkspaceRoute(lazyRoute(() => import("./pages/MyInventory")));
const PublicCompanyProfile = lazyRoute(() => import("./pages/PublicCompanyProfile"));
const AgencyCertification = withEnterpriseWorkspaceRoute(lazyRoute(() => import("./pages/pageAgencyCertification")));
const AddUser = withEnterpriseWorkspaceRoute(lazyRoute(() => import("./pages/AddUser")));
const EnterpriseInquiryInbox = withEnterpriseWorkspaceRoute(lazyRoute(() => import("./pages/EnterpriseInquiryInbox")));
const OutboundManagement = lazyRoute(() => import("./pages/OutboundManagement"));
const ChatPage = lazyRoute(importChatRoute);
const DemandCenter = lazyRoute(importDemandCenterRoute);
const DemandPublish = lazyRoute(() => import("./pages/DemandPublish"));
const DemandQuotes = lazyRoute(() => import("./pages/DemandQuotes"));
const DataTong = lazyRoute(importDataHubRoute);
const DailyRecommend = lazyRoute(() => import("./pages/DailyRecommend"));
const ForumPage = lazyRoute(() => import("./pages/ForumPage"));
const BomWorkbench = lazyRoute(() => import("./pages/BomWorkbench"));
const RegisterAgreement = lazyRoute(() => import("./pages/RegisterAgreement"));
const EnterpriseServiceAgreement = lazyRoute(() => import("./pages/EnterpriseServiceAgreement"));
const PrivacyPolicy = lazyRoute(() => import("./pages/PrivacyPolicy"));
const ContractTemplate = lazyRoute(() => import("./pages/ContractTemplate"));
const ZhuomuniaoCooperation = lazyRoute(() => import("./pages/ZhuomuniaoCooperation"));
const NotFound = lazyRoute(() => import("./pages/NotFound"));

/** 旧路径 /data-tong 自动跳转到 /data-hub（保留查询参数） */
function DataTongRedirect() {
  const [, navigate] = useLocation();
  useEffect(() => {
    navigate(`/data-hub${window.location.search}`, { replace: true });
  }, [navigate]);
  return null;
}

/**
 * 已移走完整业务的旧前台链接只回本站保留的企业工作台，不跳员工后台。
 * 目标仍使用前台原会话、企业选择、资格和细粒度权限；旧查询全部丢弃。
 */
function LegacyEnterpriseWorkbenchRedirect() {
  const [location] = useLocation();
  useEffect(() => {
    const target = resolveLegacyEnterpriseWorkbenchHref(location, window.location.search);
    if (target) window.location.replace(target);
  }, [location]);
  return null;
}

/** 前台保留订单查看；完整订单处理仍由原组件的默认可写模式供后台原生复用。 */
function FrontReadOnlyOutboundManagement() {
  return <OutboundManagement readOnly />;
}

function RouteLoading() {
  return <RouteLoadingFrame />;
}

function Router() {
  return (
    <Suspense fallback={<RouteLoading />}>
      <Switch>
        <Route path={"/"} component={Home} />
        <Route path={"/search"} component={SearchPage} />
        <Route path={"/factory-inventory"} component={FactoryChannelPage} />
        <Route path={"/model-alternative"} component={ModelAlternative} />
        <Route path={"/product/:id"} component={ProductDetail} />
        <Route path={"/auth"} component={AuthPage} />
        <Route path={"/account"} component={AccountCenter} />
        <Route path={"/cart"} component={CartPage} />
        <Route path={"/orders"} component={OrderCenter} />
        <Route path={"/crm-apply"} component={CrmApply} />
        <Route path={"/admin/company-review"} component={AdminCompanyReview} />
        <Route path={"/platform-admin/coffee-vouchers"} component={AdminCoffeeVouchers} />
        <Route path={"/publish/:id/edit"} component={EditInventory} />
        <Route path={"/publish"} component={PublishInventory} />
        <Route path={"/inventory"} component={MyInventory} />
        <Route path={"/company/:supplierId"} component={PublicCompanyProfile} />
        <Route path={"/company"} component={LegacyEnterpriseWorkbenchRedirect} />
        <Route path={"/profile"} component={LegacyEnterpriseWorkbenchRedirect} />
        <Route path={"/certification"} component={AgencyCertification} />
        <Route path={"/add-user"} component={AddUser} />
        <Route path={"/inquiries"} component={EnterpriseInquiryInbox} />
        <Route path={"/inbound"} component={LegacyEnterpriseWorkbenchRedirect} />
        <Route path={"/outbound"} component={FrontReadOnlyOutboundManagement} />
        <Route path={"/customers/new"} component={LegacyEnterpriseWorkbenchRedirect} />
        <Route path={"/customers/:id"} component={LegacyEnterpriseWorkbenchRedirect} />
        <Route path={"/customers"} component={LegacyEnterpriseWorkbenchRedirect} />
        <Route path={"/customer-demands"} component={LegacyEnterpriseWorkbenchRedirect} />
        <Route path={"/procurement/demands"} component={LegacyEnterpriseWorkbenchRedirect} />
        <Route path={"/procurement/orders/quote"} component={LegacyEnterpriseWorkbenchRedirect} />
        <Route path={"/procurement/orders/accepted"} component={LegacyEnterpriseWorkbenchRedirect} />
        <Route path={"/procurement/orders/create"} component={LegacyEnterpriseWorkbenchRedirect} />
        <Route path={"/procurement/orders"} component={LegacyEnterpriseWorkbenchRedirect} />
        <Route path={"/sales-orders"} component={LegacyEnterpriseWorkbenchRedirect} />
        <Route path={"/stock-board"} component={LegacyEnterpriseWorkbenchRedirect} />
        <Route path={"/chat"} component={ChatPage} />
        <Route path={"/demand-center"} component={DemandCenter} />
        <Route path={"/demand-publish"} component={DemandPublish} />
        <Route path={"/demand-quotes"} component={DemandQuotes} />
        <Route path={"/data-hub"} component={DataTong} />
        <Route path={"/data-tong"} component={DataTongRedirect} />
        <Route path={"/recommendations"} component={DailyRecommend} />
        <Route path={"/forum"} component={ForumPage} />
        <Route path={"/bom"} component={BomWorkbench} />
        <Route path={"/register-agreement"} component={RegisterAgreement} />
        <Route path={"/enterprise-service-agreement"} component={EnterpriseServiceAgreement} />
        <Route path={"/privacy-policy"} component={PrivacyPolicy} />
        <Route path={"/contract-template"} component={ContractTemplate} />
        <Route path={"/cooperation/zhuomuniao"} component={ZhuomuniaoCooperation} />
        <Route path={"/404"} component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </Suspense>
  );
}

function RouteAwareIcpFooter() {
  const [location] = useLocation();
  if (location.split("?")[0] === "/forum") return null;
  return (
    <Suspense fallback={null}>
      <IcpFooter />
    </Suspense>
  );
}

function App() {
  useEffect(() => {
    document.getElementById("stage-a-app-shell")?.remove();

    // The deployed asset-only accelerator waits for actual first paint before warming.
    // It does not import route components or consume business-query quotas.
    window.dispatchEvent(new Event("d51:app-ready"));
  }, []);

  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <PageAnalytics />
          <Suspense fallback={null}>
            <AnonLimitLoginGate />
          </Suspense>
          <div className="flex min-h-screen flex-col bg-background">
            <div className="flex min-h-0 flex-1 flex-col">
              <Router />
            </div>
            <RouteAwareIcpFooter />
          </div>
          <Toaster position="top-center" richColors closeButton />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
