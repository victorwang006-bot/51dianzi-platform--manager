// @vitest-environment jsdom
import React, { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import OfficialMaterialResources, { isValidOfficialParameterText, selectOfficialCoreParameters, validOfficialParameters, type OfficialMaterialResourcesProps } from "./OfficialMaterialResources";
import type { OfficialMaterialResource } from "@shared/officialMaterial";
(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
const id = "OM_11111111-1111-4111-8111-111111111111";
const placeholders = ["", " ", "-", "--", "—", "–", " - — – ", "N/A", "n/a", "NA", "n.a.", "null", "NULL", "undefined", "暂无", "暂无参数", "暂无数据", "待确认", "未知", "未提供"];
const real = [
  { name: "温度", value: "-40 ～ 85 °C" }, { name: "工作电压", value: "0" },
  { name: "主频", value: "72 MHz" }, { name: "Flash", value: "128 KB" },
  { name: "RAM", value: "20 KB" }, { name: "失调", value: "-0.5 mV" },
  { name: "CAN", value: "1" }, { name: "说明", value: "N/A is literal prose, not a missing field" },
];
const parameters = [...placeholders.map((value, index) => ({ name: `占位${index}`, value })), { name: "—", value: "72 MHz" }, ...real];
const resource: OfficialMaterialResource = { publicId: id, revision: 1, partNumber: "SYNTH", brand: "ST", pkg: "QFN", category: null, description: null, parameters, datasheetUrl: null };
let host: HTMLDivElement, root: Root;
const props: OfficialMaterialResourcesProps = { publicId: id, partNumber: "SYNTH", authenticated: false, pending: false, onFavorite: vi.fn() };
async function render(patch: Partial<OfficialMaterialResourcesProps> = {}) { await act(async () => root.render(<OfficialMaterialResources {...props} {...patch} />)); }
function more() { return host.querySelector<HTMLButtonElement>(".omr-more-parameters") ?? undefined; }
beforeEach(() => { host = document.createElement("div"); document.body.append(host); root = createRoot(host); });
afterEach(() => { act(() => root.unmount()); host.remove(); });

describe("shared real-parameter filtering", () => {
  it.each(placeholders)("rejects whole-field placeholder %j", value => expect(isValidOfficialParameterText(value)).toBe(false));
  it.each(["0", " 0 ", "-1", "-0.5 mV", "-40 ～ 85 °C", "3–5 V", "—40", "null flag disabled", "暂无外设限制", "无"])("keeps real values and ranges %j", value => expect(isValidOfficialParameterText(value)).toBe(true));
  it("filters both labels and values, keeps priority ranking stable and caps summary at five valid rows", () => {
    expect(validOfficialParameters(parameters)).toEqual(real);
    expect(selectOfficialCoreParameters(parameters).map(row => row.name)).toEqual(["主频", "Flash", "RAM", "失调", "工作电压"]);
    expect(selectOfficialCoreParameters(parameters, 99)).toHaveLength(5);
    expect(selectOfficialCoreParameters(parameters, 2)).toHaveLength(2);
    expect(selectOfficialCoreParameters(parameters, -1)).toHaveLength(0);
  });
  it("uses the same filtered set for five-row summary and inline extras, preserving zero and negative ranges without duplicates", async () => {
    await render({ resource }); expect(host.querySelectorAll(".omr-core-parameters > div")).toHaveLength(5);
    expect(host.querySelector(".omr-core-parameters")?.textContent).toContain("工作电压0");
    expect(host.querySelector(".omr-core-parameters")?.textContent).not.toContain("占位"); expect(more()?.textContent).toBe("…");
    const trigger = more()!; trigger.focus(); act(() => trigger.click());
    expect(host.querySelectorAll(".omr-extra-parameters > div")).toHaveLength(3);
    expect(host.querySelectorAll("dl > div")).toHaveLength(8);
    expect(host.querySelector(".omr-extra-parameters")?.textContent).toContain("-40 ～ 85 °C");
    expect(host.querySelector('[role="dialog"],.omr-parameter-backdrop')).toBeNull();
    expect(trigger.getAttribute("aria-expanded")).toBe("true"); expect(document.activeElement).toBe(trigger);
    act(() => trigger.click()); expect(host.querySelector<HTMLDListElement>(".omr-extra-parameters")?.hidden).toBe(true);
    expect(trigger.getAttribute("aria-expanded")).toBe("false"); expect(document.activeElement).toBe(trigger);
  });
  it.each([0, 1, 4, 5])("hides the disclosure when there are only %i valid parameters", async count => {
    await render({ resource: { ...resource, parameters: real.slice(0, count) } });
    expect(more()).toBeUndefined(); expect(host.querySelector(".omr-extra-parameters")).toBeNull();
    expect(host.querySelectorAll(".omr-core-parameters > div")).toHaveLength(count);
  });
});

describe("truthful resource availability without invented specs", () => {
  it("distinguishes not-yet-loaded from loaded but placeholder-only resources", async () => {
    await render(); expect(host.querySelector(".omr-parameter-state")?.textContent).toContain("参数加载中");
    expect(host.textContent).not.toContain("暂无参数"); expect(host.querySelector("dl")).toBeNull(); expect(more()).toBeUndefined();
    await render({ resource: { ...resource, parameters: parameters.slice(0, placeholders.length + 1) } });
    expect(host.querySelector(".omr-parameter-state")?.textContent).toContain("暂无参数");
    expect(host.textContent).not.toContain("参数加载中"); expect(host.querySelector("dl")).toBeNull(); expect(more()).toBeUndefined();
    expect(host.textContent).not.toMatch(/工作电压|72 MHz|颗/);
  });
  it("reports real local resource errors rather than claiming no specs, and keeps cached real values visible", async () => {
    await render({ error: "资料暂不可用", resourceError: "资料暂不可用" });
    expect(host.querySelector(".omr-parameter-state")?.textContent).toBe("资料暂不可用");
    expect(host.textContent).not.toMatch(/暂无参数|参数加载中/);
    await render({ resource, error: "资料暂不可用", resourceError: "资料暂不可用" });
    expect(host.querySelectorAll(".omr-core-parameters > div")).toHaveLength(5); expect(host.querySelector(".omr-parameter-state")).toBeNull();
    expect(host.textContent).toContain("资料暂不可用");
  });
  it("does not mistake favorite-only errors for failed technical resources", async () => {
    await render({ resource: { ...resource, parameters: [] }, error: "收藏状态暂不可用", resourceError: null });
    expect(host.querySelector(".omr-parameter-state")?.textContent).toContain("暂无参数");
    expect(host.textContent).toContain("收藏状态暂不可用");
    await render({ error: "收藏状态暂不可用", resourceError: null });
    expect(host.querySelector(".omr-parameter-state")?.textContent).toContain("参数加载中");
  });
});

describe("optional search presentation, default consumers unchanged", () => {
  it("keeps omitted and explicit default DOM identical, with the original utility ellipsis and sibling extras", async () => {
    await render({ resource });
    const omitted = host.innerHTML;
    expect(host.querySelector(".omr-parameter-panel")).toBeNull();
    expect(more()?.parentElement?.className).toBe("omr-material-utilities");
    expect(more()?.textContent).toBe("…");
    expect(host.querySelector(".omr-extra-parameters")?.parentElement).toBe(host);
    await render({ resource, presentation: "default" });
    expect(host.innerHTML).toBe(omitted);
    act(() => more()!.click());
    expect(more()?.textContent).toBe("收起 ▴");
    expect(host.querySelectorAll(".omr-extra-parameters > div")).toHaveLength(3);
  });
  it("places real core and explicit more/less only in the search panel, with card-local extras and stable focus/aria", async () => {
    await render({ resource, presentation: "search" });
    const panel = host.querySelector(".omr-parameter-panel")!;
    const utilities = host.querySelector(".omr-material-utilities")!;
    expect(panel.getAttribute("aria-label")).toBe("SYNTH 商品参数");
    expect(panel.querySelectorAll(".omr-core-parameters > div")).toHaveLength(5);
    expect(utilities.querySelector(".omr-core-parameters,.omr-more-parameters,.omr-extra-parameters")).toBeNull();
    expect(Array.from(utilities.querySelectorAll("button")).map(button => button.textContent)).toEqual(["收藏"]);
    const trigger = more()!; expect(trigger.textContent).toBe("更多参数 ∨");
    expect(trigger.parentElement).toBe(panel);
    expect(panel.firstElementChild?.className).toBe("omr-core-parameters"); expect(panel.lastElementChild).toBe(trigger);
    expect(trigger.getAttribute("aria-controls")).toBe(`omr-extra-parameters-${id}`);
    expect(trigger.getAttribute("aria-expanded")).toBe("false");
    trigger.focus(); act(() => trigger.click());
    expect(trigger.textContent).toBe("收起参数 ∧");
    expect(trigger.getAttribute("aria-expanded")).toBe("true");
    expect(panel.querySelectorAll(".omr-extra-parameters > div")).toHaveLength(3);
    expect(panel.querySelectorAll("dl > div")).toHaveLength(8);
    expect(document.activeElement).toBe(trigger);
    expect(host.querySelector('[role="dialog"]')).toBeNull();
    act(() => trigger.click());
    expect(panel.querySelector<HTMLDListElement>(".omr-extra-parameters")?.hidden).toBe(true);
    expect(trigger.textContent).toBe("更多参数 ∨"); expect(document.activeElement).toBe(trigger);
  });
  it("search utilities retain favorite, safe PDF, retry and independent errors, and resource state stays in the panel", async () => {
    const favorite = vi.fn(), retry = vi.fn();
    await render({ presentation: "search", resource: { ...resource, datasheetUrl: "https://www.st.com/test.pdf" },
      authenticated: true, favorite: false, onFavorite: favorite, onResourceRetry: retry,
      error: "资料暂不可用", resourceError: "资料暂不可用" });
    const utilities = host.querySelector(".omr-material-utilities")!;
    const buttons = utilities.querySelectorAll("button");
    expect(Array.from(buttons).map(button => button.textContent)).toEqual(["收藏", "重试资料"]);
    act(() => { buttons[0].click(); buttons[1].click(); });
    expect(favorite).toHaveBeenCalledTimes(1); expect(retry).toHaveBeenCalledTimes(1);
    expect(utilities.querySelector("a")?.getAttribute("href")).toBe("https://www.st.com/test.pdf");
    expect(utilities.querySelector("a")?.rel).toBe("noopener noreferrer");
    expect(utilities.querySelector(".omr-material-error")?.textContent).toBe("资料暂不可用");
    await render({ presentation: "search", resourceError: "资料暂不可用", error: "资料暂不可用" });
    expect(host.querySelector(".omr-parameter-state")?.parentElement?.className).toBe("omr-parameter-panel");
    expect(host.querySelector(".omr-parameter-state")?.textContent).toBe("资料暂不可用"); expect(more()).toBeUndefined();
  });
  it("search extras remain local to each public ID, close on identity change, and never expose an empty more action", async () => {
    await render({ resource, presentation: "search" }); act(() => more()!.click());
    await render({ resource: { ...resource, publicId: "OTHER" }, publicId: "OTHER", partNumber: "OTHER", presentation: "search" });
    expect(more()?.getAttribute("aria-expanded")).toBe("false");
    expect(more()?.getAttribute("aria-controls")).toBe("omr-extra-parameters-OTHER");
    await render({ resource: { ...resource, parameters: real.slice(0, 5) }, presentation: "search" });
    expect(more()).toBeUndefined(); expect(host.querySelector(".omr-extra-parameters")).toBeNull();
    await act(async () => root.render(<><OfficialMaterialResources {...props} resource={resource} presentation="search" />
      <OfficialMaterialResources {...props} publicId="SECOND" partNumber="SECOND" resource={{ ...resource, publicId: "SECOND" }} presentation="search" /></>));
    const triggers = host.querySelectorAll<HTMLButtonElement>(".omr-more-parameters");
    act(() => triggers[0].click());
    expect(triggers[0].getAttribute("aria-expanded")).toBe("true"); expect(triggers[1].getAttribute("aria-expanded")).toBe("false");
  });
});
