export const SEARCH_RESULT_TIMEOUT_MS = 8_000;
export type OfficialSearchCommit = { key: string; stageOfficial: (commit: () => void) => void };

/** Generation fence only: merchant and official sections publish independently.
 * Each official quotation and its exact identity/version technical seed stay atomic.
 */
export class SearchResultCommit implements OfficialSearchCommit {
  private active = true;
  constructor(readonly key: string, _officialEnabled: boolean) {}
  stageMerchant(commit: () => void) { if (this.active) commit(); }
  stageOfficial(commit: () => void) { if (this.active) commit(); }
  activate() { this.active = true; }
  invalidate() { this.active = false; }
}

/** Bounds the consumer even when a transport ignores AbortSignal; late responses cannot commit. */
export function boundedSearchRequest<T>(request: Promise<T>, controller: AbortController, timeoutMs = SEARCH_RESULT_TIMEOUT_MS): Promise<T> {
  return new Promise((resolve, reject) => {
    const abort = () => { clean(); reject(controller.signal.reason instanceof Error ? controller.signal.reason : new Error("搜索请求已取消")); };
    const timer = setTimeout(() => controller.abort(new Error("报价加载超时，请重试")), timeoutMs);
    const clean = () => { clearTimeout(timer); controller.signal.removeEventListener("abort", abort); };
    controller.signal.addEventListener("abort", abort, { once: true });
    request.then(value => { clean(); resolve(value); }, error => { clean(); reject(error); });
    if (controller.signal.aborted) { clean(); abort(); }
  });
}
