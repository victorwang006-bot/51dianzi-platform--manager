// @vitest-environment jsdom
import React, { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { OfficialMallPublicMaterial, OfficialMallPublicListResult } from "../../../server/services/officialMallPublic";
import type { OfficialMaterialResource } from "@shared/officialMaterial";
import { OFFICIAL_QUANTITY_MAX, validOfficialQuantity } from "../../lib/officialCardPresentation";
const mocks = vi.hoisted(() => ({ list: vi.fn(), resourceQuery: vi.fn(), add: vi.fn(), resources: new Map<string, OfficialMaterialResource>() }));
vi.mock("@/lib/trpc", () => ({ trpc: { useUtils: () => ({ client: { officialMall: { list: { query: mocks.list } }, officialMaterial: { resources: { query: mocks.resourceQuery } } } }) } }));
vi.mock("@/hooks/useOfficialMaterial", () => ({ useOfficialMaterial: () => ({
  rootRef: null, resources: mocks.resources, resourceErrors: new Map(), favorites: new Map(), pending: new Set(),
  authenticated: false, resourceError: null, favoriteError: null, toggleFavorite: async () => {},
}) }));
vi.mock("./OfficialSearchImage", () => ({ default: ({ priority }: { priority?: boolean }) => <span data-image-priority={String(priority)} /> }));
import { OfficialMallSearchResults, officialTierSelectionQuantity, type OfficialMallSearchResultsProps } from "./OfficialMallSearchResults";
(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
const props: OfficialMallSearchResultsProps = { keyword: "SYNTH", brand: "all", sort: "default", viewMode: "list", officialCheckoutReady: true, onAddOfficialDraft: mocks.add };
function material(patch: Partial<OfficialMallPublicMaterial> = {}): OfficialMallPublicMaterial {
  return { sourceType: "official_mall", publicId: "OM_11111111-1111-4111-8111-111111111111", revision: 1,
    partNumber: "SYNTH", brand: "ST", pkg: "QFN", dateCode: "2026", leadTime: "3天",
    qtyStock: 100, qtyOnSale: 90, qtyOrder: 10, moq: 10, spq: 6, priceEx: "1.230001", taxIncluded: true,
    ladderPrices: [{ minQty: 10, price: "1.230001" }, { minQty: 20, price: "1.100001" }, { minQty: 30, price: "1.000009" }, { minQty: 50, price: "0.900009" }, { minQty: 100, price: "0.800009" }],
    publishedAt: "2026-01-01T00:00:00.000Z", ...patch };
}
function result(items = [material()], total = items.length, page = 1): OfficialMallPublicListResult { return { items, total, page, pageSize: 100 }; }
function deferred<T>() {
  let resolve!: (value: T) => void, reject!: (error: Error) => void;
  const promise = new Promise<T>((a, b) => { resolve = a; reject = b; });
  return { promise, resolve, reject };
}
let host: HTMLDivElement, root: Root, queryClient: QueryClient;
async function render(patch: Partial<OfficialMallSearchResultsProps> = {}) { await act(async () => root.render(<QueryClientProvider client={queryClient}><OfficialMallSearchResults {...props} {...patch} /></QueryClientProvider>)); }
async function refresh(type = "focus") { await act(async () => window.dispatchEvent(new Event(type))); }
async function settle<T>(pending: ReturnType<typeof deferred<T>>, value: T) { await act(async () => pending.resolve(value)); }
function findButton(text: string): HTMLButtonElement {
  const found = Array.from(host.querySelectorAll("button")).find(node => node.textContent?.includes(text));
  if (!found) throw new Error(`Missing button: ${text}`);
  return found;
}
function input() { return host.querySelector<HTMLInputElement>("input")!; }
async function enter(value: string) {
  await act(async () => {
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")!.set!.call(input(), value);
    input().dispatchEvent(new Event("input", { bubbles: true }));
  });
}
beforeEach(() => {
  vi.clearAllMocks(); mocks.resources.clear();
  Object.defineProperty(document, "visibilityState", { configurable: true, value: "visible" });
  mocks.list.mockResolvedValue(result());
  queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  mocks.resourceQuery.mockImplementation(async ({ publicIds }: { publicIds: string[] }) => ({ items: publicIds.map(publicId => mocks.resources.get(publicId) ?? { publicId, revision: 1, partNumber: "SYNTH", brand: "ST", pkg: "QFN", category: null, description: null, datasheetUrl: null, parameters: [] }) }));
  host = document.createElement("div"); document.body.append(host); root = createRoot(host);
});
afterEach(() => { act(() => root.unmount()); queryClient.clear(); host.remove(); vi.useRealTimers(); });

describe("same-scope quote snapshot polish (synthetic, no remote operations)", () => {
  it("shows explicit first-load status, retains card/input/local parameter disclosure during refresh and swaps new revision once", async () => {
    const first = deferred<OfficialMallPublicListResult>(); mocks.list.mockReturnValueOnce(first.promise);
    await render(); expect(host.querySelector(".omr-root")).toBeNull();
    expect(host.querySelector('[role="status"]')?.textContent).toBe("自营报价加载中…");
    expect(host.querySelector("article")).toBeNull();
    const original = material({ spq: 5 });
    mocks.resources.set(original.publicId, { publicId: original.publicId, revision: 1, partNumber: "SYNTH", brand: "ST", pkg: "QFN", category: null, description: null,
      parameters: [{ name: "主频", value: "72 MHz" }, { name: "Flash", value: "128 KB" }, { name: "RAM", value: "20 KB" },
        { name: "通道", value: "2" }, { name: "工作电压", value: "0" }, { name: "温度", value: "-40 ～ 85 °C" }], datasheetUrl: null });
    await settle(first, result([original])); await enter("20");
    const card = host.querySelector("article"), quantityNode = input(), core = host.querySelector(".omr-core-parameters");
    const trigger = findButton("更多参数"); trigger.focus(); act(() => trigger.click());
    const parameterPanel = host.querySelector('.omr-parameter-panel'), extras = host.querySelector<HTMLDListElement>('.omr-extra-parameters');
    expect(extras?.hidden).toBe(false); expect(document.activeElement).toBe(trigger);
    const pending = deferred<OfficialMallPublicListResult>(); mocks.list.mockReturnValueOnce(pending.promise);
    await refresh();
    expect(host.querySelector("article")).toBe(card); expect(input()).toBe(quantityNode); expect(input().value).toBe("20");
    expect(host.querySelector(".omr-core-parameters")).toBe(core); expect(host.querySelector('.omr-parameter-panel')).toBe(parameterPanel);
    expect(host.querySelector('.omr-extra-parameters')).toBe(extras); expect(extras?.hidden).toBe(false);
    expect(host.textContent).toContain("报价更新中"); expect(findButton("加入购物车").disabled).toBe(true);
    act(() => findButton("加入购物车").click()); expect(mocks.add).not.toHaveBeenCalled();
    const updated = material({ revision: 2, spq: 5, ladderPrices: [{ minQty: 10, price: "2.000001" }] });
    await settle(pending, result([updated]));
    expect(host.querySelector("article")).toBe(card); expect(input()).toBe(quantityNode); expect(input().value).toBe("20");
    expect(host.querySelector('.omr-parameter-panel')).toBe(parameterPanel); expect(extras?.hidden).toBe(false);
    expect(trigger.getAttribute("aria-expanded")).toBe("true"); expect(host.querySelector('[role="dialog"]')).toBeNull();
    expect(host.querySelector(".omr-unit-price")?.textContent).toBe("单价 ¥2.000001");
    expect(host.querySelector(".omr-subtotal")?.textContent).toBe("小计 ¥40.00");
    expect(findButton("加入购物车").disabled).toBe(false);
    act(() => findButton("加入购物车").click()); expect(mocks.add).toHaveBeenCalledWith(updated, 20);
  });
  it("blocks a stale click even before React commits the loading render in the same event batch", async () => {
    mocks.list.mockResolvedValueOnce(result([material({ spq: 5 })])); await render();
    const pending = deferred<OfficialMallPublicListResult>(); mocks.list.mockReturnValueOnce(pending.promise);
    const cart = findButton("加入购物车"); expect(cart.disabled).toBe(false);
    act(() => { window.dispatchEvent(new Event("focus")); cart.click(); });
    expect(mocks.add).not.toHaveBeenCalled(); expect(cart.disabled).toBe(true);
    await settle(pending, result([material({ revision: 2, spq: 5 })]));
    expect(cart.disabled).toBe(false); act(() => cart.click()); expect(mocks.add).toHaveBeenCalledTimes(1);
    expect(mocks.add.mock.calls[0][0].revision).toBe(2);
  });
  it("revalidates the retained quantity against changed sale and packaging metadata", async () => {
    mocks.list.mockResolvedValueOnce(result([material({ spq: 5 })])); await render(); await enter("20");
    mocks.list.mockResolvedValueOnce(result([material({ revision: 2, qtyOnSale: 12, spq: 6 })])); await refresh();
    expect(input().value).toBe("20"); expect(input().getAttribute("aria-invalid")).toBe("true");
    expect(findButton("加入购物车").disabled).toBe(true); expect(host.querySelector(".omr-unit-price")?.textContent).toBe("单价 —");
  });
  it("keeps all old pages until the final page succeeds and disables repeated load-more while pending", async () => {
    const pageOne = Array.from({ length: 100 }, (_, index) => material({ publicId: `synthetic-${index}`, partNumber: `OLD-${index}`, spq: 5 }));
    mocks.list.mockResolvedValueOnce(result(pageOne, 101)); await render();
    const p1 = deferred<OfficialMallPublicListResult>(), p2 = deferred<OfficialMallPublicListResult>();
    mocks.list.mockReturnValueOnce(p1.promise).mockReturnValueOnce(p2.promise);
    act(() => findButton("加载更多").click()); expect(host.querySelectorAll("article")).toHaveLength(100);
    expect(findButton("加载更多").disabled).toBe(true);
    const newOne = pageOne.map(row => ({ ...row, revision: 2, partNumber: row.partNumber.replace("OLD", "NEW") }));
    await settle(p1, result(newOne, 101)); expect(host.querySelectorAll("article")).toHaveLength(100); expect(host.querySelector(".omr-part")?.textContent).toBe("OLD-0");
    expect(Array.from(host.querySelectorAll<HTMLButtonElement>(".omr-cart")).every(node => node.disabled)).toBe(true);
    await settle(p2, result([material({ publicId: "synthetic-last", partNumber: "NEW-LAST", spq: 5 })], 101, 2));
    expect(host.querySelectorAll("article")).toHaveLength(101); expect(host.querySelector(".omr-part")?.textContent).toBe("NEW-0");
    expect(mocks.list.mock.calls.map(call => call[0].page)).toEqual([1, 1, 2]);
  });
  it.each(["total", "duplicate", "page", "pageSize"])("rejects a malformed %s page batch while retaining only the verified read-only snapshot", async fault => {
    const first = Array.from({ length: 100 }, (_, index) => material({ publicId: `synthetic-${index}`, partNumber: `OLD-${index}`, spq: 5 }));
    const unverified = first.map(row => ({ ...row, revision: 2, partNumber: row.partNumber.replace("OLD", "UNVERIFIED") }));
    mocks.list.mockResolvedValueOnce(result(first, 101)).mockResolvedValueOnce(result(unverified, 101));
    const second = result([material({ publicId: fault === "duplicate" ? "synthetic-0" : "synthetic-last" })], fault === "total" ? 102 : 101, fault === "page" ? 1 : 2);
    if (fault === "pageSize") second.pageSize = 30;
    mocks.list.mockResolvedValueOnce(second); await render();
    const verifiedNodes = Array.from(host.querySelectorAll("article"));
    expect(Array.from(host.querySelectorAll<HTMLButtonElement>(".omr-cart")).every(node => !node.disabled)).toBe(true);
    await act(async () => findButton("加载更多").click());
    expect(Array.from(host.querySelectorAll("article"))).toEqual(verifiedNodes);
    expect(host.querySelectorAll("article")).toHaveLength(100);
    expect(host.querySelector('[role="alert"]')?.textContent).toContain("上次报价，仅供查看");
    expect(host.textContent).not.toContain("UNVERIFIED");
    expect(host.querySelector('[data-official-public-id="synthetic-last"]')).toBeNull();
    expect(Array.from(host.querySelectorAll<HTMLButtonElement>(".omr-cart,.omr-tier-select")).every(node => node.disabled)).toBe(true);
    expect(Array.from(host.querySelectorAll<HTMLInputElement>("input")).every(node => node.readOnly)).toBe(true);
    act(() => findButton("加入购物车").click()); expect(mocks.add).not.toHaveBeenCalled();
  });
  it.each(["total", "duplicate", "page", "pageSize"])("rejects a malformed %s first page without any previous snapshot", async fault => {
    const bad = result(fault === "duplicate" ? [material(), material()] : [material()]);
    if (fault === "total") bad.total = -1;
    if (fault === "page") bad.page = 2;
    if (fault === "pageSize") bad.pageSize = 30;
    mocks.list.mockResolvedValueOnce(bad); await render();
    expect(host.querySelector("article")).toBeNull(); expect(host.querySelector(".omr-cart")).toBeNull();
    expect(host.querySelector('[role="alert"]')?.textContent).toContain("暂不可用");
    expect(mocks.add).not.toHaveBeenCalled();
  });
  it("retains a verified read-only card on refresh failure, removes withdrawn rows only after success, and retries honestly", async () => {
    const good = material({ spq: 5 }); mocks.list.mockResolvedValueOnce(result([good]));
    await render(); const pending = deferred<OfficialMallPublicListResult>(); mocks.list.mockReturnValueOnce(pending.promise);
    const verifiedCard = host.querySelector("article");
    expect(findButton("加入购物车").disabled).toBe(false);
    await refresh(); expect(host.querySelector("article")).not.toBeNull();
    await act(async () => pending.reject(new Error("synthetic offline")));
    expect(host.querySelector("article")).toBe(verifiedCard); expect(host.querySelector('[role="alert"]')?.textContent).toContain("上次报价，仅供查看");
    expect(findButton("加入购物车").disabled).toBe(true); expect(input().readOnly).toBe(true);
    act(() => findButton("加入购物车").click()); expect(mocks.add).not.toHaveBeenCalled();
    mocks.list.mockResolvedValueOnce(result([good])); await act(async () => findButton("重试").click());
    expect(findButton("加入购物车").disabled).toBe(false); expect(input().readOnly).toBe(false);
    const withdrawal = deferred<OfficialMallPublicListResult>(); mocks.list.mockReturnValueOnce(withdrawal.promise);
    await refresh(); expect(host.querySelector("article")).not.toBeNull(); await settle(withdrawal, result([])); expect(host.querySelector(".omr-root")).toBeNull();
  });
  it("scope changes synchronously isolate old DOM and fence late responses and errors", async () => {
    await render(); const late = deferred<OfficialMallPublicListResult>(), current = deferred<OfficialMallPublicListResult>();
    mocks.list.mockReturnValueOnce(late.promise).mockReturnValueOnce(current.promise);
    await refresh(); await render({ keyword: "OTHER", brand: "OTHERBRAND" }); expect(host.querySelector("article")).toBeNull();
    await settle(current, result([material({ partNumber: "OTHER", brand: "OTHERBRAND" })]));
    await act(async () => late.reject(new Error("late old scope")));
    expect(host.querySelector(".omr-part")?.textContent).toBe("OTHER"); expect(host.querySelector('[role="alert"]')).toBeNull();
  });
  it("prioritizes exactly the first two sorted cards without making an extra quote request", async () => {
    mocks.list.mockResolvedValueOnce(result(Array.from({ length: 4 }, (_, index) => material({ publicId: `synthetic-${index}` })))); await render();
    expect(Array.from(host.querySelectorAll("[data-image-priority]")).map(node => node.getAttribute("data-image-priority"))).toEqual(["true", "true", "false", "false"]);
    await render({ viewMode: "grid" }); expect(mocks.list).toHaveBeenCalledTimes(1);
  });
});

describe("tier quantity selection and card-local ladder disclosure", () => {
  it("uses MOQ/SPQ rounding, nullable unconstrained SPQ and sale/MAX bounds, never financial conversion", () => {
    expect(officialTierSelectionQuantity(material(), 10)).toBe(12);
    expect(officialTierSelectionQuantity(material(), 20)).toBe(24);
    expect(officialTierSelectionQuantity(material(), 50)).toBe(54);
    expect(officialTierSelectionQuantity(material(), 100)).toBeNull();
    expect(officialTierSelectionQuantity(material({ spq: null }), 20)).toBe(20);
    expect(officialTierSelectionQuantity(material({ moq: 25 }), 20)).toBe(30);
    for (const patch of [{ moq: null }, { spq: 0 }, { qtyOnSale: null }, { qtyOnSale: 0 }]) expect(officialTierSelectionQuantity(material(patch), 20)).toBeNull();
    expect(officialTierSelectionQuantity(material({ moq: 1, qtyOnSale: OFFICIAL_QUANTITY_MAX, spq: 6 }), OFFICIAL_QUANTITY_MAX)).toBeNull();
    expect(officialTierSelectionQuantity(material(), -1)).toBeNull();
  });
  it("shows three rows then reveals the remaining rows once in the same procurement section, preserving trigger focus and aria", async () => {
    await render(); expect(host.querySelectorAll(".omr-prices > .omr-tier")).toHaveLength(3);
    expect(host.querySelector("details,.omr-full-tiers")).toBeNull();
    const trigger = findButton("5档"); trigger.focus(); act(() => trigger.click());
    const remaining = host.querySelector<HTMLDivElement>(".omr-remaining-tiers")!;
    expect(remaining.hidden).toBe(false); expect(remaining.querySelectorAll(".omr-tier")).toHaveLength(2);
    expect(remaining.closest(".omr-procurement")).not.toBeNull(); expect(host.querySelectorAll(".omr-tier")).toHaveLength(5);
    expect(host.querySelectorAll(".omr-prices > .omr-tier")).toHaveLength(3);
    expect(trigger.getAttribute("aria-expanded")).toBe("true"); expect(trigger.getAttribute("aria-controls")).toBe(remaining.id);
    expect(host.querySelector("article")?.classList.contains("omr-tiers-expanded")).toBe(true); expect(document.activeElement).toBe(trigger);
    act(() => trigger.click()); expect(remaining.hidden).toBe(true); expect(remaining.children).toHaveLength(0);
    expect(trigger.getAttribute("aria-expanded")).toBe("false"); expect(host.querySelectorAll(".omr-tier")).toHaveLength(3);
    expect(host.querySelector('[role="dialog"]')).toBeNull(); expect(document.activeElement).toBe(trigger);
    expect(host.querySelector("style")?.textContent).toContain(".omr-card.omr-tiers-expanded .omr-order{justify-content:flex-start}");
  });
  it("clicking tiers fills the smallest legal quantity, updates current tier/exact subtotal and keeps impossible rows visibly unavailable", async () => {
    await render(); const inline = host.querySelectorAll<HTMLButtonElement>(".omr-prices > .omr-tier-select");
    act(() => inline[1].click()); expect(input().value).toBe("24"); expect(validOfficialQuantity(material(), Number(input().value))).toBe(true);
    expect(host.querySelector(".omr-tier.is-active")?.textContent).toBe("20起1.100001");
    expect(host.querySelector(".omr-unit-price")?.textContent).toBe("单价 ¥1.100001"); expect(host.querySelector(".omr-subtotal")?.textContent).toBe("小计 ¥26.40");
    const trigger = findButton("5档"); trigger.focus(); act(() => trigger.click());
    const rows = host.querySelectorAll<HTMLButtonElement>(".omr-prices .omr-tier-select");
    expect(rows[4].disabled).toBe(true); expect(rows[4].textContent).toContain("不可选"); act(() => rows[4].click()); expect(input().value).toBe("24");
    act(() => rows[3].click()); expect(input().value).toBe("54"); expect(host.querySelector('[role="dialog"]')).toBeNull(); expect(document.activeElement).toBe(trigger);
    expect(host.querySelector(".omr-subtotal")?.textContent).toBe("小计 ¥48.60");
    act(() => findButton("加入购物车").click()); expect(mocks.add).toHaveBeenCalledWith(material(), 54);
    expect(host.textContent).not.toContain("颗"); expect(mocks.list).toHaveBeenCalledTimes(1);
  });
});

describe("scheme B truthful stock fallback beside the price heading", () => {
  it.each([
    { qtyStock: 100, qtyOnSale: 90, label: "库存 100" },
    { qtyStock: null, qtyOnSale: 90, label: "可售 90" },
    { qtyStock: 0, qtyOnSale: 0, label: "库存 0" },
    { qtyStock: 100, qtyOnSale: 0, label: "库存 100" },
    { qtyStock: null, qtyOnSale: 0, label: "可售 0" },
    { qtyStock: null, qtyOnSale: null, label: null },
  ])("distinguishes inventory and sale quantity: %j", async row => {
    mocks.list.mockResolvedValueOnce(result([material({ qtyStock: row.qtyStock, qtyOnSale: row.qtyOnSale })])); await render();
    const stock = host.querySelector(".omr-stock");
    if (row.label === null) expect(stock).toBeNull();
    else {
      expect(stock?.textContent).toBe(row.label); expect(stock?.closest(".omr-facts")).toBeNull();
      expect(stock?.parentElement?.className).toBe("omr-price-heading"); expect(stock?.previousElementSibling?.textContent).toBe("单价");
      expect(stock?.textContent).not.toMatch(/颗|现货|立即|发货/);
    }
    expect(host.querySelector(".omr-facts .omr-stock")).toBeNull();
    if (!row.qtyOnSale) expect(findButton("加入购物车").disabled).toBe(true);
    expect(host.querySelector("style")?.textContent).toContain(".omr-root .omr-card .omr-stock b{font-weight:650;color:#17633b}");
  });
});

describe("scheme B visual removal without weakening commerce", () => {
  it.each([true, false, null])("does not render badge/tax/MOQ prose while retaining taxIncluded=%j and exact quoted draft payload", async taxIncluded => {
    const item = material({ taxIncluded, spq: 5 }); mocks.list.mockResolvedValueOnce(result([item])); await render();
    const card = host.querySelector("article")!;
    expect(card.querySelector(".omr-badge,.omr-tax,.omr-moq,.lucide-zap")).toBeNull();
    expect(card.textContent).not.toMatch(/51自营|含税|未税|税别|起订/);
    expect(card.getAttribute("aria-label")).toBe("SYNTH 51自营报价");
    expect(card.getAttribute("data-source-type")).toBe(item.sourceType); expect(card.getAttribute("data-official-public-id")).toBe(item.publicId);
    expect(card.querySelector(".omr-price-heading > span")?.textContent).toBe("单价");
    expect(card.querySelector(".omr-unit-price")?.textContent).toBe("单价 ¥1.230001");
    expect(card.querySelector(".omr-subtotal")?.textContent).toBe("小计 ¥12.30");
    const procurement = card.querySelector(".omr-procurement")!;
    expect(Array.from(procurement.children).map(node => node.className)).toEqual(["omr-prices", "omr-order"]);
    expect(card.querySelector(".omr-contact")?.parentElement?.className).toBe("omr-order");
    expect(card.querySelector(".omr-contact")?.previousElementSibling?.className).toBe("omr-cart");
    expect(findButton("加入购物车").disabled).toBe(false); act(() => findButton("加入购物车").click());
    expect(mocks.add).toHaveBeenCalledWith(item, 10); expect(mocks.add.mock.calls[0][0].taxIncluded).toBe(taxIncluded);
  });
  it.each([
    { patch: { moq: null, spq: 5 }, quantity: "10" },
    { patch: { moq: 10, spq: 5 }, quantity: "5" },
    { patch: { moq: 10, spq: 6 }, quantity: "20" },
    { patch: { moq: 10, spq: 5, qtyOnSale: 12 }, quantity: "20" },
    { patch: { moq: 10, spq: 0 }, quantity: "20" },
    { patch: { moq: 10, spq: 5, qtyOnSale: null }, quantity: "20" },
  ])("still blocks published MOQ/SPQ/sale guards despite deleting the duplicate MOQ row: %j", async ({ patch, quantity }) => {
    mocks.list.mockResolvedValueOnce(result([material(patch)])); await render(); await enter(quantity);
    expect(host.querySelector(".omr-moq")).toBeNull(); expect(findButton("加入购物车").disabled).toBe(true);
    act(() => findButton("加入购物车").click()); expect(mocks.add).not.toHaveBeenCalled();
    expect(findButton("加入购物车").title).toMatch(/起订|包装|可售/);
  });
  it("a displayed stock number cannot substitute for sale availability and unknown stock does not block a known legal sale", async () => {
    const sale = material({ qtyStock: null, qtyOnSale: 90, spq: 5 }); mocks.list.mockResolvedValueOnce(result([sale])); await render();
    expect(host.querySelector(".omr-stock")?.textContent).toBe("可售 90");
    expect(findButton("加入购物车").disabled).toBe(false); act(() => findButton("加入购物车").click()); expect(mocks.add).toHaveBeenCalledWith(sale, 10);
    mocks.add.mockClear(); mocks.list.mockResolvedValueOnce(result([material({ revision: 2, qtyStock: 100, qtyOnSale: 0, spq: 5 })])); await refresh();
    expect(host.querySelector(".omr-stock")?.textContent).toBe("库存 100"); expect(findButton("加入购物车").disabled).toBe(true);
    act(() => findButton("加入购物车").click()); expect(mocks.add).not.toHaveBeenCalled();
  });
  it("missing tax display does not insert a static price when the published quote is absent", async () => {
    mocks.list.mockResolvedValueOnce(result([material({ priceEx: null, ladderPrices: [], spq: 5 })])); await render();
    expect(host.querySelector(".omr-prices .omr-tier strong")?.textContent).toBe("—");
    expect(host.querySelector(".omr-unit-price")?.textContent).toBe("单价 —"); expect(host.querySelector(".omr-subtotal")?.textContent).toBe("小计 —");
    expect(findButton("加入购物车").disabled).toBe(true); expect(host.querySelector(".omr-tax")).toBeNull();
  });
  it("refresh failure retains only the verified read-only snapshot, retries once, and successful withdrawal removes it", async () => {
    mocks.list.mockResolvedValueOnce(result([material({ spq: 5 })])); await render();
    const card = host.querySelector("article"); await enter("20");
    mocks.list.mockRejectedValueOnce(new Error("synthetic offline")); await refresh();
    expect(host.querySelector("article")).toBe(card); expect(host.querySelector('[role="alert"]')?.textContent).toContain("上次报价，仅供查看");
    expect(findButton("加入购物车").disabled).toBe(true); expect(input().readOnly).toBe(true);
    act(() => findButton("加入购物车").click()); expect(mocks.add).not.toHaveBeenCalled();
    mocks.list.mockResolvedValueOnce(result([material({ revision: 2, spq: 5 })]));
    await act(async () => findButton("重试").click()); expect(findButton("加入购物车").disabled).toBe(false); expect(input().value).toBe("20");
    mocks.list.mockResolvedValueOnce(result([])); await refresh(); expect(host.querySelector("article")).toBeNull();
  });
});
