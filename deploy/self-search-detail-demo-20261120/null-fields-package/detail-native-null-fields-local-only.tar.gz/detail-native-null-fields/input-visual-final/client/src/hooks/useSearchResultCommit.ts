import { useEffect, useRef, useState } from "react";
import { SearchResultCommit, SEARCH_RESULT_TIMEOUT_MS } from "@/lib/searchResultCommit";

type CoreResult<T> = { data: T | undefined; pending: boolean; error: boolean; cancel?: () => void };
type Committed<T> = { barrier: SearchResultCommit; retention: string; data: T | undefined; error: boolean };
type Generation = {
  key: string; retention: string; cycle: number; barrier: SearchResultCommit;
  merchantSettled: boolean; timedOut: boolean; pending: boolean; allowRetention: boolean;
};

/** Independent merchant terminal state; the official snapshot never gates this section. */
export function useSearchResultCommit<T>(key: string, retention: string, core: CoreResult<T>, officialEnabled: boolean) {
  const [view, setView] = useState<Committed<T> | null>(null);
  const slot = useRef<Generation | null>(null);
  const previous = slot.current;
  const startsFetch = previous?.key === key && core.pending && !previous.pending && previous.merchantSettled && !previous.timedOut;
  if (!previous || previous.key !== key || startsFetch) {
    previous?.barrier.invalidate();
    const cycle = (previous?.cycle ?? 0) + 1;
    slot.current = { key, retention, cycle, barrier: new SearchResultCommit(JSON.stringify([key, cycle]), officialEnabled),
      merchantSettled: false, timedOut: false, pending: core.pending, allowRetention: previous?.retention === retention };
  }
  const current = slot.current!;
  current.pending = core.pending;
  const barrier = current.barrier;
  const cancelRef = useRef(core.cancel);
  cancelRef.current = core.cancel;
  const commit = (data: T | undefined, error: boolean) => setView(previousView => ({ barrier, retention,
    data: data ?? (error && current.allowRetention && previousView?.retention === retention ? previousView.data : undefined), error }));
  useEffect(() => {
    barrier.activate();
    const timer = window.setTimeout(() => {
      if (current.merchantSettled || slot.current !== current) return;
      current.timedOut = current.merchantSettled = true;
      barrier.stageMerchant(() => commit(undefined, true));
      cancelRef.current?.();
    }, SEARCH_RESULT_TIMEOUT_MS);
    return () => { window.clearTimeout(timer); barrier.invalidate(); };
  }, [barrier]);
  useEffect(() => {
    if (core.pending || current.timedOut || slot.current !== current) return;
    current.merchantSettled = true;
    barrier.stageMerchant(() => commit(core.data, core.error));
  }, [barrier, core.data, core.pending, core.error]);
  const matching = view?.barrier === barrier || current.allowRetention && view?.retention === retention ? view : null;
  return {
    officialCommit: barrier,
    data: matching?.data,
    waiting: view?.barrier !== barrier,
    error: view?.barrier === barrier && view.error,
  };
}
