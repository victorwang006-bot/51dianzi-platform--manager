// @vitest-environment jsdom
import React, { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { describe, beforeEach, afterEach, expect, it, vi } from "vitest";
import { readFileSync } from "node:fs";
import { createHash } from "node:crypto";
const mocks = vi.hoisted(() => ({ id: "", auth: vi.fn(), utils: vi.fn(), detail: vi.fn(), preview: vi.fn(), related: vi.fn(), specs: vi.fn(), followed: vi.fn(), followMut: vi.fn(), cartMut: vi.fn() }));
vi.mock("wouter", () => ({ useRoute: () => [true, { id: mocks.id }], useLocation: () => ["/product/" + mocks.id, vi.fn()], Link: ({ href, children }: any) => <a href={href}>{children}</a> }));
vi.mock("./OfficialProductDetail", () => ({ default: ({ publicId }: { publicId: string }) => <div data-official-detail-id={publicId}>官方详情分支</div> }));
vi.mock("@/_core/hooks/useAuth", () => ({ useAuth: mocks.auth }));
vi.mock("@/components/MallNav", () => ({ default: () => <header>商户导航</header> }));
vi.mock("@/components/MallLoginDialog", () => ({ default: () => null }));
vi.mock("@/components/ProductImageGallery", () => ({ default: () => null, productImageSources: () => [] }));
vi.mock("@/components/ProductDetailSkeleton", () => ({ default: () => <div>商户骨架</div> }));
vi.mock("@/hooks/useEnterpriseInquiryLauncher", () => ({ useEnterpriseInquiryLauncher: () => ({ launchInquiry: vi.fn(), inquiryEnterpriseChooser: null }) }));
vi.mock("@/hooks/useMaterialExposure", () => ({ useMaterialExposure: () => null }));
vi.mock("@/lib/trpc", () => ({ trpc: { useUtils: mocks.utils, search: { detail: { useQuery: mocks.detail }, previewDetail: { useQuery: mocks.preview },
  relatedDetail: { useQuery: mocks.related }, followedSupplierIds: { useQuery: mocks.followed }, toggleFollowSupplier: { useMutation: mocks.followMut } },
  material: { getSpecsBatch: { useQuery: mocks.specs } }, cart: { add: { useMutation: mocks.cartMut } } } }));
import ProductDetail from "./ProductDetail";
(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
let host: HTMLDivElement, root: Root;
beforeEach(() => {
  vi.clearAllMocks(); mocks.auth.mockReturnValue({ user: null, isAuthenticated: false, loading: false }); mocks.utils.mockReturnValue({});
  for (const query of [mocks.detail, mocks.preview, mocks.related, mocks.specs, mocks.followed]) query.mockReturnValue({});
  mocks.followMut.mockReturnValue({ mutate: vi.fn() }); mocks.cartMut.mockReturnValue({ mutate: vi.fn() });
  host = document.createElement("div"); document.body.append(host); root = createRoot(host);
});
afterEach(() => { act(() => root.unmount()); host.remove(); });
async function render(id: string) { mocks.id = id; await act(async () => root.render(<ProductDetail />)); }
describe("ProductDetail pure route split and complete merchant preservation", () => {
  it.each(["OM_11111111-1111-4111-8111-111111111111", "OM_invalid", "OM_1", "", "123x", "om_bad"])("non-numeric %j never mounts merchant quota/recommendation/follow/cart hooks", async id => {
    await render(id); expect(host.querySelector("[data-official-detail-id]")?.getAttribute("data-official-detail-id")).toBe(id);
    for (const call of [mocks.auth, mocks.utils, mocks.detail, mocks.preview, mocks.related, mocks.specs, mocks.followed, mocks.followMut, mocks.cartMut]) expect(call).not.toHaveBeenCalled();
  });
  it("numeric IDs still enter the original merchant body and existing safe public preview behavior", async () => {
    mocks.preview.mockReturnValue({ data: { partNumber: "MERCHANT-42", brand: "Vendor", availability: "in_stock" } }); await render("42");
    expect(host.querySelector("[data-official-detail-id]")).toBeNull(); expect(host.querySelector(".pd-root")).not.toBeNull();
    expect(mocks.preview).toHaveBeenCalledWith({ id: 42, deferRelated: true }, expect.objectContaining({ enabled: true }));
    expect(mocks.detail).toHaveBeenCalledWith({ id: 42, deferRelated: true }, expect.objectContaining({ enabled: false, retry: false, refetchOnWindowFocus: false, refetchOnReconnect: false }));
    expect(host.querySelector("h1")?.textContent).toBe("MERCHANT-42"); expect(host.textContent).toContain("登录查看供应商报价、阶梯价与库存明细");
  });
  it("switching numeric -> official unmounts merchant and adds no further merchant hook calls", async () => {
    await render("42"); const detailCalls = mocks.detail.mock.calls.length, previewCalls = mocks.preview.mock.calls.length;
    await render("OM_11111111-1111-4111-8111-111111111111"); expect(host.querySelector(".pd-root")).toBeNull();
    expect(mocks.detail).toHaveBeenCalledTimes(detailCalls); expect(mocks.preview).toHaveBeenCalledTimes(previewCalls);
  });
  it("retains every byte of the original merchant function body including hooks, calculations, callbacks, rendering and CSS", () => {
    const source = readFileSync("client/src/pages/ProductDetail.tsx", "utf8");
    const body = source.split("function MerchantProductDetail() {")[1]; expect(body).toBeDefined();
    expect(createHash("sha256").update(body).digest("hex")).toBe("ecd83655f83f02e4a93152e9761a8311672eab91b8317c3ca182a8e4de78db65");
    const wrapper = source.split("export default function ProductDetail() {")[1].split("function MerchantProductDetail() {")[0];
    expect(wrapper).not.toMatch(/trpc|Number\(|useAuth|cart\.add|search\.detail/);
  });
});
