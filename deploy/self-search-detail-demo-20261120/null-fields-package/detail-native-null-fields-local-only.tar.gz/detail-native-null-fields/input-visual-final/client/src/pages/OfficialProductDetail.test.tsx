// @vitest-environment jsdom
import React, { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { beforeEach, afterEach, describe, expect, it, vi } from "vitest";
import type { OfficialMallPublicMaterial, OfficialMallPublicDetailResult } from "../../../server/services/officialMallPublic";
import type { OfficialMaterialResource } from "@shared/officialMaterial";
import { officialMaterialResourceItemKey } from "@/lib/officialMaterialClient";
const mocks = vi.hoisted(() => ({ detail: vi.fn(), list: vi.fn(), resources: vi.fn(), favorites: vi.fn(), setFavorite: vi.fn(),
  add: vi.fn(), cartAdd: vi.fn(), cartCount: vi.fn(), notice: vi.fn(), invalidate: vi.fn(), cartReady: "ready", buyer: "test-buyer", current: true }));
vi.mock("@/lib/trpc", () => ({ trpc: { useUtils: () => ({ client: {
  officialMall: { detail: { query: mocks.detail }, list: { query: mocks.list } },
  officialMaterial: { resources: { query: mocks.resources }, favoriteStates: { query: mocks.favorites }, setFavorite: { mutate: mocks.setFavorite } },
} }) } }));
vi.mock("@/_core/hooks/useAuth", () => ({ useAuth: () => ({ user: null, loading: false, isAuthenticated: false }) }));
vi.mock("@/hooks/useOfficialCart", () => ({ useOfficialCartCount: () => ({ buyer: mocks.buyer, key: "test-buyer:0", readiness: mocks.cartReady,
  client: { officialCart: { add: { mutate: mocks.cartAdd } }, cart: { count: { query: mocks.cartCount } } },
  isCurrent: () => mocks.current, invalidate: mocks.invalidate }) }));
vi.mock("@/components/MallNav", () => ({ default: () => <header data-testid="existing-mall-nav">现有商城导航</header> }));
vi.mock("@/components/MallLoginDialog", () => ({ default: ({ open }: { open: boolean }) => open ? <div role="dialog">登录</div> : null }));
vi.mock("@/components/OfficialCartNotice", () => ({ showOfficialCartNotice: mocks.notice }));
vi.mock("@/components/ImageLightbox", () => ({ default: ({ open, src }: { open: boolean; src: string }) => open ? <div role="dialog" data-zoom-src={src}>包装大图</div> : null }));
import OfficialProductDetail, { createOfficialProductDetail, type OfficialProductDetailProps } from "./OfficialProductDetail";
import { OfficialMallSearchResults, isOfficialDetailPublicId } from "@/components/OfficialMallSearchResults";
import { OFFICIAL_SEARCH_IMAGE_FALLBACK } from "@/components/OfficialSearchImage";
import { SEARCH_RESULT_TIMEOUT_MS } from "@/lib/searchResultCommit";
(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
const A = "OM_11111111-1111-4111-8111-111111111111", B = "OM_22222222-2222-4222-8222-222222222222";
function material(patch: Partial<OfficialMallPublicMaterial> = {}): OfficialMallPublicMaterial {
  const item: OfficialMallPublicMaterial = { sourceType: "official_mall", publicId: A, revision: 1, partNumber: "TEST-A", brand: "ST", pkg: "QFN",
    dateCode: "2026", leadTime: "3天", qtyStock: 100, qtyOnSale: 90, qtyOrder: 10, moq: 10, spq: 5, priceEx: "1.230001", taxIncluded: true,
    ladderPrices: [{ minQty: 10, price: "1.230001" }, { minQty: 20, price: "1.100001" }, { minQty: 30, price: "1.000009" }, { minQty: 50, price: "0.900009" }],
    publishedAt: "2026-01-01T00:00:00.000Z", ...patch };
  if (patch.technicalResource === undefined) item.technicalResource = { state: "ready", parameterVersion: "fixture-v1", resource: {
    publicId: item.publicId, revision: item.revision, partNumber: item.partNumber, brand: item.brand, pkg: item.pkg, category: null, description: null,
    datasheetUrl: "https://www.st.com/resource/en/datasheet/fixture.pdf", parameters: [{ name: "内核", value: "Cortex-M4" }, { name: "主频", value: "72 MHz" },
      { name: "Flash", value: "128 KB" }, { name: "RAM", value: "20 KB" }, { name: "通道", value: "2" }, { name: "工作电压", value: "0" },
      { name: "温度", value: "-40 ～ 85 °C" }, { name: "占位", value: "待确认" }],
  } };
  return item;
}
function deferred<T>() { let resolve!: (value: T) => void, reject!: (reason: Error) => void;
  const promise = new Promise<T>((a, b) => { resolve = a; reject = b; }); return { promise, resolve, reject }; }
let host: HTMLDivElement, root: Root, queryClient: QueryClient;
async function render(props: Partial<OfficialProductDetailProps> = {}, defaultBridge = false) {
  await act(async () => root.render(<QueryClientProvider client={queryClient}><OfficialProductDetail publicId={A}
    {...(defaultBridge ? {} : { onAddOfficialDraft: mocks.add, officialCheckoutReady: true })} {...props} /></QueryClientProvider>));
}
async function refresh(event = "focus") { await act(async () => window.dispatchEvent(new Event(event))); }
async function settle(pending: ReturnType<typeof deferred<OfficialMallPublicDetailResult>>, item: OfficialMallPublicMaterial | null) { await act(async () => pending.resolve({ item })); }
function button(text: string): HTMLButtonElement { const node = [...host.querySelectorAll("button")].find(el => el.textContent?.includes(text)); if (!node) throw new Error(`Missing ${text}`); return node; }
function input() { return host.querySelector<HTMLInputElement>(".omr-counter input")!; }
async function enter(value: string) { await act(async () => { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")!.set!.call(input(), value); input().dispatchEvent(new Event("input", { bubbles: true })); }); }
beforeEach(() => {
  vi.clearAllMocks(); mocks.detail.mockResolvedValue({ item: material() }); mocks.list.mockRejectedValue(new Error("No list fallback"));
  mocks.cartReady = "ready"; mocks.buyer = "test-buyer"; mocks.current = true;
  mocks.cartAdd.mockResolvedValue({ item: { sourceType: "official_mall", publicId: A }, count: 1 }); mocks.cartCount.mockResolvedValue(2);
  mocks.invalidate.mockResolvedValue(undefined); mocks.resources.mockRejectedValue(new Error("No secondary resource GET"));
  Object.defineProperty(document, "visibilityState", { configurable: true, value: "visible" });
  queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } }); host = document.createElement("div"); document.body.append(host); root = createRoot(host);
});
afterEach(() => { act(() => root.unmount()); queryClient.clear(); host.remove(); vi.useRealTimers(); });

describe("official detail public GET scope and truthful presentation (offline fixtures)", () => {
  it("uses only officialMall.detail and displays the three zones, existing one-box lightbox, full parameters and safe PDF", async () => {
    await render(); expect(mocks.detail).toHaveBeenCalledTimes(1); expect(mocks.detail.mock.calls[0][0]).toEqual({ publicId: A });
    expect(mocks.detail.mock.calls[0][1].signal).toBeInstanceOf(AbortSignal); expect(mocks.detail.mock.calls[0][1].context).toEqual({ skipBatch: true });
    expect(mocks.list).not.toHaveBeenCalled(); expect(mocks.resources).not.toHaveBeenCalled(); expect(mocks.cartAdd).not.toHaveBeenCalled();
    expect(host.querySelectorAll('[data-testid="existing-mall-nav"]')).toHaveLength(1); expect(host.querySelector("h1")?.textContent).toBe("TEST-A自营");
    expect(host.querySelector(".omr-detail-gallery")).not.toBeNull(); expect(host.querySelector(".omr-detail-info")).not.toBeNull(); expect(host.querySelector(".omr-procurement")).not.toBeNull();
    expect(host.querySelectorAll(".omr-detail-mark")).toHaveLength(2); expect(host.querySelector(".omr-detail-seller")?.textContent).toContain("51电子网自营");
    expect(host.querySelectorAll('.omr-detail-gallery img:not(.omr-detail-mark img)')).toHaveLength(1);
    const image = host.querySelector<HTMLImageElement>(".omr-image-trigger img")!; expect(image.getAttribute("src")).toBe(OFFICIAL_SEARCH_IMAGE_FALLBACK.thumbnail);
    expect(image.alt).toContain("非商品实拍"); act(() => host.querySelector<HTMLButtonElement>(".omr-image-trigger")!.click());
    expect(document.querySelector('[role="dialog"]')?.getAttribute("data-zoom-src")).toBe(OFFICIAL_SEARCH_IMAGE_FALLBACK.zoom);
    expect(host.querySelectorAll(".omr-detail-parameters>div")).toHaveLength(7); expect(host.querySelector(".omr-detail-parameters")?.textContent).toContain("-40 ～ 85 °C");
    expect(host.querySelector(".omr-detail-parameters")?.textContent).not.toContain("占位"); expect(host.querySelector(".omr-more-parameters")).toBeNull();
    const pdf = host.querySelector<HTMLAnchorElement>('a[href*="fixture.pdf"]')!; expect(pdf.rel).toBe("noopener noreferrer");
    expect(host.querySelector('.omr-contact a')?.getAttribute("href")).toBe("/chat?service=1");
    expect(host.querySelector("article")?.textContent).not.toMatch(/演示|Demo|RoHS|发票|13%|分类|生产周期|评论|立即购买/);
    expect(host.querySelector("style")?.textContent).toContain("grid-template-columns:300px minmax(0,1fr) 280px");
  });
  it.each(["", "OM_bad", "OM_1", "OM_11111111-1111-4111-8111-111111111111?x", "123", "om_11111111-1111-4111-8111-111111111111"])("rejects invalid publicId %j without detail/list/cart queries", async publicId => {
    expect(isOfficialDetailPublicId(publicId)).toBe(false); await render({ publicId }); expect(mocks.detail).not.toHaveBeenCalled();
    expect(mocks.list).not.toHaveBeenCalled(); expect(mocks.cartAdd).not.toHaveBeenCalled(); expect(host.querySelector("article")).toBeNull();
    expect(host.querySelector('[role="alert"]')?.textContent).toContain("编号无效");
  });
  it("detailPublicId presence cannot trigger list fallback even through the shared direct entry", async () => {
    await act(async () => root.render(<OfficialMallSearchResults keyword="TEST" brand="all" sort="default" viewMode="list" detailPublicId="OM_invalid" />));
    expect(mocks.detail).not.toHaveBeenCalled(); expect(mocks.list).not.toHaveBeenCalled();
  });
  it.each([true, false, null])("shows taxIncluded=%j without converting exact prices, quantity or eligible draft payload", async taxIncluded => {
    const item = material({ taxIncluded }); mocks.detail.mockResolvedValue({ item }); await render();
    const tax = taxIncluded === true ? "含税" : taxIncluded === false ? "未税" : "税别待确认";
    expect(host.querySelector(".omr-price-heading")?.textContent).toBe(`单价（${tax}）`);
    expect(host.querySelector(".omr-unit-price")?.textContent).toBe("单价 ¥1.230001"); expect(host.querySelector(".omr-subtotal")?.textContent).toBe("小计 ¥12.30");
    act(() => button("加入购物车").click()); expect(mocks.add).toHaveBeenCalledWith(item, 10);
    expect(host.querySelector(".omr-detail-quote-note")?.textContent).toContain(tax); expect(host.textContent).not.toContain("13%");
  });
  it.each([{ moq: null }, { spq: 0 }, { qtyOnSale: null }, { qtyOnSale: 0 }, { priceEx: null, ladderPrices: [] }])("preserves existing unavailable sale/pack/price guards: %j", async patch => {
    mocks.detail.mockResolvedValue({ item: material(patch) }); await render(); expect(button("加入购物车").disabled).toBe(true);
    act(() => button("加入购物车").click()); expect(mocks.add).not.toHaveBeenCalled();
  });
  it("uses existing tier selection / exact decimal math and blocks illegal SPQ or over-sale quantity", async () => {
    const item = material({ spq: 6 }); mocks.detail.mockResolvedValue({ item }); await render();
    act(() => host.querySelectorAll<HTMLButtonElement>(".omr-tier-select")[1].click()); expect(input().value).toBe("24");
    expect(host.querySelector(".omr-subtotal")?.textContent).toBe("小计 ¥26.40"); act(() => button("加入购物车").click()); expect(mocks.add).toHaveBeenCalledWith(item, 24);
    mocks.add.mockClear(); await enter("20"); expect(button("加入购物车").disabled).toBe(true); await enter("96"); expect(button("加入购物车").disabled).toBe(true); expect(mocks.add).not.toHaveBeenCalled();
  });
  it("same-ID refresh retains verified DOM and quantity strictly read-only; failed/retry requests never restore stale eligibility", async () => {
    await render(); await enter("20"); const card = host.querySelector("article"), field = input(); const pending = deferred<OfficialMallPublicDetailResult>(); mocks.detail.mockReturnValueOnce(pending.promise);
    act(() => { window.dispatchEvent(new Event("focus")); button("加入购物车").click(); }); expect(mocks.add).not.toHaveBeenCalled();
    expect(host.querySelector("article")).toBe(card); expect(input()).toBe(field); expect(input().value).toBe("20"); expect(input().readOnly).toBe(true);
    expect([...host.querySelectorAll<HTMLButtonElement>(".omr-tier-select,.omr-counter button,.omr-cart")].every(node => node.disabled)).toBe(true);
    await act(async () => pending.reject(new Error("offline fixture"))); expect(host.querySelector('[role="alert"]')?.textContent).toContain("上次报价，仅供查看");
    expect(button("加入购物车").disabled).toBe(true); mocks.detail.mockResolvedValueOnce({ item: material({ revision: 2, qtyOnSale: 12, spq: 6 }) });
    await act(async () => button("重试").click()); expect(host.querySelector("article")).toBe(card); expect(input().value).toBe("20"); expect(input().getAttribute("aria-invalid")).toBe("true");
    expect(button("加入购物车").disabled).toBe(true); expect(host.querySelector(".omr-unit-price")?.textContent).toBe("单价 —");
  });
  it("refresh withdrawal removes prior SKU, quote, input, parameters and purchasing actions", async () => {
    await render(); mocks.detail.mockResolvedValueOnce({ item: null }); await refresh(); expect(host.querySelector("article,input,.omr-cart,.omr-detail-parameters")).toBeNull();
    expect(host.querySelector('[role="status"]')?.textContent).toContain("不存在或已下架"); expect(host.querySelector(".opd-content")?.textContent).not.toContain("TEST-A"); expect(mocks.list).not.toHaveBeenCalled();
  });
  it("ID changes remove old DOM immediately and abort/fence old successful response", async () => {
    await render(); const old = deferred<OfficialMallPublicDetailResult>(), fresh = deferred<OfficialMallPublicDetailResult>(); mocks.detail.mockReturnValueOnce(old.promise).mockReturnValueOnce(fresh.promise);
    await refresh(); const oldSignal: AbortSignal = mocks.detail.mock.calls[1][1].signal; await render({ publicId: B });
    expect(oldSignal.aborted).toBe(true); expect(host.querySelector("article")).toBeNull(); expect(host.querySelector(".opd-content")?.textContent).not.toContain("TEST-A");
    await settle(fresh, material({ publicId: B, partNumber: "TEST-B" })); await settle(old, material({ partNumber: "LATE-A" }));
    expect(host.querySelector("h1")?.textContent).toBe("TEST-B自营"); expect(host.querySelector(".opd-content")?.textContent).not.toContain("LATE-A");
    act(() => button("加入购物车").click()); expect(mocks.add.mock.calls[0][0].publicId).toBe(B);
  });
  it("ID changes fence late errors and malformed/mismatched detail results never display an unverified SKU", async () => {
    const old = deferred<OfficialMallPublicDetailResult>(); mocks.detail.mockReturnValueOnce(old.promise); await render();
    mocks.detail.mockResolvedValueOnce({ item: material({ publicId: B, partNumber: "TEST-B" }) }); await render({ publicId: B });
    await act(async () => old.reject(new Error("late old failure"))); expect(host.querySelector('[role="alert"]')).toBeNull();
    mocks.detail.mockResolvedValueOnce({ item: material({ publicId: A, partNumber: "WRONG-SKU" }) }); await refresh();
    expect(host.querySelector("h1")?.textContent).toBe("TEST-B自营"); expect(button("加入购物车").disabled).toBe(true); expect(host.textContent).not.toContain("WRONG-SKU");
    expect(mocks.list).not.toHaveBeenCalled();
  });
  it("bounds hanging first/detail refresh requests at eight seconds, aborts and rejects late replies", async () => {
    vi.useFakeTimers(); const first = deferred<OfficialMallPublicDetailResult>(); mocks.detail.mockReturnValueOnce(first.promise); await render();
    await act(async () => vi.advanceTimersByTimeAsync(SEARCH_RESULT_TIMEOUT_MS)); expect(mocks.detail.mock.calls[0][1].signal.aborted).toBe(true);
    expect(host.querySelector("article")).toBeNull(); expect(host.querySelector('[role="alert"]')?.textContent).toContain("暂不可用");
    await settle(first, material()); expect(host.querySelector("article")).toBeNull();
    mocks.detail.mockResolvedValueOnce({ item: material() }); await act(async () => button("重试").click());
    const pending = deferred<OfficialMallPublicDetailResult>(); mocks.detail.mockReturnValueOnce(pending.promise); await refresh();
    await act(async () => vi.advanceTimersByTimeAsync(SEARCH_RESULT_TIMEOUT_MS)); expect(button("加入购物车").disabled).toBe(true); expect(input().readOnly).toBe(true);
    await settle(pending, material({ revision: 99, partNumber: "LATE" })); expect(host.querySelector("h1")?.textContent).toBe("TEST-A自营");
  });
  it("periodically refreshes the same detail only, and does not refresh while hidden", async () => {
    vi.useFakeTimers(); await render(); await act(async () => vi.advanceTimersByTimeAsync(60_000)); expect(mocks.detail).toHaveBeenCalledTimes(2);
    Object.defineProperty(document, "visibilityState", { configurable: true, value: "hidden" }); await act(async () => vi.advanceTimersByTimeAsync(60_000)); expect(mocks.detail).toHaveBeenCalledTimes(2);
    Object.defineProperty(document, "visibilityState", { configurable: true, value: "visible" }); await act(async () => document.dispatchEvent(new Event("visibilitychange"))); expect(mocks.detail).toHaveBeenCalledTimes(3); expect(mocks.list).not.toHaveBeenCalled();
  });
  it("uses authoritative inline seed; unavailable or wrong-identity technical resources cannot leak cached or inferred data", async () => {
    const cached: OfficialMaterialResource = { publicId: A, revision: 1, partNumber: "TEST-A", brand: "ST", pkg: "QFN", category: null, description: null,
      datasheetUrl: "https://www.st.com/resource/en/datasheet/cached.pdf", parameters: [{ name: "LEAK", value: "cached-secret" }] };
    queryClient.setQueryData(officialMaterialResourceItemKey(cached), cached);
    mocks.detail.mockResolvedValueOnce({ item: material({ technicalResource: { state: "unavailable", parameterVersion: null, resource: null } }) }); await render();
    expect(host.textContent).not.toContain("cached-secret"); expect(host.querySelector('.omr-detail-specs a[href*=".pdf"]')).toBeNull(); expect(mocks.resources).not.toHaveBeenCalled();
    const bad = material(); bad.technicalResource!.resource!.publicId = B; mocks.detail.mockResolvedValueOnce({ item: bad }); await refresh();
    expect(host.querySelector(".omr-detail-parameters")).toBeNull(); expect(host.textContent).toContain("参数标识或版本不匹配");
  });
  it.each(["javascript:alert(1)", "https://127.0.0.1/internal.pdf", "https://www.st.com/private/a.pdf", "https://www.st.com/a.pdf?token=secret"])("does not render unsafe PDF %j", async url => {
    const item = material(); item.technicalResource!.resource!.datasheetUrl = url; mocks.detail.mockResolvedValueOnce({ item }); await render();
    expect(host.querySelectorAll('.omr-detail-specs a')).toHaveLength(0); expect(host.querySelectorAll(".omr-detail-parameters>div")).toHaveLength(7);
  });
  it("default source page delegates to the existing checkout bridge, adding official publicId+revision only", async () => {
    await render({}, true); expect(button("加入购物车").disabled).toBe(false); await act(async () => button("加入购物车").click());
    expect(mocks.cartAdd).toHaveBeenCalledWith({ publicId: A, expectedRevision: 1, qty: 10 }); expect(mocks.invalidate).toHaveBeenCalledWith(true);
    expect(mocks.notice).toHaveBeenCalledWith(3); expect(mocks.add).not.toHaveBeenCalled();
  });
  it("default bridge login-required path prompts login rather than saving a guest cart", async () => {
    mocks.buyer = ""; mocks.cartReady = "login_required"; await render({}, true); await act(async () => button("加入购物车").click());
    expect(host.querySelector('[role="dialog"]')?.textContent).toBe("登录"); expect(mocks.cartAdd).not.toHaveBeenCalled();
  });
  it("factory accepts existing host-bound Results/navigation without inventing a provider or client", async () => {
    const bound = vi.fn((props: React.ComponentProps<typeof OfficialMallSearchResults>) => <div data-bound-id={props.detailPublicId} data-bound-view={props.presentation} />);
    const factory = createOfficialProductDetail({ React, MallNav: () => <header>native nav</header>, Link: ({ href, children }: any) => <a href={href}>{children}</a>, OfficialMallCheckoutResults: bound, OfficialMallSearchResults: bound });
    const Page = factory; await act(async () => root.render(<Page publicId={B} />)); expect(host.querySelector("[data-bound-id]")?.getAttribute("data-bound-id")).toBe(B);
    expect(host.querySelector("[data-bound-view]")?.getAttribute("data-bound-view")).toBe("detail"); expect(mocks.detail).not.toHaveBeenCalled();
  });
  it("omits empty public attributes and unknown SPQ without inventing placeholders or changing draft eligibility", async () => {
    const item = material({ pkg: "", dateCode: "", leadTime: "  ", spq: null });
    mocks.detail.mockResolvedValue({ item }); await render();
    const labels = [...host.querySelectorAll(".omr-detail-attrs dt,.omr-detail-base-specs dt")].map(node => node.textContent);
    expect(labels).not.toContain("封装"); expect(labels).not.toContain("Date Code"); expect(labels).not.toContain("货期");
    expect(labels).not.toContain("整包数量 SPQ"); expect(labels).toContain("品牌/厂牌"); expect(labels).toContain("起订量 MOQ");
    expect(host.querySelector(".omr-detail-attrs")?.textContent).not.toContain("待确认");
    expect(host.querySelector(".omr-detail-base-specs")?.textContent).not.toContain("待确认");
    expect(button("加入购物车").disabled).toBe(false); expect(input().value).toBe("10");
    act(() => button("加入购物车").click()); expect(mocks.add).toHaveBeenCalledWith(item, 10);
  });
  it("keeps known zero stock visible and keeps missing MOQ or sale quantity blocked", async () => {
    mocks.detail.mockResolvedValue({ item: material({ qtyStock: 0, qtyOnSale: null, moq: null, spq: null }) }); await render();
    const rows = [...host.querySelectorAll(".omr-detail-base-specs>div")];
    expect(rows.find(node => node.querySelector("dt")?.textContent === "库存")?.querySelector("dd")?.textContent).toBe("0");
    expect(rows.some(node => node.querySelector("dt")?.textContent === "起订量 MOQ")).toBe(false);
    expect(rows.some(node => node.querySelector("dt")?.textContent === "可售数量")).toBe(false);
    expect(button("加入购物车").disabled).toBe(true); act(() => button("加入购物车").click()); expect(mocks.add).not.toHaveBeenCalled();
  });
  it("search presentation still omits official badge/tax/MOQ and renders a legal publicId as a clickable product link", async () => {
    mocks.list.mockResolvedValue({ items: [material()], total: 1, page: 1, pageSize: 100 });
    await act(async () => root.render(<QueryClientProvider client={queryClient}><OfficialMallSearchResults keyword="TEST-A" brand="all" sort="default" viewMode="list" officialCheckoutReady onAddOfficialDraft={mocks.add} /></QueryClientProvider>));
    expect(mocks.detail).not.toHaveBeenCalled(); expect(host.querySelector<HTMLAnchorElement>("a.omr-part")?.getAttribute("href")).toBe(`/product/${encodeURIComponent(A)}`);
    expect(host.querySelector(".omr-detail-mark,.omr-tax,.omr-moq")).toBeNull(); expect(host.querySelector("article")?.textContent).not.toMatch(/自营|含税|未税|起订/);
  });
});
