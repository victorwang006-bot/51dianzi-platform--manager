import { useRef, useState } from "react";
import { safeOfficialDatasheetUrl } from "@/lib/officialMaterialClient";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";

type Props = {
  brands: Array<{ brand: string }>;
  selectedBrand: string;
  onBrand: (brand: string) => void;
  partNumber?: string;
  specBrand?: string;
  loading: boolean;
  groups: Array<{ title: string; entries: Array<[string, string]> }>;
  datasheetUrl?: string;
};

export default function SearchCompactHeaderControls({
  brands,
  selectedBrand,
  onBrand,
  partNumber,
  specBrand,
  loading,
  groups,
  datasheetUrl,
}: Props) {
  const [open, setOpen] = useState(false);
  const trigger = useRef<HTMLButtonElement>(null);
  const count = groups.reduce((n, group) => n + group.entries.length, 0);
  const pdf = safeOfficialDatasheetUrl(datasheetUrl);
  return (
    <>
      <div className="compact-header-brands" aria-label="常用厂牌">
        <span className="quick-filter-label">常用厂牌</span>
        <div className="compact-header-brand-scroll">
          {brands.map(item => (
            <button
              type="button"
              key={item.brand}
              className={`f-opt${selectedBrand === item.brand ? " on" : ""}`}
              aria-pressed={selectedBrand === item.brand}
              onClick={() =>
                onBrand(selectedBrand === item.brand ? "all" : item.brand)
              }
            >
              {item.brand}
            </button>
          ))}
        </div>
      </div>
      {partNumber && (loading || count > 0) && (
        <button
          ref={trigger}
          type="button"
          className="compact-header-params"
          disabled={loading && count === 0}
          aria-haspopup="dialog"
          aria-expanded={open}
          title={`${partNumber}${specBrand ? ` · ${specBrand}` : ""} 完整参数`}
          onClick={() => setOpen(true)}
        >
          {loading && count === 0 ? "参数加载中…" : `参数（${count}）`}
          <span aria-hidden="true">↗</span>
        </button>
      )}
      {partNumber && pdf && <a className="compact-header-datasheet" href={pdf} target="_blank" rel="noopener noreferrer">PDF规格书 ↗</a>}
      <span className="compact-header-divider" aria-hidden="true" />
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent
          className="compact-header-params-dialog"
          onCloseAutoFocus={event => {
            event.preventDefault();
            trigger.current?.focus();
          }}
        >
          <DialogTitle>{partNumber} · 全部参数</DialogTitle>
          <DialogDescription>
            {specBrand ? `${specBrand} · ` : ""}
            参数属于当前精确型号，供选型核对；采购仍请与供应商确认。
          </DialogDescription>
          <div className="compact-header-spec-scroll">
            {groups.map(group => (
              <section className="compact-header-spec-group" key={group.title}>
                <h3>{group.title}</h3>
                <dl>
                  {group.entries.map(([key, value]) => (
                    <div key={key}>
                      <dt>{key}</dt>
                      <dd>{value}</dd>
                    </div>
                  ))}
                </dl>
              </section>
            ))}
          </div>
          {pdf && (
            <a
              className="compact-header-datasheet"
              href={pdf}
              target="_blank"
              rel="noopener noreferrer"
            >
              数据手册 ↗
            </a>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
