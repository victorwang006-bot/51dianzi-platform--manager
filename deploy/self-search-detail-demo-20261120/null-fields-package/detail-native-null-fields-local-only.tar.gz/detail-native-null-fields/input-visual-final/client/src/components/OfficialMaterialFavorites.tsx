import React, { useEffect, useRef, useState, type ComponentType } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import {
  OFFICIAL_MATERIAL_FAVORITES_QUERY_ROOT,
  OFFICIAL_MATERIAL_FAVORITES_CHANGED_EVENT,
  notifyOfficialMaterialFavoritesChanged,
  officialMaterialErrorMessage,
  type OfficialMaterialClient,
} from "@/lib/officialMaterialClient";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import type { OfficialMaterialFavoriteItem } from "@shared/officialMaterial";

export type OfficialMaterialFavoritesStatProps = {
  n: number | string;
  label: string;
  onClick?: () => void;
};
type EntryProps = { StatComponent: ComponentType<OfficialMaterialFavoritesStatProps> };
const PAGE_SIZE = 20;

/** Only the metadata returned for this favorite is eligible; no merchant/part-image fallback. */
export function officialFavoriteThumbnail(item: OfficialMaterialFavoriteItem): string | null {
  if (!["catalog_reference", "approved_generated", "approved_uploaded"].includes(item.imageKind ?? "")) return null;
  const value = item.thumbnailUrl;
  if (!value || value.length > 2048 || /[\s\u0000-\u001f\u007f\\]/.test(value)) return null;
  try {
    const url = new URL(value, "https://www.51dianzi.com");
    if (!/^https?:$/.test(url.protocol) || url.username || url.password || url.hash) return null;
    if (!/^https?:\/\//.test(value) && (!value.startsWith("/") || value.startsWith("//"))) return null;
    return value;
  } catch { return null; }
}

export function officialFavoriteSearchHref(item: Pick<OfficialMaterialFavoriteItem, "partNumber" | "brand">): string {
  return `/search?q=${encodeURIComponent(item.partNumber)}${item.brand ? `&brand=${encodeURIComponent(item.brand)}` : ""}`;
}

/** Keyed child is an owner fence, independent from AccountCenter's enterprise/financial context. */
export function OfficialMaterialFavoritesEntry({ StatComponent }: EntryProps) {
  const { user, isAuthenticated, loading } = useAuth();
  const ownerId = !loading && isAuthenticated && user ? user.id : null;
  return <OwnerFavorites key={ownerId === null ? "signed-out" : `owner:${ownerId}`} ownerId={ownerId} StatComponent={StatComponent} />;
}

function OwnerFavorites({ ownerId, StatComponent }: EntryProps & { ownerId: number | null }) {
  const utils = trpc.useUtils();
  const client = utils.client as unknown as OfficialMaterialClient;
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [page, setPage] = useState(1);
  const [pending, setPending] = useState<Set<string>>(() => new Set());
  const [removeError, setRemoveError] = useState<{ publicId: string; message: string } | null>(null);
  const pendingRef = useRef(new Set<string>());
  const alive = useRef(false);
  const scope = [...OFFICIAL_MATERIAL_FAVORITES_QUERY_ROOT, ownerId] as const;
  const count = useQuery({
    queryKey: [...scope, "count"],
    enabled: ownerId !== null,
    retry: false,
    queryFn: async ({ signal }) => {
      const result = await client.officialMaterial.favoriteCount.query(undefined, { signal });
      if (signal.aborted) throw new Error("Request cancelled");
      if (!Number.isSafeInteger(result.count) || result.count < 0) throw new Error("Invalid favorite count");
      return result;
    },
  });
  const list = useQuery({
    queryKey: [...scope, "list", page],
    enabled: ownerId !== null && open,
    retry: false,
    queryFn: async ({ signal }) => {
      const result = await client.officialMaterial.favorites.query({ page, pageSize: PAGE_SIZE }, { signal });
      if (signal.aborted) throw new Error("Request cancelled");
      if (!Number.isSafeInteger(result.total) || result.total < 0 || result.page !== page || result.pageSize !== PAGE_SIZE
        || !Array.isArray(result.items) || result.items.length > PAGE_SIZE) throw new Error("Invalid favorites page");
      return result;
    },
  });

  useEffect(() => {
    alive.current = true;
    const refresh = () => { void queryClient.invalidateQueries({ queryKey: scope }); };
    const storage = (event: StorageEvent) => {
      if (event.key === OFFICIAL_MATERIAL_FAVORITES_CHANGED_EVENT || event.key === null) refresh();
    };
    window.addEventListener(OFFICIAL_MATERIAL_FAVORITES_CHANGED_EVENT, refresh);
    window.addEventListener("storage", storage);
    return () => {
      alive.current = false;
      pendingRef.current.clear();
      window.removeEventListener(OFFICIAL_MATERIAL_FAVORITES_CHANGED_EVENT, refresh);
      window.removeEventListener("storage", storage);
      void queryClient.cancelQueries({ queryKey: scope });
    };
    // OwnerFavorites remounts for every auth boundary; this effect belongs to one owner only.
  }, [ownerId, queryClient]);

  const totalPages = list.data ? Math.max(1, Math.ceil(list.data.total / list.data.pageSize)) : null;
  useEffect(() => {
    // Never infer pages by the visible item count; a successful server total is authoritative.
    if (!list.isError && totalPages !== null && page > totalPages) setPage(totalPages);
  }, [list.isError, totalPages, page]);

  async function remove(publicId: string) {
    if (ownerId === null || !alive.current || pendingRef.current.has(publicId)) return;
    pendingRef.current.add(publicId);
    setPending(new Set(pendingRef.current));
    setRemoveError(null);
    try {
      const result = await client.officialMaterial.setFavorite.mutate({ publicId, favorite: false });
      if (!alive.current) return;
      if (result.publicId !== publicId || result.favorite !== false) throw new Error("Favorite was not removed");
      notifyOfficialMaterialFavoritesChanged(queryClient);
    } catch (error) {
      if (alive.current) setRemoveError({ publicId, message: officialMaterialErrorMessage(error, "取消收藏失败，请重试") });
    } finally {
      pendingRef.current.delete(publicId);
      if (alive.current) setPending(new Set(pendingRef.current));
    }
  }

  return <>
    <StatComponent n={ownerId !== null && count.isSuccess ? count.data.count : "—"} label="自营收藏" onClick={() => setOpen(true)} />
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-[620px] max-h-[85vh] overflow-y-auto" style={{ width: "calc(100vw - 24px)", maxWidth: "620px", maxHeight: "85vh", overflowY: "auto" }} aria-describedby={undefined}>
        <DialogHeader><DialogTitle>自营收藏</DialogTitle></DialogHeader>
        {ownerId === null ? <p role="status">请先登录</p> : <>
          {count.isError && <p role="alert" className="text-sm text-red-700">{officialMaterialErrorMessage(count.error, "收藏数量加载失败")} <button type="button" disabled={count.isFetching} onClick={() => void count.refetch()}>重试</button></p>}
          {list.isPending && <p role="status">加载中…</p>}
          {list.isError && <p role="alert" className="text-sm text-red-700">{officialMaterialErrorMessage(list.error, "收藏列表加载失败")} <button type="button" disabled={list.isFetching} onClick={() => void list.refetch()}>重试</button></p>}
          {removeError && <p role="alert" className="text-sm text-red-700">{removeError.message} <button type="button" disabled={pending.has(removeError.publicId)} onClick={() => void remove(removeError.publicId)}>重试</button></p>}
          {list.data && <>
            {list.data.total === 0 ? <p role="status">暂无自营收藏</p> : <ul className="divide-y divide-gray-100">
              {list.data.items.map(item => <FavoriteRow key={item.publicId} item={item} pending={pending.has(item.publicId)} onRemove={() => void remove(item.publicId)} />)}
            </ul>}
            {totalPages !== null && totalPages > 1 && <nav aria-label="自营收藏分页" className="flex items-center justify-center gap-4 text-sm">
              <button type="button" disabled={page <= 1 || list.isFetching} onClick={() => setPage(value => Math.max(1, value - 1))}>上一页</button>
              <span>{list.data.page} / {totalPages}</span>
              <button type="button" disabled={page >= totalPages || list.isFetching} onClick={() => setPage(value => value + 1)}>下一页</button>
            </nav>}
          </>}
        </>}
      </DialogContent>
    </Dialog>
  </>;
}

function FavoriteRow({ item, pending, onRemove }: { item: OfficialMaterialFavoriteItem; pending: boolean; onRemove: () => void }) {
  const image = officialFavoriteThumbnail(item);
  return <li className="flex items-center gap-3 py-3" data-public-id={item.publicId}>
    {image && <img src={image} alt={`${item.partNumber} ${item.imageKind === "approved_generated" ? "已审批生成示意图" : "型号参考图"}，非商品实拍`} width={48} height={48} className="h-12 w-12 shrink-0 object-contain" loading="lazy" onError={event => { event.currentTarget.hidden = true; }} />}
    <div className="min-w-0 flex-1 text-sm">
      <div className="break-words font-medium">{item.partNumber || "型号待确认"}</div>
      <div className="break-words text-xs text-gray-500">{[item.brand, item.pkg].filter(Boolean).join(" · ")}</div>
      {item.availability === "unavailable" && <span className="text-xs text-gray-500">已下架</span>}
      {item.availability === "unknown" && <span className="text-xs text-gray-500">商品状态待确认</span>}
    </div>
    <div className="flex shrink-0 flex-col items-end gap-2 text-xs text-[#185FA5]">
      {item.partNumber && <a href={officialFavoriteSearchHref(item)}>查看商品</a>}
      <button type="button" disabled={pending} onClick={onRemove}>{pending ? "取消中…" : "取消收藏"}</button>
    </div>
  </li>;
}
