import * as React from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import MallLoginDialog from "./MallLoginDialog";
import { OfficialMallSearchResults } from "./OfficialMallSearchResults";
import { useOfficialCartCount } from "@/hooks/useOfficialCart";
import { combinedCartKinds, isOfficialUnauthorized, officialErrorMessage } from "@/lib/officialCartClient";
import { showOfficialCartNotice } from "./OfficialCartNotice";

type Props = React.ComponentProps<typeof OfficialMallSearchResults>;
export type OfficialMallCheckoutResultsDependencies = {
  React: Pick<typeof React, "useState" | "useRef" | "useEffect" | "createElement" | "Fragment">;
  useLocation: typeof useLocation;
  useOfficialCartCount: typeof useOfficialCartCount;
  OfficialMallSearchResults: typeof OfficialMallSearchResults;
  MallLoginDialog: typeof MallLoginDialog;
  notice: typeof showOfficialCartNotice;
  error: (message: string) => unknown;
};
/** Legacy six public search props/export retained; draft callback now persists dedicated official cart rows. */
export function createOfficialMallCheckoutResults(deps: OfficialMallCheckoutResultsDependencies) {
  const React = deps.React;
  return function OfficialMallCheckoutResults(props: Props) {
    const scope = deps.useOfficialCartCount();
    const [, navigate] = deps.useLocation();
    const [loginOpen, setLoginOpen] = deps.React.useState(false);
    const busy = deps.React.useRef(false);
    const loginOwner = deps.React.useRef(scope.key);
    if (loginOwner.current !== scope.key) { loginOwner.current = scope.key; busy.current = false; }
    deps.React.useEffect(() => { setLoginOpen(false); }, [scope.key]);
    const add: NonNullable<Props["onAddOfficialDraft"]> = async (material, quantity) => {
      if (!scope.buyer) { setLoginOpen(true); return; }
      if (busy.current) return;
      const owner = scope.key;
      busy.current = true;
      try {
        const result = await scope.client.officialCart.add.mutate({ publicId: material.publicId, expectedRevision: material.revision, qty: quantity });
        if (!scope.isCurrent(owner)) return;
        if (!result.item || result.item.sourceType !== "official_mall" || result.item.publicId !== material.publicId ||
          !Number.isSafeInteger(result.count) || result.count < 1) throw new Error("购物车状态待确认，请刷新");
        await scope.invalidate(true);
        if (!scope.isCurrent(owner)) return;
        // The native cart endpoint remains untouched: the total is presentation-only.
        const normal = await scope.client.cart.count.query().catch(() => null);
        if (!scope.isCurrent(owner)) return;
        if (normal === null) { deps.error("已保存自营商品，购物车总数暂不可用，请查看购物车"); return; }
        deps.notice(combinedCartKinds(normal, result.count));
      } catch (reason) {
        if (!scope.isCurrent(owner)) return;
        if (isOfficialUnauthorized(reason)) setLoginOpen(true);
        else deps.error(officialErrorMessage(reason));
      } finally { if (scope.isCurrent(owner)) busy.current = false; }
    };
    const ready = scope.readiness === "ready" || scope.readiness === "login_required";
    return <>
      <deps.OfficialMallSearchResults {...props} officialCheckoutReady={ready} onAddOfficialDraft={add} />
      {loginOpen && <deps.MallLoginDialog open={loginOpen} onOpenChange={setLoginOpen} onSuccess={() => { setLoginOpen(false); navigate("/cart"); }} />}
    </>;
  };
}
export const OfficialMallCheckoutResults = createOfficialMallCheckoutResults({ React, useLocation, useOfficialCartCount, OfficialMallSearchResults, MallLoginDialog, notice: showOfficialCartNotice, error: message => toast.error(message) });
