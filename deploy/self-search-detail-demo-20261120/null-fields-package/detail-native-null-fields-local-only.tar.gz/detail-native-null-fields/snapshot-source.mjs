import fs from 'node:fs';import path from 'node:path';import {execFileSync} from 'node:child_process';import {H} from './incremental-core.mjs';
export const D='/home/ubuntu/work/self-row-redesign/detail-native-null-fields',P='/home/ubuntu/work/resume-frontend/platform',HEAD='6589eb2653eb30714845c77f7336ed0cf23e3afb',LISTHEAD='027c172ed38f979f5fbe939f08d3f4eb1dde2ee6';
export const fixed={
'client/src/components/OfficialMallSearchResults.tsx':'3e3e355de1bccc0327318ef0a5139b2b28b79c072c91cd445e09474af04680bc',
'client/src/components/OfficialMaterialResources.tsx':'0f4911e8b95ee3a643a3ee9ec7d17a1619a14f93677292467310590496785d57',
'client/src/pages/OfficialProductDetail.tsx':'26af704d416bc8442038f6caaa30b6a8b82dc1e4cbd7ea537daf1e3520af76cc',
'client/src/pages/ProductDetail.tsx':'f0c2a4f6930f62f7bfa63f8a45585f1b05107cac7ccc30c774c2fa98868235d2'};
function need(v,m){if(!v)throw Error(m)}
const original=JSON.parse(fs.readFileSync('/home/ubuntu/work/resume-frontend/remote-evidence/original-stage/package/evidence/frontend-manifest.json'));
export const originalFiles=Object.fromEntries(Object.entries(original.sourceFiles).filter(([k])=>k.startsWith('/home/ubuntu/work/platform/')).map(([k,v])=>[k.slice('/home/ubuntu/work/platform/'.length),v]));
export const extras=['client/src/components/OfficialMallCheckoutResults.tsx','client/src/assets/homeLogo.ts','client/src/assets/brand/logo-header-mark.webp','client/src/App.tsx'];
export const expectedSet=[...new Set([...Object.keys(originalFiles),...Object.keys(fixed),...extras])].sort();
export const sourceTestsSet=['client/src/pages/OfficialProductDetail.test.tsx','client/src/pages/ProductDetail.route.test.tsx','client/src/components/OfficialMaterialResources.SearchPage.test.tsx','client/src/components/OfficialMallSearchResults.polish.test.tsx','client/src/components/OfficialMaterialResources.polish.test.tsx','client/src/components/OfficialMallSearchResults.inline.test.tsx'];
export const aggregateSourceTestsSet=['client/src/pages/ProductDetail.tsx','client/src/pages/OfficialProductDetail.tsx','client/src/components/OfficialMallSearchResults.tsx','client/src/components/OfficialMaterialResources.tsx',...sourceTestsSet.slice(0,3)];
export function readObject(rel,head=HEAD){return execFileSync('git',['-C',P,'show',head+':'+rel],{maxBuffer:16e6,env:{PATH:process.env.PATH,GIT_NO_LAZY_FETCH:'1',GIT_OPTIONAL_LOCKS:'0'}})}
export function verifySourceTests(input,pins){
 need(Object.keys(pins.sourceTestFiles||{}).join('\n')===sourceTestsSet.join('\n'),'EXACT_SIX_SOURCE_TEST_SET');
 for(const rel of sourceTestsSet){need(H(fs.readFileSync(input+'/'+rel))===pins.sourceTestFiles[rel],'TEST_SNAPSHOT_SHA '+rel);need((fs.statSync(input+'/'+rel).mode&0o222)===0,'TEST_SNAPSHOT_READONLY '+rel)}
 const ordered=Object.fromEntries(aggregateSourceTestsSet.map(rel=>[rel,H(fs.readFileSync(input+'/'+rel))]));
 need(JSON.stringify(ordered)===JSON.stringify(pins.aggregateSourceTestsFiles),'EXACT_ORDERED_SEVEN_SOURCE_TEST_AGGREGATE');
 need(H(JSON.stringify(ordered))===pins.aggregateSourceTestsSHA256,'RECOMPUTED_SOURCE_TEST_AGGREGATE');
 const all=Object.fromEntries([...aggregateSourceTestsSet.slice(0,4),...sourceTestsSet].map(rel=>[rel,H(fs.readFileSync(input+'/'+rel))]));
 need(H(JSON.stringify(all))===pins.aggregateSourceAllSixTestsSHA256,'RECOMPUTED_ALL_SIX_TEST_AGGREGATE');
 return {aggregateSourceTestsSHA256:pins.aggregateSourceTestsSHA256,aggregateSourceAllSixTestsSHA256:pins.aggregateSourceAllSixTestsSHA256,sourceTestFiles:pins.sourceTestFiles,sourceTestsCount:sourceTestsSet.length,algorithm:'SHA256(JSON.stringify(ordered relative-path-to-file-SHA256 map)); original seven-file order retained',executionEvidence:'Parent final-CSS source test rerun is separate; this seal proves bytes, not execution',nativeRendererBrowser:'NOT_YET_RECOMPUTED'};
}
export function snapshot(){
 const dest=D+'/input-visual-final',pin=D+'/source-sha-visual-final.json';need(!fs.existsSync(dest)&&!fs.existsSync(pin),'SNAPSHOT_EXISTS');
 const files={},buffers={};for(const rel of expectedSet){const bytes=fs.readFileSync(P+'/'+rel);if(fixed[rel])need(H(bytes)===fixed[rel],'FINAL_PARENT_PIN '+rel);if(originalFiles[rel]&&!fixed[rel])need(H(bytes)===originalFiles[rel],'PROTECTED_ORIGINAL_SOURCE '+rel);if(extras.includes(rel))need(H(bytes)===H(readObject(rel,LISTHEAD)),'PROTECTED_LIST_HEAD '+rel);files[rel]=H(bytes);buffers[rel]=bytes}
 const sourceTestFiles={};for(const rel of sourceTestsSet){buffers[rel]=fs.readFileSync(P+'/'+rel);sourceTestFiles[rel]=H(buffers[rel])}
 for(const [rel,bytes]of Object.entries(buffers))need(H(fs.readFileSync(P+'/'+rel))===H(bytes),'SOURCE_TEST_RACE '+rel);
 fs.mkdirSync(dest);for(const [rel,bytes]of Object.entries(buffers)){const local=dest+'/'+rel;fs.mkdirSync(path.dirname(local),{recursive:true});fs.writeFileSync(local,bytes);fs.chmodSync(local,0o444)}
 const aggregateSourceTestsFiles=Object.fromEntries(aggregateSourceTestsSet.map(rel=>[rel,H(buffers[rel])])),all=Object.fromEntries([...aggregateSourceTestsSet.slice(0,4),...sourceTestsSet].map(rel=>[rel,H(buffers[rel])]));
 const pins={schema:'detail-native-source-sha-v1',baselineHead:HEAD,listHead:LISTHEAD,status:'NOT_APPROVED',files,finalParentPins:fixed,sourceTestFiles,aggregateSourceTestsFiles,aggregateSourceTestsSHA256:H(JSON.stringify(aggregateSourceTestsFiles)),aggregateSourceAllSixTestsSHA256:H(JSON.stringify(all)),sourceFileCount:expectedSet.length,sourceTestsCount:sourceTestsSet.length,originalProtectedSetCount:Object.keys(originalFiles).length};verifySourceTests(dest,pins);
 fs.writeFileSync(pin,JSON.stringify(pins,null,2)+'\n');fs.chmodSync(pin,0o444);return{inputSourceDir:dest,sourceShaFile:pin,sourceSha:H(fs.readFileSync(pin)),files,sourceTests:verifySourceTests(dest,pins),productionWrites:0,status:'NOT_APPROVED'}
}
if(process.argv[1]===D+'/snapshot-source.mjs')try{console.log(JSON.stringify(snapshot(),null,2))}catch(e){console.error('SNAPSHOT_REJECTED '+e.message);process.exitCode=1}
