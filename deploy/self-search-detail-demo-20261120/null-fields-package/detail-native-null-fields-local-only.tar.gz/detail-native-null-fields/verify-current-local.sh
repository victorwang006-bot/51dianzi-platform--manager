#!/usr/bin/env bash
set -euo pipefail
cd /home/ubuntu/work/self-row-redesign/detail-native-null-fields
node verify-native-detail.mjs --manifest "$PWD/candidate-visual-final/manifest.json"
node readonly-run.mjs --manifest "$PWD/candidate-visual-final/manifest.json"
